#!/bin/sh
#$ -S /bin/sh
#Version1.0	hewm@genomics.org.cn	2012-05-16
echo Start Time : 
date
## get clearn fq data ##
../bin/iTools 	 Fqtools  filter	-InFq1	/nas/RD_08B/backup/Soybean_resequencing/02.Sequencing/090902_I638_FC42K81AAXX_L3_SOYhyuRCHDEAPE_1.fq.gz	-InFq2	/nas/RD_08B/backup/Soybean_resequencing/02.Sequencing/090902_I638_FC42K81AAXX_L3_SOYhyuRCHDEAPE_2.fq.gz	-OutFq1	/ifs5/PC_PA_AP/USER/heweiming/soy31/Soap/090902_I638_FC42K81AAXX_L3_SOYhyuRCHDEAPE/090902_I638_FC42K81AAXX_L3_SOYhyuRCHDEAPE_1.fq.gz	-OutFq2	/ifs5/PC_PA_AP/USER/heweiming/soy31/Soap/090902_I638_FC42K81AAXX_L3_SOYhyuRCHDEAPE/090902_I638_FC42K81AAXX_L3_SOYhyuRCHDEAPE_2.fq.gz	-maxLeng	90	>	/ifs5/PC_PA_AP/USER/heweiming/soy31/Soap/090902_I638_FC42K81AAXX_L3_SOYhyuRCHDEAPE/fqfilter.log	
## mapping soap ##
/ifs1/STT_POP/USER/heweiming/bin/Soap/soap2.21	-a	/ifs5/PC_PA_AP/USER/heweiming/soy31/Soap/090902_I638_FC42K81AAXX_L3_SOYhyuRCHDEAPE/090902_I638_FC42K81AAXX_L3_SOYhyuRCHDEAPE_1.fq.gz	-b	/ifs5/PC_PA_AP/USER/heweiming/soy31/Soap/090902_I638_FC42K81AAXX_L3_SOYhyuRCHDEAPE/090902_I638_FC42K81AAXX_L3_SOYhyuRCHDEAPE_2.fq.gz	-D	/share/project005/xuxun/heweiming/Soybean/reference_v2/soybean.merge.fa.index	-m	100	-x	888	-s	35	-l	32	-v	3	-p	4	-o	/ifs5/PC_PA_AP/USER/heweiming/soy31/Soap/090902_I638_FC42K81AAXX_L3_SOYhyuRCHDEAPE/090902_I638_FC42K81AAXX_L3_SOYhyuRCHDEAPE.soap	-2	/ifs5/PC_PA_AP/USER/heweiming/soy31/Soap/090902_I638_FC42K81AAXX_L3_SOYhyuRCHDEAPE/090902_I638_FC42K81AAXX_L3_SOYhyuRCHDEAPE.single	2>	/ifs5/PC_PA_AP/USER/heweiming/soy31/Soap/090902_I638_FC42K81AAXX_L3_SOYhyuRCHDEAPE/soap.log	
##  soap result deal : split --> msort --> rmdep --> stat ##
../bin/iTools	SOAPtools	split	-Ref	/share/project005/xuxun/heweiming/Soybean/reference_v2/soybean.merge.fa	-OutStat	/ifs5/PC_PA_AP/USER/heweiming/soy31/Soap/090902_I638_FC42K81AAXX_L3_SOYhyuRCHDEAPE/ChrStat	-OutDir	/ifs5/PC_PA_AP/USER/heweiming/soy31/Soap/090902_I638_FC42K81AAXX_L3_SOYhyuRCHDEAPE/SoapBychr	-InFile	/ifs5/PC_PA_AP/USER/heweiming/soy31/Soap/090902_I638_FC42K81AAXX_L3_SOYhyuRCHDEAPE/090902_I638_FC42K81AAXX_L3_SOYhyuRCHDEAPE.soap	-InFile	/ifs5/PC_PA_AP/USER/heweiming/soy31/Soap/090902_I638_FC42K81AAXX_L3_SOYhyuRCHDEAPE/090902_I638_FC42K81AAXX_L3_SOYhyuRCHDEAPE.single	>>	insert.sd.info	
perl	/ifs1/STT_POP/USER/heweiming/bin/Soap/soap2_insert_step2.pl	/ifs5/PC_PA_AP/USER/heweiming/soy31/Soap/090902_I638_FC42K81AAXX_L3_SOYhyuRCHDEAPE/ChrStat.insert	
rm	-f	/ifs5/PC_PA_AP/USER/heweiming/soy31/Soap/090902_I638_FC42K81AAXX_L3_SOYhyuRCHDEAPE/090902_I638_FC42K81AAXX_L3_SOYhyuRCHDEAPE.soap	/ifs5/PC_PA_AP/USER/heweiming/soy31/Soap/090902_I638_FC42K81AAXX_L3_SOYhyuRCHDEAPE/090902_I638_FC42K81AAXX_L3_SOYhyuRCHDEAPE.single	
perl	/ifs1/STT_POP/USER/heweiming/bin/Soap/chrSort2SortDedupV1.20.pl	-inDir	/ifs5/PC_PA_AP/USER/heweiming/soy31/Soap/090902_I638_FC42K81AAXX_L3_SOYhyuRCHDEAPE/SoapBychr	-outDir	/ifs5/PC_PA_AP/USER/heweiming/soy31/Soap/090902_I638_FC42K81AAXX_L3_SOYhyuRCHDEAPE/SoapBychrDup	-rmsoapBychr	-laneID	64	-chrlist	/share/project005/xuxun/heweiming/Soybean/reference_v2/soybean.merge.fa.chrlist	
# this Perl(about) call the [../bin/iTools  SOAPtools msort & rmdup] to deal each chr mapping result ##
ls	/ifs5/PC_PA_AP/USER/heweiming/soy31/Soap/090902_I638_FC42K81AAXX_L3_SOYhyuRCHDEAPE/SoapBychrDup/*	>	/ifs5/PC_PA_AP/USER/heweiming/soy31/Soap/090902_I638_FC42K81AAXX_L3_SOYhyuRCHDEAPE/tmp.list	
../bin/iTools	SOAPtools	stat	-InList	/ifs5/PC_PA_AP/USER/heweiming/soy31/Soap/090902_I638_FC42K81AAXX_L3_SOYhyuRCHDEAPE/tmp.list	-Ref	/share/project005/xuxun/heweiming/Soybean/reference_v2/soybean.merge.fa	-OutStat	/ifs5/PC_PA_AP/USER/heweiming/soy31/Soap/090902_I638_FC42K81AAXX_L3_SOYhyuRCHDEAPE/AllStat.out	>	/ifs5/PC_PA_AP/USER/heweiming/soy31/Soap/090902_I638_FC42K81AAXX_L3_SOYhyuRCHDEAPE/depth.dis	
rm	/ifs5/PC_PA_AP/USER/heweiming/soy31/Soap/090902_I638_FC42K81AAXX_L3_SOYhyuRCHDEAPE/tmp.list	
##  if one sample have multi lane ,can used  [../bin/iTools	SOAPtools merge] to cat the result.
#../bin/iTools  SOAPtools       merge   -InList List/LaneSoapByChrSoap.Gm01.list       -OutPut sampe/SoapBychrSort/Gm01.sort.soap.gz
echo End Time : 
date
