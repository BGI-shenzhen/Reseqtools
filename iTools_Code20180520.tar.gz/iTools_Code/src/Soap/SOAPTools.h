#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstdlib>
#include "../include/zlib/zlib.h"
#include <stdio.h>
#include "../ALL/kseq.h"
#include "../ALL/comm.h"

#include "msort/sort_funs.c"
#include "msort/stdhashc.cc"
#include "msort/msort_h.h"

#include "Soap_Filter.h"
#include "Soap_Genotype.h"
#include "Soap_Merge.h"
#include "Soap_RmDup.h"
#include "Soap_Split.h"
#include "Soap_Stat.h"
#include "View/Soap_View.h"
#include "../Form/soap2sam.h"
#include "../Form/xam2soap.h"

using namespace std;

int Soap_Filter_main(int argc, char **argv);
int Soap_Genotype_main(int argc, char **argv);
int Soap_Merge_main(int argc,char *argv[]);
int Soap_RmDup_main(int argc, char *argv[]);
int Soap_Split_main(int argc,char *argv[]);
int Soap_View_main(int argc, char *argv[]);
int Soap_Stat_main(int argc, char **argv);
int Xam2Soap_main(int argc, char **argv);
int soap2sam_main(int argc, char *argv[]);

static int  SOAP_usage ()
{
	cerr <<"Program: SOAPtools (Tools for Soap output)\nVersion: 0.21\thewm@genomics.org.cn\t2012-02-24"<<endl;
	cerr<<""
		"\n"
		"\tSOAP Usage:\n\n"
		"\t\tsplit       split soap[list] by chr file\n"
		"\t\tmsort       sort the SoapOut by [chr and position]\n"
		"\t\tview        view the Soap Alignment\n"
		"\t\tmerge       merge multi SoapBychrSort to a Sort Soap\n"
		"\t\tfilter      fiter/extract the soap Read\n"
		"\t\tstat        stat SortSoap of [depth,coverage,MisMacth...]\n"
		"\t\trmdup       remove PCR duplicates of SortSoap \n"
		"\t\tgenotype    SortSoap-->consistency[genotype,RST,Hit,Qseq...]\n"
		"\n"
		"\t\tSoap2Sam    Soap --> Sam Fomat\n"
		"\t\tXam2Soap    Bam,Sam --> Soap Fomat\n"
		"\n"
		"\t\tHelp        Show this help\n"
		"\n";
	return 1;
}

int SOAP_Tools_main(int argc, char *argv[])
{
	if (argc < 2) { return SOAP_usage(); }
	else if (strcmp(argv[1], "msort") == 0) { return msort_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "split") == 0) { return Soap_Split_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "merge") == 0) { return Soap_Merge_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "filter") == 0) { return Soap_Filter_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "stat") == 0) { return Soap_Stat_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "genotype") == 0) { return Soap_Genotype_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "view") == 0) { return Soap_View_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "rmdup") == 0) { return Soap_RmDup_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "Soap2Sam") == 0) { return soap2sam_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "Xam2Soap") == 0) { return Xam2Soap_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "Help") == 0 || strcmp(argv[1], "help") == 0 )  {  SOAP_usage(); }
	else
	{
		cerr<<"SOAPtools[main] unrecognized command "<<argv[1]<<endl;
		return 1;
	}
	return 0;	
}


