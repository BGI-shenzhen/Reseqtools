#ifndef Soap_RmDup_H_
#define Soap_RmDup_H_

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <map>
#include <cstdlib>
#include "../include/gzstream/gzstream.C"
#include "../ALL/DataClass.h"
#include "../include/zlib/zlib.h"
#include <stdio.h>
//KSEQ_AINIT(gzFile, gzread)
#include "../ALL/comm.h"
using namespace std;

int  print_Ausage_A23()
{
	cout <<""
		"\n"
		"\tUsage: rmdup  -InPut <in.sort.soap> -OutPut out.soap \n"
		"\n"
		"\t\t-InPut     <str>   InPut SortSoap file \n"
		"\t\t-OutPut    <str>   OutPut file with rmdup\n"
		"\n"
		"\t\t-IDFlag    <int>   Add Flag to ReadID for SoapSV[NA]\n"
		"\t\t-help              show this help\n" 
		"\n";
	return 1;
}


int parse_Acmd_A23(int argc, char **argv , In3str1v * para_A23  )
{
	if (argc <=2 ) {print_Ausage_A23();return 0 ;}


	for(int i = 1; i < argc ; i++)
	{
		if(argv[i][0] != '-')
		{
			cerr << "command option error! please check." << endl;
			return 0 ;
		}
		string flag=argv[i] ;
		flag=replace_all(flag,"-","");

		if (flag  == "InPut" )
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0 ; }
			i++;
			para_A23->InStr1=argv[i];
		}           
		else if (flag  ==  "OutPut")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0 ;}
			i++;
			para_A23->InStr2=argv[i];
		}
		else if (flag  ==  "IDFlag")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0 ;}
			i++;
			para_A23->InInt=atoi(argv[i]);
		}
		else if (flag  == "help")
		{
			print_Ausage_A23();return 0 ;;
		}
		else
		{
			cerr << "UnKnow argument -"<<flag<<endl;
			return 0 ;
		}
	}
	if  ((para_A23->InStr1).empty() || (para_A23->InStr2).empty()  )
	{
		cerr<< "lack argument for the must"<<endl ;
		return 0 ;
	}
	(para_A23->InStr2)=add_Asuffix ( (para_A23->InStr2) );
	if ((para_A23->InStr1) == (para_A23->InStr2) )
	{
		cerr<<"\t\toutput should be the same with the input file\n";
		return 0 ;
	}
	return 1 ;
}

int InsertMap ( map <string, string> & A ,  map <string, string> & B ,string key,string val )
{
	map <string, string> :: iterator it=A.find(key);

	if (it == A.end() )
	{
		A.insert(map <string, string> :: value_type(key,val));
		return 1 ;
	}
	else
	{
		B.insert(map <string, string> :: value_type(key,val));
		return 2;
	}

}


int Soap_RmDup_main(int argc, char *argv[])
{
	In3str1v * para_A23 = new In3str1v;
	para_A23->InInt=-1;
	if (parse_Acmd_A23(argc, argv , para_A23 ) == 0 ) 
	{
		delete para_A23 ;
		return 1;
	}
	igzstream IN ((para_A23->InStr1).c_str(),ifstream::in);

	ogzstream OUT ((para_A23->InStr2).c_str());

	if(!IN.good())
	{
		cerr << "open InputFile error: "<<(para_A23->InStr1)<<endl;
		return 1;
	}
	if(!OUT.good())
	{
		cerr << "open InputFile error: "<<(para_A23->InStr2)<<endl;
		return 1;
	}

	int Flag =0 ,ReadLeng , hit ;
	string  lineF  ;
	//  char * RID ;
	string  RID ,seq , Qseq ,ab , zf, chr , Posi ;
	//long long Posi ;
	getline(IN,lineF);
	map <string, string> SameStat ;
	map <string, string> SameStatV2 ;
	istringstream isone (lineF,istringstream::in);
	isone>>RID>>seq>>Qseq>>hit>>ab>>ReadLeng>>zf>>chr>>Posi ;
	string GenoPosi=chr+Posi ;
	string NowID= RID ;

	//  b       100     -       chr01   5    
	while(!IN.eof())
	{
		string  line ;
		getline(IN,line);
		if (line.length()<=0)  { continue  ; }
		istringstream isone (line,istringstream::in);
		isone>>RID>>seq>>Qseq>>hit>>ab>>ReadLeng>>zf>>chr>>Posi ;
		string GenoPositmp=chr+Posi ;
		if (GenoPosi!=GenoPositmp)
		{
			if (Flag)
			{
				string StortID =getID(NowID) ;
				InsertMap ( SameStat ,SameStatV2  ,StortID , GenoPosi );
				Flag=0;
			}
			NowID=RID ;
			GenoPosi=GenoPositmp;
		}
		else
		{
			string StortID =getID(NowID) ;
			InsertMap ( SameStat ,SameStatV2 , StortID , GenoPosi );
			Flag=1;
			NowID=RID ;
			GenoPosi=GenoPositmp;
		}
	}
	IN.close();

	map <string, int> IDMap ;
	map <string, int> IntMap ; 

	map <string, string> :: iterator it=SameStatV2.begin();
	map <string, string> :: iterator itA ;

	for(it=SameStatV2.begin() ; it!=SameStatV2.end(); it++)
	{
		string valuB=(it->second);
		string keynow=it->first ;
		itA=SameStat.find(keynow);
		string valuA=(itA->second);
		string key=valuA+valuB;
		if (valuB<valuA)
		{
			key=valuB+valuA;
		}
		map <string, int> :: iterator itInt=IntMap.find(key);
		if (itInt==IntMap.end())
		{
			IntMap.insert(map <string, int> :: value_type(key,1));
			//      IDMap.insert(map <string, int> :: value_type(key,keynow));
		}
		else
		{
			(itInt->second)++;
			IDMap.insert(map <string, int> :: value_type (keynow,1));
			//cerr<<keynow<<"\t"<<valuA<<"\t"<<valuB<<endl;
		}
	}

	IntMap.clear();
	SameStat.clear();
	SameStatV2.clear();


	igzstream INS ((para_A23->InStr1).c_str(),ifstream::in);
	if ((para_A23->InInt)<1)
	{
		while(!INS.eof())
		{        
			string  line ;
			getline(INS,line);
			if (line.length()<=0)  { continue  ; }
			istringstream isone (line,istringstream::in);
			isone>>RID;
			string StortID =getID(RID) ;
			map <string, int> :: iterator it=IDMap.find(StortID);
			if (it==IDMap.end())
			{
				OUT<<line<<endl;
			}
		}
	}
	else
	{
		while(!INS.eof())
		{        
			string  line ;
			getline(INS,line);
			if (line.length()<=0)  { continue  ; }
			istringstream isone (line,istringstream::in);
			isone>>RID;
			string StortID =getID(RID) ;
			map <string, int> :: iterator it=IDMap.find(StortID);
			if (it==IDMap.end())
			{
				OUT<<(para_A23->InInt)<<"-"<<line<<endl;
			}
		}
	}
	OUT.close();
	INS.close();
	IDMap.clear();
	delete para_A23 ;
	return 1;

}

#endif //Soap_RmDup_H_
///////// swimming in the sky and flying in the sea ////////////
//




