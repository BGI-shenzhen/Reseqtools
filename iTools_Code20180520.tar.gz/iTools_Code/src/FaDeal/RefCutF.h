#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <map>
#include "../ALL/comm.h"
#include <cstdlib>
#include "../include/gzstream/gzstream.C"
#include "../include/zlib/zlib.h"
#include <stdio.h>
#include "../ALL/kseq.h"
#include "./RefCutS.h"
#include <sys/stat.h>

//KSEQ_AINIT(gzFile, gzread)

using namespace std;
typedef long long  llong ;


int  print_Ausage_A33()
{
	cout <<""
		"\n"
		"\tUsage: cutF  -InFa <in.fa>  \n"
		"\n"
		"\t\t-InFa     <str>   Input Fa for cut to subFile\n"
		"\n"
		"\t\t-OutDir   <str>   Output Dir for cut Files [PWD]\n"        
		"\t\t-Cut      <int>   Num of subFile for cut Fa [12]\n"
		"\n"
		"\t\t-help             show this help\n" 
		"\n";
	return 1;
}


int parse_Acmd_A33(int argc, char **argv , In3str1v * para_A26 )
{
	if (argc <=2 ) {print_Ausage_A33();return 0;}

	for(int i = 1; i < argc ; i++)
	{
		if(argv[i][0] != '-')
		{
			cerr << "command option error! please check." << endl;
			return 0;
		}
		string flag=argv[i] ;
		flag=replace_all(flag,"-","");

		if (flag  == "InFa" )
		{
			if(i + 1 == argc) {LogLackArg( flag ) ; return 0;}
			i++;
			para_A26->InStr1=argv[i];
		}
		else if (flag  ==  "OutDir")
		{
			if(i + 1 == argc) {LogLackArg( flag ) ; return 0;}
			i++;
			para_A26->InStr2=argv[i];
			para_A26->InStr2=(para_A26->InStr2)+"/";
		}
		else if (flag  ==  "Cut")
		{
			if(i + 1 == argc) {LogLackArg( flag ) ; return 0;}
			i++;
			para_A26->InInt=atoi(argv[i]);
		}
		else if (flag  == "help")
		{
			print_Ausage_A33();return 0;
		}
		else
		{
			cerr << "UnKnow argument -"<<flag<<endl;
			return 0;
		}
	}
	if  ((para_A26->InStr1).empty() )
	{
		cerr<< "lack argument for the must"<<endl ;
		return 0;
	}

	if ((para_A26->InStr2).empty())
	{
		(para_A26->InStr2)="./" ;
	}
	return 1 ;
}


int FA_CutFile_main(int argc, char *argv[])
	//int main(int argc, char *argv[])
{
	In3str1v * para_A26 = new In3str1v ;
	para_A26->InInt=12;

	if( parse_Acmd_A33(argc, argv, para_A26 )==0)
	{
		delete  para_A26 ;
		return 0 ;
	}

	string ext =(para_A26->InStr1).substr((para_A26->InStr1).rfind('/') ==string::npos ? (para_A26->InStr1).length() : (para_A26->InStr1).rfind('/') + 1);
	if (ext=="")
	{
		ext=(para_A26->InStr1);
	}
	ext=replace_all(ext,".fa.gz","");
	ext=replace_all(ext,".fa","");
	if (ext=="")
	{           
		ext="Out" ;
	}
	(para_A26->InStr2)=(para_A26->InStr2)+ext+"_cut/";
	mkdir((para_A26->InStr2).c_str() , 0755 ) ;

	if ((para_A26->InInt)<2)
	{
		cout<<"cut off must be biger 1"<<endl;
		delete  para_A26 ; return 0;
	}
	else
	{

		gzFile fp;
		kseq_t *seq;
		int l;
		fp = gzopen((para_A26->InStr1).c_str(), "r");
		seq = kseq_init(fp);
		llong SumLeng=0;
		map <string,llong>  ChrLeng ;

		while ((l = kseq_read(seq)) >= 0)
		{
			string  chr=seq->name.s ;
			llong  chr_length=(seq->seq.l);
			SumLeng+=chr_length;
			ChrLeng[chr]=chr_length ;
		}

		kseq_destroy(seq);
		gzclose(fp);

		llong Sub_len=llong(SumLeng/(para_A26->InInt));
		cout<<"SumLeng: "<<SumLeng<<"\tSubFileLeng: "<<Sub_len<<endl; 
		igzstream  IN ((para_A26->InStr1).c_str(),ifstream::in);
		if(!IN.good())
		{
			cerr << "open InputFile error: "<<(para_A26->InStr1)<<endl;
			delete  para_A26 ; return 0;
		}

		string tmp ;
		getline(IN, tmp, '>');
		int A=1;

		while(!IN.eof())
		{
			string chr_line ,seq , chr_name ;
			string outfile=(para_A26->InStr2)+ext+"_"+Int2Str(A)+".fa.gz";
			ogzstream  OUT (outfile.c_str());

			if (OUT.fail())
			{
				cerr << "open OUT File error: "<<outfile<<endl;
				delete  para_A26 ; return  0;
			}
			llong Cur_len=0; 

			while(Cur_len<Sub_len)
			{
				if (!IN.eof())
				{
					getline(IN, chr_line , '\n');
					getline(IN, seq , '>');
					OUT<<">"<<chr_line<<endl<<seq;
					istringstream isone (chr_line,istringstream::in);
					isone>>chr_name ;
					Cur_len+=ChrLeng[chr_name];
				}
				else
				{
					break ;
				}
			}

			OUT.close();
			OUT.clear();
			A++;
		}

	}

	delete para_A26 ;
	return 0;
}

///////// swimming in the sky and flying in the sea ////////////

