#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <map>
#include "../ALL/comm.h"
#include <cstdlib>
#include "../include/gzstream/gzstream.C"
#include <algorithm>
#include "../include/zlib/zlib.h"
#include <stdio.h>
#include "../ALL/kseq.h"
#include "../ALL/DataClass.h"

using namespace std;
typedef long long  llong ;

int  usage_sort()
{
	cout <<""
		"\n"
		"\tUsage: sort -InPut <in.fa> -OutPut <out.fa>\n"
		"\n"
		"\t\t-InPut   <str>   Input fa File to sort\n"
		"\t\t-OutPut  <str>   Output sort fa File\n"
		"\n"
		"\t\t-Sort    <str>   Rank the Seq by [name/length]\n"
		"\t\t                 Default [name]\n"
		"\t\t-reverse         reverse the result,no seq\n"
		"\t\t-help            Show this help\n"
		"\n";
	return 1;
}


int parse_Acmd_FA18(int argc, char **argv ,In3str1v * para_FA18 )
{
	if (argc <=2 ) {usage_sort();return 0;}

	for(int i = 1; i < argc ; i++)
	{
		if(argv[i][0] != '-')
		{
			cerr << "command option error! please check." << endl;
			return 0;
		}
		string flag=argv[i] ;
		flag=replace_all(flag,"-","");

		if (flag  == "InPut" )
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			para_FA18->InStr1=argv[i];
		}
		else if (flag  ==  "OutPut")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_FA18->InStr2=argv[i];
		}       
		else if (flag  == "Sort")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			string temp=(argv[i]);
			if (temp == "length" || temp == "Length" )
			{
				para_FA18->TF=false;
			}
		}
		else if (flag  == "reverse")
		{
			para_FA18->TF2=false;
		}
		else if (flag  == "help")
		{
			usage_sort();return 0;
		}

		else
		{
			cerr << "UnKnow argument -"<<flag<<endl;
			return 0;
		}
	}
	if  ((para_FA18->InStr2).empty() || (para_FA18->InStr1).empty() )
	{
		cerr<< "lack argument for the must"<<endl ;
		return 0;
	}
	return 1 ;
}




//int main(int argc, char *argv[])
int FA_Sort_main(int argc, char *argv[])
{
	In3str1v * para_FA18 = new In3str1v;

	if( parse_Acmd_FA18(argc, argv, para_FA18 )==0)
	{
		delete  para_FA18 ;
		return 0;    
	}

	int linecut= FaCutLine ((para_FA18->InStr1));

	(para_FA18->InStr2)=add_Asuffix((para_FA18->InStr2));
	string chrlist=(para_FA18->InStr2)+".chrlist";
	ogzstream  OUT ((para_FA18->InStr2).c_str());
	if(!OUT.good())
	{
		cerr << "open OUT File error: "<<(para_FA18->InStr2)<<endl;
		delete para_FA18 ;  return 0;
	}

	gzFile fp;
	kseq_t *seq;
	int l;
	fp = gzopen((para_FA18->InStr1).c_str(),"r");
	seq = kseq_init(fp);
	map <string ,llong > ChrLen ;
	map <string ,string> ChrSeq ;
	map <llong ,vector <string> > SortLeng ;
	map <string ,string> COM ;

	while ((l = kseq_read(seq)) >= 0) 
	{
		string RefSeq=(seq->seq.s);
		string chr=(seq->name.s);
		llong seq_length = (seq->seq.l);

		ChrLen[chr]=seq_length;
		ChrSeq[chr]=RefSeq;
		map <llong ,vector <string> > ::iterator it=SortLeng.find(seq_length);
		if (it==SortLeng.end())
		{
			vector <string> tmp;
			tmp.push_back(chr);
			SortLeng.insert(map <llong,vector <string> > ::value_type(seq_length,tmp));
		}
		else
		{
			(it->second).push_back(chr);
		}
		if (seq->comment.l)
		{
			COM[chr]=seq->comment.s;
		}
	}
	kseq_destroy(seq);
	gzclose(fp);

	if (para_FA18->TF)
	{
		if  (para_FA18->TF2)
		{
			map <string ,llong > ::iterator itL = ChrLen.begin();
			for ( ; itL!=ChrLen.end(); itL++)
			{    
				string chr=itL->first ;
				string ID=chr ;
				if (COM.find(chr)!=COM.end())
				{
					ID+="\t"+COM[chr];
				}
				Display(ChrSeq[chr],ID,OUT,linecut);
			}
		}
		else
		{
			map <string ,llong > ::iterator itL = ChrLen.end();
			while(1)
			{
				itL--;
				string chr=itL->first ;
				string ID=chr ;
				if (COM.find(chr)!=COM.end())
				{
					ID+="\t"+COM[chr];
				}
				Display(ChrSeq[chr],ID,OUT,linecut);
				if (itL==ChrLen.begin())
				{
					break;
				}
			}
		}
	}
	else
	{
		vector <string>  SortChr ;
		map <llong ,vector <string> > ::iterator it=SortLeng.begin();
		for ( ; it!=SortLeng.end();it++)
		{
			int Size=(it->second).size();
			for (int ii=0; ii<Size ; ii++)
			{
				SortChr.push_back((it->second)[ii]);
			}
		}
		SortLeng.clear();
		int size_length=SortChr.size();
		if (para_FA18->TF2)
		{
			for (int i=size_length-1; i>-1; i--)
			{
				string chr=SortChr[i];
				string ID=chr;
				if (COM.find(chr)!=COM.end())
				{
					ID+="\t"+COM[chr];
				}
				Display( ChrSeq[chr] ,ID , OUT , linecut);
			}
		}
		else
		{
			for ( int i=0; i<size_length; i++ )
			{
				string chr=SortChr[i];
				string ID=chr;
				if (COM.find(chr)!=COM.end())
				{
					ID+="\t"+COM[chr];
				}
				Display( ChrSeq[chr] ,ID , OUT , linecut);
			}

		}
	}
	OUT.close();

	char * A = const_cast<char*>((para_FA18->InStr2).c_str());
	char * B = const_cast<char*>((chrlist).c_str());
	char * ssTmp[5]={(char *)"stat", (char *)"-InPut", A ,(char *)"-OutPut" , B  };
	FA_stat_main(5 , ssTmp ) ;
	delete para_FA18 ;
	return 0;
}

///////// swimming in the sky and flying in the sea ////////////
