#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <map>
#include "../ALL/comm.h"
#include <cstdlib>
#include "../include/gzstream/gzstream.C"
#include "../include/zlib/zlib.h"
#include <stdio.h>
#include "../ALL/kseq.h"
#include "../ALL/DataClass.h"

//KSEQ_AINIT(gzFile, gzread)
using namespace std;

int  print_AusageFA02()
{
	cout <<""
		"\n"
		"\tUsage: getSN  -InPut <in.fa>  -Sample 5-10\n"
		"\n"
		"\t\t-InPut       <str>   InPut fa for geting  Sub range Seq\n"
		"\t\t-Sample      <str>   Get Seq by specified order range\n"
		"\t\t                     Only give one num will only extract one Seq\n"
		"\n"
		"\t\t-OutPut      <str>   OutPut Fasta file or [STDOUT]\n" 
		"\n"
		"\t\t-help                show this help\n" 
		"\n";
	return 1;
}


int parse_AcmdFA02(int argc, char **argv , In3str1v * paraFA02 )
{
	if (argc <=2 ) {print_AusageFA02();return 0;}

	for(int i = 1; i < argc ; i++)
	{
		if(argv[i][0] != '-')
		{
			cerr << "command option error! please check." << endl;
			return 0;
		}
		string flag=argv[i] ;
		flag=replace_all(flag,"-","");

		if (flag  == "InPut" )
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			paraFA02->InStr1=argv[i];
		}
		else if (flag  ==  "Sample")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			paraFA02->InStr3=argv[i];
		}
		else if (flag  ==  "OutPut")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			paraFA02->InStr2=argv[i];
		}
		else if (flag  == "help")
		{
			print_AusageFA02();return 0;
		}
		else
		{
			cerr << "UnKnow argument -"<<flag<<endl;
			return 0;
		}
	}
	if  ((paraFA02->InStr1).empty() || (paraFA02->InStr3).empty() )
	{
		cerr<< "lack argument for the must"<<endl ;
		return 0;
	}
	if (!(paraFA02->InStr2).empty() )
	{
		(paraFA02->InStr2)=add_Asuffix(paraFA02->InStr2) ;
	}

	return 1 ;
}

int FA_Order_main(int argc, char *argv[])
	//int main(int argc, char *argv[])
{
	In3str1v * paraFA02 = new In3str1v;
	if( parse_AcmdFA02(argc, argv, paraFA02 )==0)
	{
		delete  paraFA02 ;
		return 0 ;
	}

	vector<string> Temp;
	split((paraFA02->InStr3),Temp,"-");
	int Start=atoi(Temp[0].c_str());
	int End=atoi(Temp[Temp.size()-1].c_str());
	if (Start>End)
	{
		cerr<<Start<<"biger than"<<endl;
		delete  paraFA02 ; return 0;
	}

	igzstream IN ((paraFA02->InStr1).c_str(),ifstream::in);
	if(!IN.good())
	{
		cerr << "open InputFile error: "<<(paraFA02->InStr1)<<endl;
		delete  paraFA02 ; return 0;
	}
	if ((paraFA02->InStr2).empty())
	{
		string tmp ;
		getline(IN, tmp, '>');
		int A=0;
		while(!IN.eof())
		{
			string chr_line ,seq , chr_name;
			A++;
			getline(IN, chr_line , '\n') ;
			getline(IN, seq , '>') ;
			if (A>=Start)
			{
				cout<<">"<<chr_line<<"\n"<<seq;
			}
			if (A>=End)
			{
				break ;
			}
		}
	}
	else
	{

		ogzstream  OUT  ((paraFA02->InStr2).c_str());
		if (OUT.fail())
		{
			cerr << "open OUTFile error: "<<(paraFA02->InStr2)<<endl;
			delete  paraFA02 ; return 0;
		}

		string tmp ;
		getline(IN, tmp, '>');
		int A=0;
		while(!IN.eof())
		{
			string chr_line ,seq , chr_name;
			A++;
			getline(IN, chr_line , '\n') ;
			getline(IN, seq , '>') ;
			if (A>=Start)
			{
				OUT<<">"<<chr_line<<"\n"<<seq;
			}
			if (A>=End)
			{
				break ;
			}
		}

		OUT.close();
	}
	delete paraFA02 ;
	return 0;

}

///////// swimming in the sky and flying in the sea ////////////

