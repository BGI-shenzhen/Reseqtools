#ifndef RefCutS_h_
#define RefCutS_h_ 

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <map>
#include "../ALL/comm.h"
#include "../ALL/DataClass.h"
#include <cstdlib>
#include "../include/gzstream/gzstream.C"
#include "../include/zlib/zlib.h"
#include <stdio.h>
#include "../ALL/kseq.h"
#include <sys/stat.h>

//KSEQ_AINIT(gzFile, gzread)

using namespace std;
typedef long long  llong ;


int  print_Ausage_A26()
{
	cout <<""
		"\n"
		"\tUsage: cutS  -InFa <in.fa>  \n"
		"\n"
		"\t\t-InFa     <str>   Input Fa for cut to subFile\n"
		"\n"
		"\t\t-OutDir   <str>   Output Dir for cut Files [PWD]\n"        
		"\t\t-Cut      <int>   Num of seq for each subFile [1]\n"
		"\n"
		"\t\t-help             show this help\n" 
		"\n";
	return 1;
}


int parse_Acmd_A26(int argc, char **argv , In3str1v * para_A26 )
{
	if (argc <=2 ) {print_Ausage_A26();return 0;}

	for(int i = 1; i < argc ; i++)
	{
		if(argv[i][0] != '-')
		{
			cerr << "command option error! please check." << endl;
			return 0;
		}
		string flag=argv[i] ;
		flag=replace_all(flag,"-","");

		if (flag  == "InFa" )
		{
			if(i + 1 == argc) { LogLackArg(flag); return 0;}
			i++;
			para_A26->InStr1=argv[i];
		}
		else if (flag  ==  "OutDir")
		{
			if(i + 1 == argc) { LogLackArg(flag);  return 0;}
			i++;
			para_A26->InStr2=argv[i];
			para_A26->InStr2=(para_A26->InStr2)+"/";
		}
		else if (flag  ==  "Cut")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			para_A26->InInt=atoi(argv[i]);
		}
		else if (flag  == "help")
		{
			print_Ausage_A26();return 0;
		}
		else
		{
			cerr << "UnKnow argument -"<<flag<<endl;
			return 0;
		}
	}
	if  ((para_A26->InStr1).empty() )
	{
		cerr<< "lack argument for the must"<<endl ;
		return 0;
	}

	if ((para_A26->InStr2).empty())
	{
		(para_A26->InStr2)="./" ;
	}
	return 1 ;
}


int FA_CutSeq_main(int argc, char *argv[])
	//int main(int argc, char *argv[])
{
	In3str1v * para_A26 = new In3str1v;
	para_A26->InInt=1;
	if( parse_Acmd_A26(argc, argv, para_A26 )==0)
	{
		delete  para_A26 ;
		return 0 ;
	}

	igzstream  IN ((para_A26->InStr1).c_str(),ifstream::in);
	if(!IN.good())
	{
		cerr << "open InputFile error: "<<(para_A26->InStr1)<<endl;
		delete  para_A26 ; return 0;
	}

	string ext =(para_A26->InStr1).substr((para_A26->InStr1).rfind('/') ==string::npos ? (para_A26->InStr1).length() : (para_A26->InStr1).rfind('/') + 1);
	if (ext=="")
	{
		ext=(para_A26->InStr1);
	}
	ext=replace_all(ext,".fasta.gz","");
	ext=replace_all(ext,".fasta","");
	ext=replace_all(ext,".fa.gz","");
	ext=replace_all(ext,".fa","");
	if (ext=="")
	{           
		ext="Out" ;
	}
	(para_A26->InStr2)=(para_A26->InStr2)+ext+"_cut/";
	mkdir((para_A26->InStr2).c_str() , 0755 ) ;

	if ((para_A26->InInt)<1)
	{
		cout<<"cut off must be positive"<<endl;
		delete  para_A26 ; return 0;
	}
	else if ( (para_A26->InInt) == 1 )
	{
		string tmp ;
		getline(IN, tmp, '>');
		while(!IN.eof())
		{
			string chr_line ,seq , chr_name;
			getline(IN, chr_line , '\n') ;
			getline(IN, seq , '>') ;
			istringstream isone (chr_line,istringstream::in);
			isone>>chr_name ;
			string outfile=(para_A26->InStr2)+chr_name+".fa.gz";
			ogzstream  OUT (outfile.c_str());
			if (OUT.fail())
			{
				cerr << "open OUT File error: "<<outfile<<endl;
				delete  para_A26 ; return  0;
			}
			OUT<<">"<<chr_line<<"\n"<<seq;
			OUT.close();
			OUT.clear();
		}
	}
	else
	{
		string tmp ;
		getline(IN, tmp, '>');
		int A=1;
		while(!IN.eof())
		{
			string chr_line ,seq , chr_name;
			getline(IN, chr_line , '\n') ;
			getline(IN, seq , '>') ;
			string outfile=(para_A26->InStr2)+ext+"_"+Int2Str(A)+".fa.gz";
			ogzstream  OUT (outfile.c_str());

			if (OUT.fail())
			{
				cerr << "open OUT File error: "<<outfile<<endl;
				delete  para_A26 ; return  0;
			}            
			OUT<<">"<<chr_line<<"\n"<<seq ;

			for ( int i=1 ; i< (para_A26->InInt) ; i++ )
			{
				if (!IN.eof())
				{
					getline(IN, chr_line , '\n');
					getline(IN, seq , '>') ;
					OUT<<">"<<chr_line<<"\n"<<seq;
				}
				else
				{
					break ;
				}
			}

			OUT.close();
			OUT.clear();
			A++;
		}

	}

	delete para_A26 ;
	return 0;

}

#endif // RefCutS_h_

///////// swimming in the sky and flying in the sea ////////////

