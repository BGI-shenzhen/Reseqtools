#include <iostream>
#include "../include/gzstream/gzstream.C"
#include "../ALL/comm.h"
#include <fstream>
#include <sstream>
#include <vector>
#include <iomanip>
#include <map>
#include <string>
#include <ctime>
#include <algorithm>
#include <boost/thread/thread.hpp>
#include <boost/thread/mutex.hpp>
#include <boost/bind.hpp>


using namespace std ;
using namespace boost ;
using namespace __gnu_cxx;

/// ///////swimming in the sea & flying in the sky ////////////

int  print_usage_6()
{
	cout <<""
		"\n"
		"\tUsage: Addcn -InRaw <in.raw> -SoapList <SoapBychr.list> -OutPut <out.addcn>\n"
		"\n"
		"\t\t-InRaw     <str>     Input file of GLFmulti raw\n"
		"\t\t-SoapList  <str>     soap by chr list\n"
		"\t\t-OutPut    <str>     OutPut addcn file with copyberNum\n"
		"\t\t-ChrLeng   <int>     The length of the chr ref\n"
		"\n"
		"\t\t-CPU       <int>     Number of thread for Run [2]\n"
		"\t\t-help                show this help\n" 
		"\n";
	return 1;
}


class Para_6 {
	public:
		string raw ;
		string soaplist ;
		string output ;
		int chrleng ;
		int NumBer_CPU ;
		Para_6()
		{
			chrleng=0;
			NumBer_CPU=2;
			raw="";
			soaplist="";
			output="";
		}
};

//mutex mutexVector ;


int parse_cmd_6(int argc, char **argv, Para_6 * para_6)
{
	if (argc <=2 ) {print_usage_6();return  0;}

	for(int i = 1; i < argc ; i++)
	{
		if(argv[i][0] != '-')
		{
			cerr << "command option error! please check." << endl;
			return 0;
		}
		string flag=argv[i] ;
		flag=replace_all(flag,"-","");

		if (flag  == "InRaw" )
		{
			if(i + 1 == argc) {LogLackArg(flag); return  0;}
			i++;
			para_6->raw=argv[i];
		}
		else if (flag  ==  "SoapList")
		{
			if(i + 1 == argc) {LogLackArg(flag); return  0;}
			i++;
			para_6->soaplist=(argv[i]);
		}
		else if (flag  ==  "CPU")
		{
			if(i + 1 == argc) {LogLackArg(flag);return  0;}
			i++;
			para_6->NumBer_CPU=atoi(argv[i]);
		}
		else if (flag  ==  "ChrLeng")
		{
			if(i + 1 == argc) {LogLackArg(flag);return  0;}
			i++;
			para_6->chrleng=atol(argv[i]);
		}
		else if (flag  ==  "OutPut")
		{
			if(i + 1 == argc) {LogLackArg(flag);return  0;}
			i++;
			para_6->output=argv[i];
		}
		else if (flag  == "help")
		{
			print_usage_6();return 0;
		}
		else
		{
			cerr << "UnKnow argument -"<<flag<<endl;
			return  0;
		}
	}
	if  ((para_6->raw).empty() ||  (para_6->soaplist).empty() ||   (para_6->output).empty() )
	{
		cerr<< "lack argument for the must"<<endl ;
		return  0;
	}
	para_6->output=add_Asuffix(para_6->output);
	if ( (para_6->chrleng) < 10)
	{
		cerr<<"chr lenth must in"<<endl;
		return  0; 
	}
	return 1 ;
}



void  StatHit( vector  <string> & Files , vector  <pair <int,int> > & Info )
{
	int B=Files.size();
	for (int kk=0 ; kk<B ;  kk++ )
	{
		string soapfile=Files[kk];
		if(soapfile.length()>0)
		{
			cout<<"SoapFile\t"<<soapfile<<endl;
			igzstream  soap (soapfile.c_str(),ifstream::in);
			string id,seq,qua,ab,zw,chr;
			int hit ,length,start;
			if(!soap.good())
			{
				cerr<<"open soap error: "<<soapfile<<endl;
				return  ;
			}
			while(!soap.eof())
			{
				string  line ;
				getline(soap,line);
				int position ;
				if(line.length() > 0 )
				{
					istringstream isone (line,istringstream::in);
					isone>>id>>seq>>qua>>hit>>ab>>length>>zw>>chr>>start ;
					for (int ii=0 ; ii<length ; ii++)
					{
						position = start+ii ;  
						//                       mutex::scoped_lock lock(mutexVector);
						(Info[position].first)++;
						(Info[position].second)+=hit;
					}
				}
			}
			soap.close();
			soap.clear();
		}
	}
}


int Addcn_main(int argc,char *argv[])
{
	Para_6 * para_6 = new Para_6;
	if( parse_cmd_6(argc, argv ,  para_6 )==0 )
	{
		delete  para_6 ;
		return  0 ;
	}
	clock_t start_time = clock();
	clock_t end_time ;

	string soaplist_file=para_6->soaplist;
	string raw_file=para_6->raw ;
	string output_file=para_6->output ;
	int chr_length=para_6->chrleng ;
	chr_length+=2 ;
	pair <int,int> temp ;
	temp=make_pair(0,0) ;
	vector <pair <int,int> > Info (chr_length,temp);

	igzstream  raw   (raw_file.c_str(),ifstream::in);
	ogzstream out_fs (output_file.c_str()) ;
	vector <string> SoapFiles ;

	if(!raw.good())
	{
		cerr << "open RawFile error: "<<raw_file<<endl;
		return  0;
	}

	ReadList ( (para_6->soaplist)  , SoapFiles  );
	thread_group TRead ;

	int SumFile=SoapFiles.size();
	int Sub_File=(SumFile/(para_6->NumBer_CPU));
	int headtmp=(para_6->NumBer_CPU)+1;
	cout<<headtmp<<endl;
	for (int jj=0 ; jj<headtmp; jj++)
	{
		vector <string> Now ; 
		int Start= jj*Sub_File ;
		int  End =Start+Sub_File ;
		cout <<Start<<"\t"<<End<<endl ;
		for ( int key=Start ; (key<End && key<SumFile) ; key++ )
		{
			cout<<SoapFiles[key]<<endl;
			Now.push_back(SoapFiles[key]);
		}
		if (!Now.empty())
		{
			TRead.create_thread(bind(StatHit , Now ,boost::ref(Info) ));
		}
	}

	//getchar();
	TRead.join_all();

	while(!raw.eof())
	{
		string  line ;
		getline(raw,line);
		if(line.length() > 0 )
		{
			string chr ; 
			int posi ;
			if (line[0] == '#') 
			{
				out_fs<<line<<endl;
				continue ;
			}
			istringstream isone(line,istringstream::in);
			isone>>chr>>posi ;
			if (Info[posi].first!=0)
			{
				double mean_hit=(double(Info[posi].second+0.0)/double(Info[posi].first+0.0));
				out_fs<<line<<"\t"<<setiosflags(ios::fixed)<<setiosflags(ios::right)<<setprecision(2)<<mean_hit<<endl;
			}
			else
			{
				out_fs<<line<<"\t25.00"<<endl;
			}
		}
	}
	raw.close();
	out_fs.close();
	end_time = clock();
	delete para_6 ;
	Info.clear();
	cout << "time elapsed : " << (end_time - start_time) / (float)CLOCKS_PER_SEC << endl;
	return  0 ;
}



////////////////////////swimming in the sea & flying in the sky //////////////////



////////////////////////swimming in the sea & flying in the sky //////////////////
///////// swimming in the sky and flying in the sea ////////////
