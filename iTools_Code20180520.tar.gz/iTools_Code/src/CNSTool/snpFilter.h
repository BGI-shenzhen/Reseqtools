#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <map>
#include <cstdlib>
#include "../include/gzstream/gzstream.C"
#include "../ALL/comm.h"
using namespace std;

///////////////////

int  print_usage_2()
{
	cout <<""
		"\n"
		"\tUsage: FilterCns  -InPut <in.cns> -OutPut <out.cns>\n"
		"\n"
		"\t\t-InPut      <str>   InPut the CNS file of potential SNP\n"
		"\t\t-OutPut     <str>   OutPut of accurate SNP\n"
		"\n"
		"\t\t-MinQual    <int>   the min qulity for snp[20]\n"
		"\t\t-MaxCP    <float>   the max soap rep(copynumber) for snp[2.0]\n"
		"\t\t-MinDist  <float>   the min distant for two snps[1]\n"
		"\t\t-MinDepth <float>   the min depth for two snps[1]\n"
		"\t\t-MaxDepth <float>   the max depth for two snps[100]\n"
		"\n"
		"\t\t-help               show this help\n"
		"\n";
	return 1;
}



int parse_cmd_2(int argc, char **argv, ParaClass * para_2)
{
	if (argc <=2 ) {print_usage_2();return 0;}

	for(int i = 1; i < argc ; i++)
	{
		if(argv[i][0] != '-')
		{
			cerr << "command option error! please check." << endl;
			return 0;
		}
		string flag=argv[i] ;
		flag=replace_all(flag,"-","");

		if (flag  == "InPut" )
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_2->InPut1=argv[i];
		}
		else if (flag  ==  "OutPut")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_2->OutPut1=argv[i];
		}
		else if (flag  ==  "MinDist")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_2->InInt1=atoi(argv[i]);
		}
		else if (flag  ==  "MinQual")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_2->InStr1=argv[i];
		}
		else if (flag  ==  "MaxDepth")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_2->InInt3=atoi(argv[i]);
		}
		else if (flag  ==  "MinDepth")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_2->InInt2=atoi(argv[i]);
		}
		else if (flag  ==  "MaxCP")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_2->Indouble=atof(argv[i]);
		}

		else if (flag  == "help")
		{
			print_usage_2();return 0;
		}
		else
		{
			cerr << "UnKnow argument -"<<flag<<endl;
			return 0;
		}
	}
	if  ((para_2->InPut1).empty() ||  (para_2->OutPut1).empty() )
	{
		cerr<< "lack argument for the must"<<endl ;
		return 0;
	}
	para_2->OutPut1=add_Asuffix(para_2->OutPut1);

	return 1 ;
}

//programme entry
int filter_main(int argc,char *argv[])
{
	ParaClass * para_2 = new ParaClass;
	(para_2->Indouble)=2.0;
	para_2->InInt2=1;
	para_2->InInt3=100;
    para_2->InInt1=1;
	para_2->InStr1="20";
	if (parse_cmd_2(argc, argv, para_2 )==0)
	{
		delete para_2 ;
		return  0;
	}

	int  minQual=atoi((para_2->InStr1).c_str());
	igzstream IN (para_2->InPut1.c_str(),ifstream::in); // igzstream
	ogzstream OUT ((para_2->OutPut1).c_str()); // write_para_4

	if(!IN.good())
	{
		cerr << "open InputFile error: "<<para_2->InPut1<<endl;
		return 0;
	}

	if (!OUT.good())
	{
		cerr << "open OUT File error: "<<para_2->OutPut1<<endl;
		return 0;
	}

	////////////////////////swimming in the sea & flying in the sky //////////////////   
	string ori ,soap_base ;
	int soap_base_int ,dbsnp ;
	int qual,base1Depth,base2Depth,depth ,dist ;
	float rank_sum ,rep ;
	map <string,int> code ;
	code["A"]=1;      code["G"]=1;      code["C"]=1;      code["T"]=1; 
	code["M"]=0;      code["W"]=0;      code["R"]=0;
	code["S"]=0;      code["Y"]=0;      code["K"]=0;      

	string temp1 ;
	// decode = ["A", "M", "W", "R", "M", "C", "Y", "S", "W", "Y", "T", "K", "R", "S", "K", "G"]
	//
	while(!IN.eof())
	{
		string  line ;
		getline(IN,line);
		if (line.length()<=0)  { continue ; }
		istringstream isone (line,istringstream::in);        
		isone>>temp1>>temp1>>temp1>>soap_base>>qual>>temp1>>temp1>>temp1>>base1Depth>>temp1>>temp1>>temp1>>base2Depth>>depth>>rank_sum>>rep>>dbsnp>>dist ;

		bool isSNP=((dbsnp==1) or  (dbsnp==5));
		soap_base_int=code[soap_base];

		if  (  rep  > (para_2->Indouble) )
		{
			continue  ;
		}       
		else if (   qual <  minQual )
		{
			continue  ;
		}
		else if  (  depth >  (para_2->InInt3) )
		{
			continue  ;
		}
		else  if ( !(dist >= (para_2->InInt1) || isSNP ) )
		{
			continue  ;
		}

		if (soap_base_int==1)
		{
			if (depth >= (para_2->InInt2))
			{
				OUT<<line<<"\n" ;
			}
		}
		else if  ( base1Depth >= (para_2->InInt2) &&   base2Depth >= (para_2->InInt2) )
		{
			OUT<<line<<"\n" ;
		}
	}
	IN.close();
	OUT.close();
	delete para_2 ;
	return 0 ;
}
////////////////////////swimming in the sea & flying in the sky //////////////////
