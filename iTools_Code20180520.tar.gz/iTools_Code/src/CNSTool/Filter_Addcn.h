#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <map>
#include <cstdlib>
#include "glfRead.h"
#include "../include/gzstream/gzstream.C"
#include "../ALL/comm.h"
using namespace std;

class Para_7 {
	public:
		string input_file ;
		string output_file ;
		string  name ;
		int  depthmin ;
		int  depthmax ;
		double  quality ;
		double cpnumber ;
		Para_7()
		{
			input_file="";
			output_file="";
			name="HG";
			depthmin=68 ;
			depthmax=1168 ;
			quality=15 ;
			cpnumber=1.5 ;
		}
} ;



int  print_usage_7 ()
{
	cout <<""
		"\n"
		"\tUsage:FilterRaw  -InAddcn <in.addcn> -OutPut <out.addcn> [options]\n"
		"\t\t-InAddcn       <str>   file name of input addcn file\n"
		"\t\t-OutPut        <str>   file name of output\n"
		"\n"
		"\t\t-MinDepth      <int>   the filter of the lowest depth [68]\n"
		"\t\t-MaxDepth      <int>   the filter of the hightest depth [1168]\n"
		"\t\t-Quality    <double>   the filter of the snp quility  [15]\n"
		"\t\t-CpNumber    <float>   the filter of the copynumber  [1.5]\n"
		"\t\t-Name          <str>   the name of the speci for dbsnp [HG]\n"
		"\n"
		"\t\t-help                  show this help\n" 
		"\n";
	return 1;
}

int parse_cmd_7(int argc, char **argv, Para_7 * para_7 )
{
	if (argc <=4  ) {print_usage_7();return 0 ;}

	for(int i = 1; i < argc ; i++)
	{
		if(argv[i][0] != '-')
		{
			cerr << "command option error! please check." << endl;
			return 0 ;
		}
		string flag=argv[i] ;
		flag=replace_all(flag,"-","");

		if (flag  == "InAddcn" )
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0 ;}
			i++;
			para_7->input_file=argv[i];
		}
		else if (flag  ==  "Quality")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0 ;}
			i++;
			para_7->quality=atof(argv[i]);
		}
		else if (flag  ==  "CpNumber")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0 ;}
			i++;
			para_7->cpnumber=atof(argv[i]);
		}
		else if (flag  ==  "OutPut")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0 ;}
			i++;
			para_7->output_file=argv[i];
		}
		else if (flag  ==  "Name")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0 ;}
			i++;
			para_7->name=argv[i];
		}
		else if (flag  ==  "MinDepth")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0 ;}
			i++;
			para_7->depthmin=atoi(argv[i]);
		}
		else if (flag  ==  "MaxDepth")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0 ;}
			i++;
			para_7->depthmax=atoi(argv[i]);
		}
		else if (flag  == "help")
		{
			print_usage_7();return 0 ;
		}
		else
		{
			cerr << "UnKnow argument -"<<flag<<endl;
			return 0 ;
		}
	}
	if  ((para_7->input_file).empty() ||  (para_7->output_file).empty() )
	{
		cerr<< "lack argument for the must"<<endl ;
		return 0 ;
	}
	return 1 ;
}

//programme entry
///////// swimming in the sky and flying in the sea ////////////
int FilterAddcn_main(int argc, char **argv)
{
	Para_7 * para_7 = new Para_7;
	if (parse_cmd_7(argc, argv , para_7 )==0 )
	{
		delete para_7 ;
		return 0; 
	}
	igzstream IN ((para_7->input_file).c_str(),ifstream::in); // ifstream  + gz 
	string output_filter=(para_7->output_file)+".filter";
	string output_dbsnp=(para_7->output_file)+".dbsnp";
	ofstream  OUT1 (output_filter.c_str());
	ofstream  OUT2 (output_dbsnp.c_str());

	if(!IN.good())
	{
		cerr << "open IN File error: "<<para_7->input_file<<endl;
		return 1;
	}
	if(!OUT1.good())
	{
		cerr << "open OUT File error: "<<output_filter<<endl;
		return 1;
	} 
	if(!OUT2.good())
	{
		cerr << "open OUT File error: "<<output_dbsnp<<endl;
		return 1;
	} 
	//chr24   9       T       2       0.500000        T       C       124     0       0       1.00
	//chr24   10      T       2       0.500000        T       C       124     0       0       1.00
	//chr24   11      A       3       0.500000        A       G       124     0       0       1.00
	//chr24   12      A       7       0.785714        C       A       65      59      49      1.43
	string chr ;
	char ref_base , base1 ,base2 ; 
	int depth ,fre_base1 ,fre_base2 ;

	//long position ;
	double mean_hit, cp_log , SNP_Q ;
	int cout_snp=0;
	while(!IN.eof())
	{
		string  line  ;
		int position ;
		getline(IN,line);
		if (line.length()<=0)  { continue  ; }
		istringstream isone (line,istringstream::in);
		isone>>chr>>position>>ref_base>>depth>>cp_log>>base1>>base2>>fre_base1>>fre_base2>>SNP_Q>>mean_hit ;
		if ( SNP_Q < (para_7->quality)  ) { continue  ; }
		if ( depth < (para_7->depthmin)  ||  depth > (para_7->depthmax)  ) { continue  ; }         
		if ( mean_hit >  (para_7->cpnumber)  ) { continue  ; }        
		if (fre_base2==0 || fre_base1==0 )   { continue  ; }
		OUT1<<line<<"\n" ;
		double T[4]={0.0, 0.0, 0.0, 0.0};
		double temp_fre=  int((100*((fre_base1*1.0)/(fre_base1+fre_base2))+0.5))/100.0 ;
		//            double(int(fre_base1*1.0))/(fre_base1+fre_base2)/100 ;
		T[((base1>>1)&3)]=temp_fre ;
		T[((base2>>1)&3)]=1-temp_fre ;
		cout_snp++;
		stringstream ss;          ss<<cout_snp;       string s=ss.str();         
		//string s=cout_snp.ToString(); 
		string ID="000000000"+s;
		ID=ID.substr(ID.size()-8);
		ID=(para_7->name)+ID ;
		OUT2<<chr<<"\t"<<position<<"\t1\t"<<T[0]<<"\t"<<T[1]<<"\t"<<T[2]<<"\t"<<T[3]<<"\t"<<ID<<"\n";
		// hash{A},$hash{C},$hash{T},$hash{G}
		//         return (allele1>>1)&3;
		//      // A 0 C 1 T 2 G 3
	}
	IN.close();
	OUT1.close();
	OUT2.close();
	delete para_7 ;
	return 0;
}

///////// swimming in the sky and flying in the sea ////////////
