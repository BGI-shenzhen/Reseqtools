#include <stdio.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <map>
#include "glfRead.h"
#include <cstdlib>
#include "../ALL/kseq.h"
#include "../include/zlib/zlib.h"
#include "../include/gzstream/gzstream.C"
#include "../ALL/comm.h"
#include "../ALL/DataClass.h"

using namespace std;

int  print_usage_14()
{
	cout <<""
		"\n"
		"\tUsage: AddRef  -InPut <inFile> -Ref <in.fa> -OutPut <out>\n"
		"\n"
		"\t\t-InPut     <str>   Input file(chr site ...) to add ref base\n"
		"\t\t-Ref       <str>   Input Chr Ref fasta file\n"
		"\t\t-OutPut    <str>   Output of the file with ref_base\n"
		"\n"
		"\t\t-help              show this help\n" 
		"\n";
	return 1;
}


int parse_cmd_14(int argc, char **argv, In3str1v * para_14  )
{
	if (argc <=2 ) {print_usage_14();return  0;}

	for(int i = 1; i < argc ; i++)
	{
		if(argv[i][0] != '-')
		{
			cerr << "command option error! please check." << endl;
			return 0;
		}
		string flag=argv[i] ;
		flag=replace_all(flag,"-","");

		if (flag  == "InPut" )
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			para_14->InStr1=argv[i];
		}
		else if (flag  == "Ref" )
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			para_14->InStr2=argv[i];
		}
		else if (flag  ==  "OutPut")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			para_14->InStr3=argv[i];
		}
		else if (flag  == "help")
		{
			print_usage_14();return 0;
		}
		else if (flag  == "Multi")
		{
		}
		else
		{
			cerr << "UnKnow argument -"<<flag<<endl;
			return 0;
		}
	}
	if  ((para_14->InStr1).empty()||(para_14->InStr3).empty()||(para_14->InStr2).empty() )
	{
		cerr<< "lack argument for the must"<<endl ;
		return 0;
	}
	para_14->InStr3=add_Asuffix(para_14->InStr3);
	return 1 ;
}



//KSEQ_INIT(gzFile, gzread)
int AddRef_main(int argc, char *argv[])
{
	In3str1v * para_14 = new In3str1v;
	if (parse_cmd_14(argc, argv, para_14 )==0)
	{
		delete  para_14 ;
		return 0;
	}

	gzFile fp;
	kseq_t *seq ;
	int l;
	fp = gzopen((para_14->InStr2).c_str(), "r");
	seq = kseq_init(fp);

	igzstream IN (para_14->InStr1.c_str(),ifstream::in); // ifstream  + gz 
	ogzstream OUT (para_14->InStr3.c_str());

	if(!IN.good())
	{
		cerr << "open IN File error: "<<para_14->InStr1<<endl;
		return 1;
	}
	if(!OUT.good())
	{
		cerr << "open OUT File error: "<<para_14->InStr3<<endl;
		return 1;
	}

	map <string,string> HashSeq ;
	while ((l = kseq_read(seq)) >= 0) 
	{
		string  ChrSeq=(seq->seq.s) ;
		string  chrID =(seq->name.s);
		HashSeq.insert(map <string, string> :: value_type(chrID,ChrSeq));
	}

	while(!IN.eof())
	{
		string  line ;
		getline(IN,line);
		if (line.length()<=0)  { continue ; }
		vector<string> inff;
		split(line,inff," \t" );
		int position=atoi(inff[1].c_str())-1 ;
		OUT<<inff[0]<<"\t"<<inff[1]<<"\t"<<(HashSeq[inff[0]])[position];
		int AA=inff.size();
		for (int ii=2 ; ii<AA ; ii++)
		{
			OUT<<" "<<inff[ii];
		}
		OUT<<"\n";
	}

	OUT.close();
	IN.close();
	kseq_destroy(seq);
	gzclose(fp);
	delete para_14 ;
	return 0;
}

//programme entry
///////// swimming in the sky and flying in the sea ////////////
///////// swimming in the sky and flying in the sea ////////////
