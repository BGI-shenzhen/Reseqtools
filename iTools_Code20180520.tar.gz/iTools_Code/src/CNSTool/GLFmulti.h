#include<iostream>
#include<fstream>
#include<map>
#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#include<string>
#include<time.h>
#include<float.h>
#include "glfRead.h"
#include <iomanip>
#include "../include/gzstream/gzstream.C"
#include "../ALL/comm.h"
using namespace std ;


#ifndef DBL_MANT_DIG
#define DBL_MANT_DIG 35
#endif
//*///
#define MAX_FILE_LIST_LEN 1024
#define MAX_LIST_NAME_LEN 1024
#define MAX_CHR_NAME_LEN 128

//const char decode[16] = {'N','A','C','N','G','N','N','N','T','N','N','N','N','N','N','N'};
//const int code[10] = {0,5,15,10,1,3,2,7,6,11};
//const int rev_code[16] = {0,4,6,5,4,1,8,7,6,8,3,9,5,7,9,2};
///*////

int  print_usage_5()
{
	cout <<""
		"\n"
		"\tUsage: GLFmulti -GlfList <in.glflist> -OutPut <out.raw>\n"
		"\n"
		"\t\t-GlfList   <str>   GLF file (soapsnp1.02) input list\n"
		"\t\t-OutPut    <str>   File name of output raw\n"
		"\n"
		"\t\t-Start     <int>   Start position to run[1]\n"
		"\t\t-End       <int>   End position to run[chrEnd]\n"
		"\t\t-help              show this help\n" 
		"\n";
	return 1;
}


int parse_cmd_5(int argc, char **argv ,  ParaClass * para_5)
{
	if (argc <=2 ) {print_usage_5();return 0;}

	for(int i = 1; i < argc ; i++)
	{
		if(argv[i][0] != '-')
		{
			cerr << "command option error! please check." << endl;
			return 0;
		}
		string flag=argv[i] ;
		flag=replace_all(flag,"-","");

		if (flag  == "GlfList" )
		{
			if(i + 1 == argc) { LogLackArg( flag ) ;return 0;}
			i++;
			para_5->InPut1=argv[i];
		}
		else if (flag  ==  "End")
		{
			if(i + 1 == argc) {LogLackArg( flag ) ; return 0;}
			i++;
			para_5->InInt2=atol(argv[i]);
		}
		else if (flag  ==  "Start")
		{
			if(i + 1 == argc) {LogLackArg( flag ) ;return 0;}
			i++;
			para_5->InInt1=atol(argv[i]);
		}
		else if (flag  ==  "OutPut")
		{
			if(i + 1 == argc) {LogLackArg( flag ) ;return 0;}
			i++;
			para_5->OutPut1=argv[i];
		}
		else if (flag  == "help")
		{
			print_usage_5();return 0;
		}
		else
		{
			cerr << "UnKnow argument -"<<flag<<endl;
			return 0;
		}
	}
	if  ((para_5->InPut1).empty() ||  (para_5->OutPut1).empty() )
	{
		cerr<< "lack argument for the must"<<endl ;
		return 0;
	}
	(para_5->InInt1)--;
	return 1 ;
}


int GLFmulti_main(int argc,char *argv[])
{
	ParaClass * para_5 = new ParaClass;
	para_5->InInt1=1;
	if (parse_cmd_5(argc, argv, para_5 )==0)
	{
		delete para_5 ;
		return 0;
	}

	clock_t start_time,finish_time;
	double time_cost=0.0,*log10_prob=NULL,power[256]={0.0},LLR_mat[MAX_FILE_LIST_LEN][10],count[4]={0.0},copyNum=0.0,indi_G_LL=0.0;
	FILE *GLFlist=NULL,*Files[MAX_FILE_LIST_LEN]={NULL};
	int FLAG=0,i=0,j=0,k=0,N_indi=0,N_hap=0,minLLR=0,chrLen=-1,chrLen_tmp=0,LLR[10],total_depth=0,indi_CN=0,indi_dep=0,ref_index=0;
	int type=0,base=0,base1=-1,base2=-1,besttype[3],minor_count=0,est_G=0;
	//    char lo[4]={'\0'},hi[4]={'\0'},chrName[MAX_CHR_NAME_LEN],chrName_tmp[MAX_CHR_NAME_LEN],ref='N',str_name[1024],str_result[1024];
	char chrName[MAX_CHR_NAME_LEN],chrName_tmp[MAX_CHR_NAME_LEN],ref='N',str_name[1024];
	start_time=clock();

	GLFlist=fopen((para_5->InPut1).c_str(),"r");

	while(1)
	{
		if(fgets(str_name,MAX_LIST_NAME_LEN-1,GLFlist)==NULL)
		{
			break;
		}
		else
		{
			if(str_name[strlen(str_name)-1]=='\n')
				str_name[strlen(str_name)-1]='\0';
			Files[FLAG]=fopen(str_name,"rb");
			FLAG++;
		}
	}

	fclose(GLFlist);

	//  output=fopen(argv[2],"w");
	string outfile1=(para_5->OutPut1)+".depth";
	ofstream out_fs(outfile1.c_str());

	para_5->OutPut1=add_Asuffix(para_5->OutPut1);
	ogzstream OUTRaw ((para_5->OutPut1).c_str()); // write_para_4


	map <int,int> Depth_sum ;
	map <int,map<int, int> > Depth ;

	////////////////////////swimming in the sea & flying in the sky /////////////////

	N_indi=FLAG;
	N_hap=2*N_indi;
	minLLR=(int)(20+10*log10((double)N_hap));
	double G_LL[N_hap+1];
	memset(G_LL,0,N_hap+1);
	log10_prob=(double *)malloc(3*(N_hap+1)*sizeof(double));
	Prior_mat_gen(N_hap,log10_prob);
	Log2normal(power);
	if(MAX_FILE_LIST_LEN<N_indi){
		fprintf(stdout,"The number of files in GLFlist should not more than %d\n",MAX_FILE_LIST_LEN-1);
		return 0;
	}
	int chrNum=-1;
	int TTTMP=N_hap-2;
	int chrNum_new=-1;
	for(i=0;i<FLAG;i++){
		if(-1==chrNum){
			Read_header(Files[i],&chrNum);
		}else{
			Read_header(Files[i],&chrNum_new);
			if(chrNum!=chrNum_new)
				fprintf(stdout,"Inconsistent number of chromosomes,only the first chromosome is called.\n");
			chrNum=1;
		}
	}
	fprintf(stdout,"Total chromosomes %d\n",chrNum);
	for(i=0;i<chrNum;i++){
		memset(chrName,'\0',MAX_CHR_NAME_LEN);
		chrLen=-1;
		for(j=0;j<FLAG;j++){
			if(-1==chrLen){
				Read_chr(Files[j],&chrLen,chrName);
			}else{
				Read_chr(Files[j],&chrLen_tmp,chrName_tmp);
				if(chrLen!=chrLen_tmp||strcmp(chrName,chrName_tmp)!=0){
					fprintf(stdout,"ERROR:The files in GLFlist don't have the sanme ChrLen or ChrName!\n");
					return 0;
				}
			}
			fseek(Files[j],12*(para_5->InInt1),1);
		}
		if((para_5->InInt2)<2)
		{
			(para_5->InInt2)=chrLen;
		}   
		if ((para_5->InInt2)>chrLen )
		{
			cerr<<"InPut End Length "<<(para_5->InInt2)<<" biger than chr length "<<chrLen<<". we take the chr length as endLenth InPut"<<endl;
			(para_5->InInt2)=chrLen;
		}

		fprintf(stdout,"%s %d start: %d end: %d\n",chrName,chrLen,(para_5->InInt1)+1,para_5->InInt2);

		for(j=(para_5->InInt1);j<(para_5->InInt2);j++){
			//            if(j>=chrLen){
			//              break;
			//        }
			memset(count,0,4*sizeof(double));
			total_depth=0;
			copyNum=0;
			ref='N';
			for(k=0;k<N_indi;k++){
				ref_index=Read_base(Files[k],&indi_CN,&indi_dep,LLR);
				total_depth+=indi_dep;
				Depth[k][indi_dep]++;
				copyNum+=(indi_dep*(indi_CN+0.5));

				if('N'==ref){
					ref=decode[ref_index];
				}else{
					if(ref!=decode[ref_index]){
						fprintf(stdout,"Error,ref!=decode[ref_index]\n");
						cerr<<"sample "<<k+1<<" : "<<ref<<"\t!=\t"<<decode[ref_index]<<endl;
						return 0;
					}
				}                
				for(type=0;type<10;type++){
					LLR_mat[k][type]=power[LLR[type]];
					if(type<4){
						count[code[type]&3]+=LLR_mat[k][type];
					}else{
						count[code[type]&3]+=LLR_mat[k][type];
						count[(code[type]>>2)&3]+=LLR_mat[k][type];
					}
				}
			}

			base1=-1;base2=-1;
			for(base=0;base<4;base++){
				if(base1==-1||count[base]>count[base1]){
					base2=base1;
					base1=base;
				}else if(base2==-1||count[base]>count[base2]){
					base2=base;
				}else{
					//                   continue;
				}
			}
			memset(G_LL,0,(N_hap+1)*sizeof(double));
			besttype[0]=rev_code[(base1<<2)|base1];
			besttype[1]=rev_code[(base1<<2)|base2];
			besttype[2]=rev_code[(base2<<2)|base2];
			//            for(minor_count=0;minor_count<N_hap+1;minor_count++){
			for(minor_count=0;minor_count<N_hap;minor_count++){
				//                if(minor_count>=N_hap){
				//                    break;
				//                }else{
				G_LL[minor_count]=0.0;
				for(k=0;k<N_indi;k++){
					indi_G_LL=0.0;
					for(type=0;type<3;type++){
						indi_G_LL+=(pow(10,*(log10_prob+minor_count*3+type))*LLR_mat[k][besttype[type]]);
					}
					G_LL[minor_count]+=log10(indi_G_LL);
				}
				//                }
			}
			est_G=0;
			//          est_G=-1;
			for(minor_count=0;minor_count<TTTMP;minor_count++){
				//if(minor_count>=N_hap-2){
				//                    break;
				//                }else{
				if((G_LL[minor_count]>G_LL[minor_count+1])&&(G_LL[minor_count+1]>G_LL[minor_count+2])){
					est_G=minor_count;
					break;
				}
				//                   else{
				//                      continue;
				//                }
				//                }
			}

			//if(est_G==-1){
			//  est_G=0;
			//            }
			if(total_depth!=0){
				copyNum/=total_depth;
			}else{
				copyNum=15;
			}
			Depth_sum[total_depth]++;
			if (total_depth!=0)
			{
				//            fprintf(output,"%s\t%d\t%c\t%d\t%f\t%c\t%c\t%d\t%d\t%d\n",chrName,j+1,ref,total_depth,copyNum,"ACTG"[base1],"ACTG"[base2],N_hap-est_G,est_G,(int)(10*(G_LL[est_G]-G_LL[0])+0.5));
				char REF="ACTG"[base1];
				char ALT="ACTG"[base2];
				int SNPQ=(int)(10*(G_LL[est_G]-G_LL[0])+0.5);
				OUTRaw<<setiosflags(ios::fixed)<<setiosflags(ios::right)<<setprecision(6)<<chrName<<"\t"<<(j+1)<<"\t"<<ref<<"\t"<<total_depth<<"\t"<<copyNum<<"\t"<<REF<<"\t"<<ALT<<"\t"<<N_hap-est_G<<"\t"<<est_G<<"\t"<<SNPQ<<endl;
			}
			else
			{
				char REF="ACTG"[base1];
				char ALT="ACTG"[base2];
				OUTRaw<<setiosflags(ios::fixed)<<setiosflags(ios::right)<<setprecision(6)<<chrName<<"\t"<<(j+1)<<"\t"<<ref<<"\t0\t15.00000\t"<<REF<<"\t"<<ALT<<"\t"<<N_hap<<"\t0\t0"<<endl;
				//fprintf(output,"%s\t%d\t%c\t%d\t%f\t%c\t%c\t%d\t%d\t%d\n",chrName,j+1,ref,total_depth,copyNum,ref,"ACTG"[base2],N_hap,0,0);
			}
		}
		cout<<"Finished chrName: "<<chrName<<endl;
		}
		for(i=1;i<FLAG;i++){
			fclose(Files[i]);
			//   Depth[N_indi][indi_dep]++;
		}

		OUTRaw.close();

		out_fs<<"#depth\tnumber"<<endl;
		out_fs<<">#####Glf_sample\tAll_sample_Depth\t#########"<<endl;
		map  <int,int> ::const_iterator map_it=Depth_sum.begin();

		while(map_it!=Depth_sum.end())
		{
			out_fs<<map_it->first<<"\t"<<map_it->second<<endl;
			map_it++;
		}

		map <int,map<int, int> > ::const_iterator outerit=Depth.begin();
		map<int,int > ::const_iterator innerit ;


		for(outerit=Depth.begin() ; outerit!=Depth.end(); outerit++)
		{
			out_fs<<">#####Glf_sample\t"<<(outerit->first+1)<<"\t#########"<<endl;
			for(innerit=outerit->second.begin() ; innerit!=outerit->second.end();  innerit++)
			{
				out_fs<<innerit->first<<"\t"<<innerit->second<<endl;
			}
		}
		out_fs.close();
		finish_time=clock();
		time_cost=(double)(finish_time-start_time)/CLOCKS_PER_SEC;
		cout<<"Misson complete!"<<endl;
		cout<<"total time cost is: "<<time_cost<<"seconds"<<endl;
		//	fprintf(stdout,"total time cost is:%f seconds\n",time_cost);
		//
		delete para_5 ;
		return 0 ;
	}

	////////////////////////swimming in the sea & flying in the sky //////////////////
