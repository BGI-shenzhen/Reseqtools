#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <map>
#include "../ALL/comm.h"
#include <cstdlib>
#include "../include/gzstream/gzstream.C"
using namespace std;
typedef long long llong ;


class Para_Xam04 {
	public:
		string input_Sam ;
		string input_Bam ;
		string OutPut ;
		string Dict ;
		llong start ;
		llong end ;
		string chr;
		int minLeng ;
		int minMapQ ;
		int maxHit ;
		bool TF ;

		Para_Xam04()
		{
			start=0;
			end=100000000;
			minLeng=30 ;
			minMapQ =15 ;
			maxHit=1 ;
			TF=false;
			chr="";
			Dict="";
		}
};




int  print_Ausage_Xam04()
{
	cout <<""
		"\n"
		"\tUsage: filter -InBam <in.bam> \n"
		"\n"
		"\t\t-InSam     <str>   InPut Sam File\n"
		"\t\t-InBam     <str>   InPut Bam File\n"
		"\n"
		"\t\t-OutPut    <str>   OutPut file/file.gz,or [STDOUT]\n"
		"\t\t-MinMapQ   <int>   The min Bwa Mapping Q [15]\n" 
		"\t\t-MaxHit    <int>   The max Bwa Mapping Hit[1]\n" 
		"\t\t-MinLeng   <int>   the min length of read[30]\n" 
		"\t\t-Start     <int>   the start position out[0]\n" 
		"\t\t-End       <int>   the end position out[1e8]\n" 
		"\t\t-Chr       <str>   only the [chr] out[all]\n"
		"\t\t-SamNoHead         if the file is Sam with NoHead\n"
		"\t\t-Dict      <str>   Input Sam Head file\n"
		"\n"
		"\t\t-help              show this help\n" 
		"\n";
	return 1;
}


int parse_Acmd_Xam04(int argc, char **argv, Para_Xam04 * para_Xam04)
{
	if (argc <=2 ) {print_Ausage_Xam04();return 0;}

	for(int i = 1; i < argc ; i++)
	{
		if(argv[i][0] != '-')
		{
			cerr << "command option error! please check." << endl;
			return 0;
		}
		string flag=argv[i] ;
		flag=replace_all(flag,"-","");

		if (flag  == "InSam" )
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_Xam04->input_Sam=argv[i];
		}
		else if (flag  == "InBam" )
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_Xam04->input_Bam=argv[i];
		}
		else if (flag  ==  "OutPut")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0; }
			i++;
			para_Xam04->OutPut=argv[i];
		}
		else if (flag  ==  "Dict")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_Xam04->Dict=argv[i];
		}
		else if (flag  ==  "Chr")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0; }
			i++;
			para_Xam04->chr=argv[i];
		}
		else if (flag  ==  "MinMapQ")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_Xam04->minMapQ=atoi(argv[i]);
		}
		else if (flag  ==  "MaxHit")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_Xam04->maxHit=atoi(argv[i]);
		}
		///* 
		else if (flag  ==  "MinLeng")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			para_Xam04->minLeng=atoi(argv[i]);
		}
		///*////
		else if (flag  ==  "End")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_Xam04->end=atol(argv[i]);
		}
		else if (flag  ==  "Start")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0; }
			i++;
			para_Xam04->start=atol(argv[i]);
		}
		else if (flag  == "help")
		{
			print_Ausage_Xam04();return 0;
		}
		else if (flag  == "SamNoHead")
		{
			para_Xam04->TF=true ;  
		}
		else
		{
			cerr << "UnKnow argument -"<<flag<<endl;
			return 0;
		}
	}
	if  ((para_Xam04->input_Sam).empty() && (para_Xam04->input_Bam).empty() )
	{
		cerr<< "lack argument for the must"<<endl ;
		return 0;    
	}
	if (para_Xam04->TF)
	{
		if ((para_Xam04->input_Sam).empty())
		{
			cerr<<"-SamNoHead should be the with -InSam"<<endl;
			return 0;
		}
	}
	return 1 ;
}


bool Sam_filter ( string line , Para_Xam04 * para_Xam04  )
{
	vector<string> inf;
	split(line,inf," \t");
	int Read_leng=atoi(inf[4].c_str()) ;
	if (Read_leng<(para_Xam04->minMapQ)) { return  false ; }
	llong position=atol(inf[3].c_str());
	if (position<(para_Xam04->start)) { return  false ; }
	if (position>(para_Xam04->end)) { return  false ; }
	Tcount_indel_len(inf[5],Read_leng,inf[9],inf[10]);
	Read_leng=inf[9].size();
	if (Read_leng<(para_Xam04->minLeng)) { return  false ;}
	int vec_size=inf.size();
	Read_leng = 1 ;

	for (int i = 11; i < vec_size; i++) {
		if (inf[i].find(HIT_COUNT_H0) != std::string::npos) {
			Read_leng = atoi(inf[i].substr(5).c_str());
			break;
		} else if (inf[i].find(HIT_COUNT_X0) != std::string::npos) {
			Read_leng = atoi(inf[i].substr(5).c_str());
			break;
		}
	}

	if (Read_leng>(para_Xam04->maxHit)) { return  false ;}

	if ((para_Xam04->chr).empty())
	{
		return true ;
	}
	else
	{
		if (inf[2]!=(para_Xam04->chr)) {  return  false ;}
		else {return true ;}
	}
}


//programme entry
///////// swimming in the sky and flying in the sea ////////////
int Xam_Filter_main(int argc, char **argv)
{
	Para_Xam04 * para_Xam04 = new Para_Xam04;
	if (parse_Acmd_Xam04(argc, argv , para_Xam04 )==0)
	{
		delete para_Xam04 ; 
		return 0 ;
	}

	if ((para_Xam04->TF))
	{
		igzstream INS ((para_Xam04->input_Sam).c_str(),ifstream::in);
		if (INS.fail())
		{
			cerr<<"can't open file\t"<<(para_Xam04->input_Sam)<<endl;
			return 0 ;
		}
		if (((para_Xam04->OutPut).empty()) )
		{
			while(!INS.eof())
			{
				string  line ,chr ,tmp;
				getline(INS,line);
				if (line.length()<=0)  { continue  ; }
				if ( Sam_filter (line , para_Xam04  ) )
				{
					cout<<line<<endl;
				}
			}
		}
		else
		{
			ogzstream  OUT (para_Xam04->OutPut.c_str());            
			if(!OUT.good())
			{
				cerr << "open OUT File error: "<<para_Xam04->OutPut<<endl;
				return 0 ;
			} 
			if (!(para_Xam04->Dict).empty())
			{
				Write_Sam_head (para_Xam04->Dict, OUT) ;
			}
			while(!INS.eof())
			{
				string  line ,chr ,tmp;
				getline(INS,line);
				if (line.length()<=0)  { continue  ; }
				if ( Sam_filter (line , para_Xam04  ) )
				{
					OUT<<line<<endl;
				}
			}
			OUT.close();
		}
		INS.close();
	}
	else
	{
		char in_mode[5] ={ 0 };     in_mode[0]='r';
		TSamCtrl IN;
		if (!((para_Xam04->input_Sam).empty()))
		{
			IN.open((para_Xam04->input_Sam).c_str(),in_mode);
		}
		else
		{
			in_mode[1]='b';
			IN.open((para_Xam04->input_Bam).c_str(),in_mode);
		}
		if (((para_Xam04->OutPut).empty()) )
		{
			string  line ;
			while(IN.readline(line)!=-1)
			{
				if ( Sam_filter (line , para_Xam04  ) )
				{
					cout<<line<<endl;
				}
			}
		}
		else if ((!(para_Xam04->OutPut).empty()) )
		{
			para_Xam04->OutPut=add_Asuffix(para_Xam04->OutPut);                
			ogzstream  OUT (para_Xam04->OutPut.c_str());
			if (!(para_Xam04->Dict).empty())
			{
				Write_Sam_head (para_Xam04->Dict, OUT) ;
			}
			if(!OUT.good())
			{
				cerr << "open OUT File error: "<<para_Xam04->OutPut<<endl;
				return 0 ;
			} 
			string  line ;
			while(IN.readline(line)!=-1)
			{
				if ( Sam_filter (line , para_Xam04 ) )
				{
					OUT<<line<<endl;
				}
			}
			OUT.close();
		}
		IN.close();
	}

	delete para_Xam04 ;
	return 0;
}

///////// swimming in the sky and flying in the sea ////////////
