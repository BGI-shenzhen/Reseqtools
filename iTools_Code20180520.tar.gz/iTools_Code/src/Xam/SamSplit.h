#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <map>
#include <cmath>
#include <cstdlib>
#include "../ALL/comm.h"
#include "../Soap/Soap_Split.h"
#include "../ALL/kseq.h"
#include "../ALL/DataClass.h"
#include "../Soap/xam2soap/TSamCtrl.h"
#include "../Soap/xam2soap/Ttools.h"
#include "../include/gzstream/gzstream.C" 
using namespace std;
using namespace __gnu_cxx;

typedef long long llong ;

///////////////////
int  print_Xam01()
{
	cout <<""
		"\n"
		"\tUsage: split -Ref <Ref.fa> -InFile <in1.sam> -InFile <in2.sam> \n"
		"\n"
		"\t\t-Ref       <str>   Input the Ref seq\n"
		"\t\t-InFile    <str>   [Repeat] Input sam,bam file\n"
		"\t\t-InList    <str>   Input sam,bam file list\n"
		"\t\t\n"
		"\t\t-OutDir    <str>   Output Dir for split sam [./]\n"
		"\t\t-Bam               if the file is Bam format\n"
		"\t\t-SamNoHead         if the InPut Sam with NoHead\n"
		"\t\t-OutHead           if you want OutPut Sam with SamHead\n"
		"\t\t-help              show this help\n"
		"\n";
	return 1;
}

int parse_Xam01(int argc, char **argv , In3str1v * para_Xam01 )
{
	if (argc <=2 ) {print_Xam01();return 0;}

	for(int i = 1; i < argc ; i++)
	{
		if(argv[i][0] != '-')
		{
			cerr << "command option error! please check." << endl;
			return 0;
		}
		string flag=argv[i] ;
		flag=replace_all(flag,"-","");

		if (flag  == "Ref")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_Xam01->InStr1=argv[i];
		}
		else if (flag  ==  "InFile")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			string tmp=argv[i];
			(para_Xam01->List).push_back(tmp);
		}
		else if (flag  ==  "OutHead")
		{
			(para_Xam01->InInt)=8;
		}        
		else if (flag  ==  "OutDir")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			(para_Xam01->InStr2)=argv[i];
		}
		else if (flag  ==  "InList" )
		{
			if(i + 1 == argc) { LogLackArg(flag);return 0; }
			i++;
			string tmp=argv[i];
			ReadList (tmp  , (para_Xam01->List) );
		}
		else if (flag  == "Bam" || flag  == "bam" )
		{
			(para_Xam01->TF)=false ;
		}
		else if (flag  == "SamNoHead" )
		{
			(para_Xam01->TF2)=false ;
		}
		else if (flag  == "help")
		{
			print_Xam01();return 0;
		}
		else
		{
			cerr << "UnKnow argument -"<<flag<<endl;
			return 0;
		}
	}

	if  (((para_Xam01->List).size()<1) ||  (para_Xam01->InStr1).empty() )
	{
		cerr<< "lack argument for the must"<<endl ;
		return 0;
	}

	return 1 ;
}

/*//////////////////
  void  changid ( string & str  , llong  id ,int sam_count )
  {
  stringstream ss ;
  ss<<sam_count<<"-"<<id;
  str.replace(0,str.find("\t"),ss.str());
  }

  void  changid ( string & str1 , string  str2  , llong & id  , int sam_count )
  {
  stringstream ss ;
  ss<<sam_count<<"-"<<id;
  str1.replace(0,str1.find("\t"),ss.str());
  str2.replace(0,str2.find("\t"),ss.str());
  }
//*///
//////////////////
int Xam_split_main(int argc,char *argv[])
{

	In3str1v  * para_Xam01 = new In3str1v ;
	(para_Xam01->InStr2)="./";
	if (parse_Xam01( argc, argv, para_Xam01)==0)
	{
		delete para_Xam01 ;
		return 0;
	}

	//    string  OutDir=(para_Xam01->InStr2);

	vector <string> File ;
	map <string,int>  Soap2Int ;
	int File_count=ReadChrInfo ((para_Xam01->InStr1),(para_Xam01->InStr2), File , Soap2Int);

	if (File_count>168)
	{
		cerr<<"Waining :chr num too much"<<endl;
	}
	ogzstream *Soap2Chr = new ogzstream[File_count];

	for (int i=0; i<File_count ; i++)
	{
		string aaa=File[i]+".sam.gz" ;
		Soap2Chr[i].open(aaa.c_str());
		if  (!Soap2Chr[i].good())
		{
			cerr<<"Can't open follow output:\n"<<File[i]<<endl;
		}
	}

	if ((para_Xam01->InInt)==8)
	{
		gzFile fp;
		kseq_t *seq;
		int l;
		fp = gzopen((para_Xam01->InStr1).c_str(), "r");
		seq = kseq_init(fp);
		
		while ((l = kseq_read(seq)) >= 0)
		{
			string chr=(seq->name.s);
			map  <string,int> :: iterator map_it=Soap2Int.find(chr);
			if (map_it!=Soap2Int.end())
			{
			Soap2Chr[map_it->second]<<"@SQ\tSN:"<<chr<<"\tLN:"<<(seq->seq.l)<<"\n";
			}
		}
		kseq_destroy(seq);
		gzclose(fp);
	}


	int Soap_Stat_count=(para_Xam01->List).size();

	if ((para_Xam01->TF2))
	{
		char in_mode[5] ={ 0 };
		in_mode[0]='r';
		if (!(para_Xam01->TF) )
		{
			in_mode[1]='b';
		}
		for (int i=0; i<Soap_Stat_count ; i++)
		{
			string sampath=(para_Xam01->List)[i]; 
			TSamCtrl samhandle;
			samhandle.open(sampath.c_str(),in_mode);
			string line;
			while(samhandle.readline(line)!=-1)
			{
				vector<string> inf;
				split(line,inf," \t");
				if ( (inf.size() < 11) || (inf[5] == "*"))
				{
					continue ;
				}
				map  <string,int> :: iterator map_it=Soap2Int.find(inf[2]);
				if (map_it!=Soap2Int.end())
				{
					Soap2Chr[map_it->second]<<line<<"\n";
				}
			}
		}
	}
	else
	{
		for (int i=0; i<Soap_Stat_count ; i++)
		{
			string sampath=(para_Xam01->List)[i];
			igzstream IN (sampath.c_str(),ifstream::in);
			while(!IN.eof())
			{
				string  line ,chr ,tmp;
				getline(IN,line);
				if (line.length()<=0)  { continue  ; }
				istringstream isone (line,istringstream::in);
				isone>>tmp>>tmp;     
				isone>>chr;
				map  <string,int> :: iterator map_it=Soap2Int.find(chr);
				if (map_it!=Soap2Int.end())
				{
					Soap2Chr[map_it->second]<<line<<"\n";
				}
			}
			IN.close();
			IN.clear();
		}
	}

	for (int i=0; i<File_count ; i++)
	{
		Soap2Chr[i].close() ;    
	}

	delete para_Xam01 ;
	delete [] Soap2Chr ;
	//////////swimming in the sky and flying in the sea ///////////

	return 0 ;
}


////////////////////////swimming in the sea & flying in the sky //////////////////


