#!/usr/bin/perl

=head1 Name

 gff2psl.pl

=head1 Description

 Translate gff file to psl file.(*.gff --> *.psl). 
 New psl file will be in the current dir.
 The third row of each line of the gff file must be one of the words below,'mRNA' 'CDS'.

 Warning: just fits for some type of gff file.

=head1 Author

 He Zengquan Email: hezengquan@genomics.org.cn
 Zhang Jinbo Email: zhangjinbo@genomics.org.cn

 Data: 2010-03-02

=head1 Usage

 perl gff2psl.pl /home/example.gff

=cut

use strict;

die `pod2text $0` if (@ARGV!=1);

my $result=$ARGV[0].'.psl';
my $id=$ARGV[0].'.id';

################### main function #####################

my ($tName,$qName,$strand,$qSize,$gid,$tStart,$tEnd,$blockCount)=();

my %block;  ## $block{start}=length

open STDIN,'<',$ARGV[0] || die "Can't open $ARGV[0]!\n";
open ID,'>',$id || die "Can't create $id!\n";
open PSL,'>',$result || die "Can't create $result!\n";
while (<STDIN>) {
	next if(/^\s*$/);
	chomp;
	my @temp=split /\s+/,$_;
	next if(@temp<9);

	#if($temp[2] eq 'mRNA'){
	## changed by zhangjinbo
	if($temp[2] =~/RNA/ ){
		if( scalar(keys%block)>0 ){
			myPrint();
		}
		else{
			($tName,$qName,$strand,$qSize,$gid,$tStart,$tEnd,$blockCount)=();
		}
		$tName=$temp[0];
		($qName,$gid)=GetQName($temp[8]);
		$strand=$temp[6];
	}

	elsif ($temp[2] eq 'CDS' || $temp[2] eq 'five_prime_UTR' || $temp[2] eq 'three_prime_UTR'){
		my ($blockStart,$blockSize);
		if($temp[3]<=$temp[4]){
			$blockStart=$temp[3]-1;
			$blockSize=$temp[4]-$temp[3]+1;
		}
		elsif($temp[3]>$temp[4]){
			$blockStart=$temp[4]-1;
			$blockSize=$temp[3]-$temp[4]+1;
		}
		else{
			die "$temp[0]\t$temp[1]\t$temp[3]\t$temp[4]\n";
		}

		$qSize+=$blockSize;
		$blockCount+=1;
		$block{$blockStart}=$blockSize;
	}

}
myPrint();

print STDERR "$result has been done at ".`date`;

close STDIN;
close PSL;
close ID;

################### sub function ######################
#Find the query name from gff.
#usage: $qName=&GetQName($string);
my $g;
sub GetQName{
	my $string=shift;
	my $a=$1 if($string=~/^([^;]+)/);
	$a=$1 if($a=~/ID=(.*)/); ## add by zhangjinbo
	if ($a=~/(.*)\.(.*)/){
		$g=$1;
	}else{
		$g=$a;
	}
	#my $g=$1 if($a=~/(.*)\.(.*)/);
	($a,$g);
}
#############################################
#Print to psl file.

sub myPrint{
	print ID "$gid\t$qName\n";
	my @tStarts=sort {$a<=>$b} keys %block;
	my $check = 1;
	while(@tStarts>1 && $check==1){
		$check = 0;
		foreach my $i(1..$#tStarts){
			if($tStarts[$i-1]+$block{$tStarts[$i-1]}==$tStarts[$i]){
				$check = 1;
				$block{$tStarts[$i-1]}+=$block{$tStarts[$i]};
				delete $block{$tStarts[$i]};
				splice(@tStarts,$i,1);
			}
		}
	}
	$tStart=$tStarts[0];
	$tEnd=$tStarts[-1]+$block{$tStarts[-1]};
	$blockCount = scalar(@tStarts);
	print PSL "0\t";         #matches=0
	print PSL "0\t";         #misMatches=0
	print PSL "0\t";         #repMatches=0
	print PSL "0\t";         #nCount=0
	print PSL "0\t";         #qNumInsert=0
	print PSL "0\t";         #qBaseInsert=0
	print PSL "0\t";         #tNumInsert=0
	print PSL "0\t";         #tBaseInsert=0
	print PSL "$strand\t";   #strand
	print PSL "$qName\t";    #qName
	print PSL "$qSize\t";    #qSize
	print PSL "0\t";         #qStart
	print PSL "0\t";         #qEnd
	print PSL "$tName\t";    #tName
	print PSL "0\t";         #tSize
	print PSL "$tStart\t";   #tStart
	print PSL "$tEnd\t";     #tEnd
	print PSL "$blockCount\t"; #blockCount
	foreach (@tStarts) {
		print PSL $block{$_}.",";    #blockSizes
	}
	print PSL "\t";
	foreach (@tStarts) {
		print PSL "0,";    #qStarts
	}
	print PSL "\t";
	foreach (@tStarts) {
		print PSL $_.",";    #tStarts
	}
	print PSL "\n";

	($tName,$qName,$strand,$qSize,$gid,$tStart,$tEnd,$blockCount)=();
	@tStarts=();
	foreach  (keys %block) {
		delete $block{$_};
	}
}
