#ifndef Allgenotype_H_
#define Allgenotype_H_

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <vector>
#include <map>
#include <cstdlib>
#include "../include/zlib/zlib.h"
#include <iomanip>
#include <stdio.h>
#include "../ALL/kseq.h"
#include "../ALL/comm.h"
#include "../ALL/DataClass.h"
#include "../ALL/rank_sum.cc"
#include "../Soap/xam2soap/TSamCtrl.h"
#include "../Soap/xam2soap/Ttools.h"
#include <stdio.h>
#include "../ALL/kseq.h"
#include "../Xam/Alg_View.h"

#include "../include/gzstream/gzstream.C"
#define NOUSE_ALIGNMENT "alignment is no use"

//KSEQ_AINIT(gzFile, gzread) 
using namespace std;

typedef char Base;
typedef unsigned long long ubit64_t;
typedef long double  LDBL;

int  print_usage_A21()
{
	cout <<""
		"\n"
		"\tUsage: Alg2geno -InSoap <In.soap> -Ref <Ref.fa> -OutPut <Out.geno>\n"
		"\n"
		"\t\t-InSoap      <str>   Input SortSoap file for Genotype\n"
		"\t\t-InBam       <str>   Input SortBam for Genotype\n"
		"\t\t-InSam       <str>   Input SortSam for Genotype\n"
		"\t\t-Ref         <str>   Input Ref seq\n"  
		"\t\t-OutPut      <str>   Out Put genotype file\n"
		"\n"
		"\t\t-MinMapQ     <int>   The minimum Bwa Mapping quality [15]\n"
		"\t\t-NOFiGap             No Filter Bwa Del or Inset(Gap) Reads [NA]\n"
		"\t\t-BaseFilter  <int>   The minimum Base quality to pass [15]\n"
		"\t\t-HET       <float>   Novel HET prior probability [0.0010]\n"
		"\t\t-Haploid             If the specie is haploid or chrY [diploid]\n"
		"\n" 
		"\t\t-help                show this help\n" 
		"\n";
	return 1;
}

int parse_cmd_A21(int argc, char **argv , ParaClass * para_A21 )
{
	if (argc <=2 ) {print_usage_A21();return 0; }

	for(int i = 1; i < argc ; i++)
	{
		if(argv[i][0] != '-')
		{
			cerr << "command option error! please check." << endl;
			return 0;
		}
		string flag=argv[i] ;
		flag=replace_all(flag,"-","");

		if (flag  == "InSoap" )
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_A21->InPut1=argv[i];
			para_A21->InUnInt1=1 ;
		}
		else if (flag  == "InSam" )
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			para_A21->InStr3=argv[i];
			para_A21->InUnInt1=2 ;
		}
		else if (flag  == "InBam" )
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			para_A21->InStr2=argv[i];
			para_A21->InUnInt1=3 ;
		}
		else if (flag  ==  "OutPut")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			para_A21->OutPut1=argv[i];
		}
		else if (flag  ==  "MinMapQ")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			para_A21->InInt3=atoi(argv[i]) ;
		}
		else if (flag  ==  "BaseFilter")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_A21->InInt2=atoi(argv[i]) ;
		}
		else if (flag  ==  "Ref")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			para_A21->InStr1=argv[i];
		}
		else if (flag  == "Haploid")
		{
			para_A21->InInt1=1;
		}
		else if (flag  == "NOFiGap")
		{
			para_A21->TF=false;
		}
		else if (flag  == "help")
		{
			print_usage_A21();return 0;
		}
		else
		{
			cerr << "UnKnow argument -"<<flag<<endl;
			return 0;
		}
	}
	if((para_A21->InStr1).empty()||  (para_A21->InUnInt1)==0 ||(para_A21->OutPut1).empty())
	{
		cerr<< "lack argument for the must"<<endl ;
		return 0;
	}

	(para_A21->OutPut1)=add_Asuffix(para_A21->OutPut1) ;

	return 1 ;

}



//////////



int Genotype_Arg(ubit64_t Chr_Length , string ChrSeq ,  string & chr  ,igzstream & IN ,ogzstream & OUT , string & linesoap , ParaClass * para_A21 )
{
	int WindosL=500000, maxReadLength=200;
	int bin=WindosL+3*maxReadLength;
	int windos_Alen=WindosL;
	int minQ=(para_A21->Inchar1)+0;


	double *p_rank;
	p_rank=rank_table_gen();
	int *same_qual_count = new int [256];
	double *rank_array = new double [256];
	memset(same_qual_count,0,sizeof(int)*256);
	memset(rank_array,0,sizeof(double)*256);


	//  int windos_Amax=bin-1*maxReadLength ;
	ubit64_t  sliding_Acount=ubit64_t((Chr_Length)/(windos_Alen))+1 ;    
	Site *BaseSite= new Site[bin];
	string  Nowchr ;


	for (ubit64_t  ii = 0 ; ii < sliding_Acount  ; ii++ )
	{   
		ubit64_t Start_Ai=ii*windos_Alen ;
		ubit64_t End_Ai=Start_Ai+windos_Alen ;
		ubit64_t position=Start_Ai ;
		string ID , seq ,Qseq ,ab , zf  ;
		int hit , Read_leng ;

		istringstream isoneA (linesoap,istringstream::in);        
		isoneA>>ID >> seq >> Qseq >> hit >> ab >> Read_leng >> zf >> Nowchr >> position ;

		while( (!IN.eof()) && position<=End_Ai  &&  Nowchr==chr ) 
		{
			istringstream isone (linesoap,istringstream::in);
			isone >>ID>>seq >> Qseq >> hit >> ab >> Read_leng >> zf >> Nowchr >> position ;
			int Stat_vetor=position - Start_Ai-1 ;
			if (Stat_vetor>windos_Alen) { break ;}
			for(int jj=0 ; jj<Read_leng ; jj++)
			{
				int key_depth= Stat_vetor  + jj  ;
				if (( (Qseq[jj])-(para_A21->Inchar1) )>(para_A21->InInt2))
				{
					(BaseSite[key_depth]).Add_Quality (seq[jj],Qseq[jj] ,hit) ;
				}
			}
			getline(IN, linesoap ) ;
		}

		if (End_Ai>(Chr_Length))
		{
			End_Ai=Chr_Length;
		}

		if ((para_A21->InInt1)==0)
		{
			for (ubit64_t  Refposi = Start_Ai   ; Refposi < End_Ai ; Refposi++ )
			{
				int ie=Refposi-Start_Ai ;
				char RefBaseSite=ChrSeq[Refposi];
				char AltBase='N';
				int RefNum=((RefBaseSite>>1)&3);
				int Ref_length=0 ,  Alt_length=0 , SumDepth =0 ;
				double MeanHit=25.0 ;
				int AltNum=(BaseSite[ie]).get_Two_allele(RefNum ,AltBase , Ref_length ,Alt_length );
				MeanHit=(BaseSite[ie]).get_mean_hit(SumDepth) ;
				if (Alt_length==0)
				{
					OUT<<chr<<"\t"<<Refposi+1<<"\t"<<RefBaseSite<<"\t"<<SumDepth<<setiosflags(ios::fixed)<<setiosflags(ios::right)<<setprecision(2)<<"\t"<<MeanHit<<"\t1.00000\t"<<RefBaseSite<<(BaseSite[ie]).get_q(RefNum)<<"\t"<<"N"<<"\n"; 
				}
				else if (Ref_length==0)
				{
					OUT<<chr<<"\t"<<Refposi+1<<"\t"<<AltBase<<"\t"<<SumDepth<<"\t"<<setiosflags(ios::fixed)<<setiosflags(ios::right)<<setprecision(2)<<MeanHit<<"\t1.00000\t"<<RefBaseSite<<"\t"<<AltBase<<(BaseSite[ie]).get_q(AltNum)<<"\n";
				}
				else
				{
					string FinalBase=(BaseSite[ie]).Genotype_Likelihood(RefNum ,AltNum,Ref_length ,  Alt_length ,minQ , para_A21->Indouble );
					double  RST=rank_test(BaseSite[ie], p_rank, same_qual_count, rank_array, para_A21->Inchar1 , RefNum,AltNum );
					OUT<<chr<<"\t"<<Refposi+1<<"\t"<<FinalBase<<"\t"<<SumDepth<<"\t"<<setiosflags(ios::fixed)<<setiosflags(ios::right)<<setprecision(2)<<MeanHit<<"\t"<<setprecision(5)<<RST<<"\t"<<RefBaseSite<<(BaseSite[ie]).get_q(RefNum)<<"\t"<<AltBase<<(BaseSite[ie]).get_q(AltNum)<<"\n";
				}
				(BaseSite[ie]).Destory_Site();
			}
		}
		else
		{

			for (ubit64_t  Refposi = Start_Ai   ; Refposi < End_Ai ; Refposi++ )
			{
				int ie=Refposi-Start_Ai ;
				char RefBaseSite=ChrSeq[Refposi];
				char AltBase='N';
				int RefNum=((RefBaseSite>>1)&3);
				int Ref_length=0 ,  Alt_length=0 , SumDepth =0 ;
				double MeanHit=25.0 ;
				int AltNum=(BaseSite[ie]).get_Two_allele(RefNum ,AltBase , Ref_length ,Alt_length );
				MeanHit=(BaseSite[ie]).get_mean_hit(SumDepth) ;
				if (Alt_length==0)
				{
					OUT<<chr<<"\t"<<Refposi+1<<"\t"<<RefBaseSite<<"\t"<<SumDepth<<setiosflags(ios::fixed)<<setiosflags(ios::right)<<setprecision(2)<<"\t"<<MeanHit<<"\t1.00000\t"<<RefBaseSite<<(BaseSite[ie]).get_q(RefNum)<<"\t"<<"N"<<"\n"; 
				}
				else if (Ref_length==0)
				{
					OUT<<chr<<"\t"<<Refposi+1<<"\t"<<AltBase<<"\t"<<SumDepth<<"\t"<<setiosflags(ios::fixed)<<setiosflags(ios::right)<<setprecision(2)<<MeanHit<<"\t1.00000\t"<<RefBaseSite<<"\t"<<AltBase<<(BaseSite[ie]).get_q(AltNum)<<"\n";
				}
				else
				{
					string FinalBase=(BaseSite[ie]).Genotype_Likelihood(RefNum ,AltNum,Ref_length ,  Alt_length ,minQ );
					double  RST=rank_test(BaseSite[ie], p_rank, same_qual_count, rank_array, para_A21->Inchar1 , RefNum,AltNum );
					OUT<<chr<<"\t"<<Refposi+1<<"\t"<<FinalBase<<"\t"<<SumDepth<<"\t"<<setiosflags(ios::fixed)<<setiosflags(ios::right)<<setprecision(2)<<MeanHit<<"\t"<<setprecision(5)<<RST<<"\t"<<RefBaseSite<<(BaseSite[ie]).get_q(RefNum)<<"\t"<<AltBase<<(BaseSite[ie]).get_q(AltNum)<<"\n";
				}
				(BaseSite[ie]).Destory_Site();
			}
		}

		for( int ie=windos_Alen; ie<bin ; ie++ )
		{
			int tmpj=ie-windos_Alen;
			(BaseSite[tmpj]).CopySame((BaseSite[ie]));
			(BaseSite[ie]).Destory_Site();
		}
	}

	delete [] BaseSite ;
	delete [] same_qual_count ;
	delete [] rank_array ; 
	/// print out ///
	chr=Nowchr ;
	if ( (!IN.eof()) ) 
	{
		return 1 ;
	}
	else
	{
		return 0 ;
	}
}





//////////////////////////////////

int Genotype_Arg(ubit64_t Chr_Length , string ChrSeq ,  string & chr  , TSamCtrl  & Alignment  ,ogzstream & OUT , string & linesoap , ParaClass * para_A21 )
{
	int WindosL=500000, maxReadLength=200;
	int bin=WindosL+3*maxReadLength;
	int windos_Alen=WindosL;
	int minQ=(para_A21->Inchar1)+0;


	double *p_rank;
	p_rank=rank_table_gen();
	int *same_qual_count = new int [256];
	double *rank_array = new double [256];
	memset(same_qual_count,0,sizeof(int)*256);
	memset(rank_array,0,sizeof(double)*256);

	//  int windos_Amax=bin-1*maxReadLength ;
	ubit64_t  sliding_Acount=ubit64_t((Chr_Length)/(windos_Alen))+1 ;    
	Site *BaseSite= new Site[bin];
	string  Nowchr ;

	for (ubit64_t  ii = 0 ; ii < sliding_Acount  ; ii++ )
	{
		ubit64_t Start_Ai=ii*windos_Alen ;
		ubit64_t End_Ai=Start_Ai+windos_Alen ;
		ubit64_t position=Start_Ai ;
		string ID , seq ,Qseq ,ab , zf  ;
		int hit , Read_leng ;

		istringstream isoneA (linesoap,istringstream::in);        
		isoneA>>ID >> seq >> Qseq >> hit >> ab >> Read_leng >> zf >> Nowchr >> position ;
		while( (Alignment.isOpened()) && position<=End_Ai  &&  Nowchr==chr ) 
		{
			istringstream isone (linesoap,istringstream::in);
			isone >>ID>>seq >> Qseq >> hit >> ab >> Read_leng >> zf >> Nowchr >> position ;
			int Stat_vetor=position - Start_Ai-1 ;
			if (Stat_vetor>windos_Alen) { break ;}
			for(int jj=0 ; jj<Read_leng ; jj++)
			{
				int key_depth= Stat_vetor  + jj  ;
				if (( (Qseq[jj])-(para_A21->Inchar1) )>(para_A21->InInt2))
				{
					(BaseSite[key_depth]).Add_Quality (seq[jj],Qseq[jj] ,hit) ;
				}
			}
			while(Alignment.readline(linesoap)!=-1 )
			{
				linesoap=Talignment_format_filter(linesoap, para_A21->InInt3 ,para_A21->TF);
				if(linesoap.compare(NOUSE_ALIGNMENT)==0)
				{
					continue;
				}
				else
				{
					break;
				}
			}
		}

		if (End_Ai>(Chr_Length))
		{
			End_Ai=Chr_Length;
		}

		if ((para_A21->InInt1)==0)
		{
			for (ubit64_t  Refposi = Start_Ai   ; Refposi < End_Ai ; Refposi++ )
			{
				int ie=Refposi-Start_Ai ;
				char RefBaseSite=ChrSeq[Refposi];
				char AltBase='N';
				int RefNum=((RefBaseSite>>1)&3);
				int Ref_length=0 ,  Alt_length=0 , SumDepth =0 ;
				double MeanHit=25.0 ;
				int AltNum=(BaseSite[ie]).get_Two_allele(RefNum ,AltBase , Ref_length ,Alt_length );
				MeanHit=(BaseSite[ie]).get_mean_hit(SumDepth) ;
				if (Alt_length==0)
				{
					OUT<<chr<<"\t"<<Refposi+1<<"\t"<<RefBaseSite<<"\t"<<SumDepth<<setiosflags(ios::fixed)<<setiosflags(ios::right)<<setprecision(2)<<"\t"<<MeanHit<<"\t1.00000\t"<<RefBaseSite<<(BaseSite[ie]).get_q(RefNum)<<"\t"<<"N"<<"\n"; 
				}
				else if (Ref_length==0)
				{
					OUT<<chr<<"\t"<<Refposi+1<<"\t"<<AltBase<<"\t"<<SumDepth<<"\t"<<setiosflags(ios::fixed)<<setiosflags(ios::right)<<setprecision(2)<<MeanHit<<"\t1.00000\t"<<RefBaseSite<<"\t"<<AltBase<<(BaseSite[ie]).get_q(AltNum)<<"\n";
				}
				else
				{
					string FinalBase=(BaseSite[ie]).Genotype_Likelihood(RefNum ,AltNum,Ref_length ,  Alt_length ,minQ , para_A21->Indouble );
					double  RST=rank_test(BaseSite[ie], p_rank, same_qual_count, rank_array, para_A21->Inchar1 , RefNum,AltNum );
					OUT<<chr<<"\t"<<Refposi+1<<"\t"<<FinalBase<<"\t"<<SumDepth<<"\t"<<setiosflags(ios::fixed)<<setiosflags(ios::right)<<setprecision(2)<<MeanHit<<"\t"<<setprecision(5)<<RST<<"\t"<<RefBaseSite<<(BaseSite[ie]).get_q(RefNum)<<"\t"<<AltBase<<(BaseSite[ie]).get_q(AltNum)<<"\n";
				}
				(BaseSite[ie]).Destory_Site();
			}
		}
		else
		{

			for (ubit64_t  Refposi = Start_Ai   ; Refposi < End_Ai ; Refposi++ )
			{
				int ie=Refposi-Start_Ai ;
				char RefBaseSite=ChrSeq[Refposi];
				char AltBase='N';
				int RefNum=((RefBaseSite>>1)&3);
				int Ref_length=0 ,  Alt_length=0 , SumDepth =0 ;
				double MeanHit=25.0 ;
				int AltNum=(BaseSite[ie]).get_Two_allele(RefNum ,AltBase , Ref_length ,Alt_length );
				MeanHit=(BaseSite[ie]).get_mean_hit(SumDepth) ;
				if (Alt_length==0)
				{
					OUT<<chr<<"\t"<<Refposi+1<<"\t"<<RefBaseSite<<"\t"<<SumDepth<<setiosflags(ios::fixed)<<setiosflags(ios::right)<<setprecision(2)<<"\t"<<MeanHit<<"\t1.00000\t"<<RefBaseSite<<(BaseSite[ie]).get_q(RefNum)<<"\t"<<"N"<<"\n"; 
				}
				else if (Ref_length==0)
				{
					OUT<<chr<<"\t"<<Refposi+1<<"\t"<<AltBase<<"\t"<<SumDepth<<"\t"<<setiosflags(ios::fixed)<<setiosflags(ios::right)<<setprecision(2)<<MeanHit<<"\t1.00000\t"<<RefBaseSite<<"\t"<<AltBase<<(BaseSite[ie]).get_q(AltNum)<<"\n";
				}
				else
				{
					string FinalBase=(BaseSite[ie]).Genotype_Likelihood(RefNum ,AltNum,Ref_length ,  Alt_length ,minQ );
					double  RST=rank_test(BaseSite[ie], p_rank, same_qual_count, rank_array, para_A21->Inchar1 , RefNum,AltNum );
					OUT<<chr<<"\t"<<Refposi+1<<"\t"<<FinalBase<<"\t"<<SumDepth<<"\t"<<setiosflags(ios::fixed)<<setiosflags(ios::right)<<setprecision(2)<<MeanHit<<"\t"<<setprecision(5)<<RST<<"\t"<<RefBaseSite<<(BaseSite[ie]).get_q(RefNum)<<"\t"<<AltBase<<(BaseSite[ie]).get_q(AltNum)<<"\n";
				}
				(BaseSite[ie]).Destory_Site();
			}
		}

		for( int ie=windos_Alen; ie<bin ; ie++ )
		{
			int tmpj=ie-windos_Alen;
			(BaseSite[tmpj]).CopySame((BaseSite[ie]));
			(BaseSite[ie]).Destory_Site();
		}

	} 
	/// print out ///

	delete [] BaseSite ;
	delete [] same_qual_count ;
	delete [] rank_array ; 
	delete p_rank ;

	chr=Nowchr ;
	if ( (Alignment.isOpened()) ) 
	{
		return 1 ;
	}
	else
	{
		return 0 ;
	}
}






int Bam_Genotype_main( ParaClass * para_A21 ) 
{
	char in_mode[5] ={ 0 };
	TSamCtrl Alignment ;
	if  ((para_A21->InUnInt1)==3)
	{
		in_mode[0]='r';in_mode[1]='b';
		Alignment.open((para_A21->InStr2).c_str(),in_mode);
	}
	else
	{
		in_mode[0]='r';
		Alignment.open((para_A21->InStr3).c_str(),in_mode);
	}

	ogzstream OUT ((para_A21->OutPut1).c_str());
	if(!OUT.good())
	{
		cerr << "open InputFile error: "<<(para_A21->OutPut1)<<endl;
		return 1;
	}

	map <string,ubit64_t>  ChrLeng ;
	map <string,string>    ChrSeq ;   

	int chrNum=ReadFaSeq (para_A21->InStr1 , ChrLeng ,ChrSeq );

	string ID , seq ,Qseq ,ab , zf  ,soapline , Nowchr ;
	int hit , Read_leng ;
	ubit64_t position =0;

	//    Alignment.readline(soapline);

	while(Alignment.readline(soapline)!=-1 )
	{
		soapline=Talignment_format_filter(soapline, para_A21->InInt3 ,para_A21->TF);
		if(soapline.compare(NOUSE_ALIGNMENT)==0)
		{
			continue;
		}
		else
		{
			break;
		}
	}



	istringstream isoneA (soapline,istringstream::in);
	isoneA>>ID >> seq >> Qseq >> hit >> ab >> Read_leng >> zf >> Nowchr >> position ;

	///*///
	int run = Genotype_Arg(ChrLeng[Nowchr] , ChrSeq[Nowchr] , Nowchr  , Alignment  , OUT , soapline , para_A21 ) ;
	int tempC=1;
	while(run)
	{
		run = Genotype_Arg(ChrLeng[Nowchr] , ChrSeq[Nowchr] , Nowchr  , Alignment  , OUT , soapline , para_A21 ) ;
		tempC++;
		if (tempC>chrNum) { cerr<<"may Ref chr smaller than soap chr\n" ;}
	}
	////*////


	OUT.close();
	//    SOAP.close();

	return 1 ;
}



int Soap_Genotype_main( ParaClass * para_A21 ) 
{

	ogzstream OUT ((para_A21->OutPut1).c_str());
	if(!OUT.good())
	{
		cerr << "open InputFile error: "<<(para_A21->OutPut1)<<endl;
		return 1;
	}

	map <string,ubit64_t>  ChrLeng ;
	map <string,string>    ChrSeq ;   

	int chrNum=ReadFaSeq (para_A21->InStr1 , ChrLeng ,ChrSeq );

	igzstream SOAP ((para_A21->InPut1).c_str(),ifstream::in);
	if(!SOAP.good())
	{
		cerr << "open InputFile error: "<<(para_A21->InPut1)<<endl;
		return 1;
	} 

	string ID , seq ,Qseq ,ab , zf  ,soapline , Nowchr ;
	int hit , Read_leng ;
	ubit64_t position =0;
	getline(SOAP, soapline ) ;

	istringstream isoneA (soapline,istringstream::in);
	isoneA>>ID >> seq >> Qseq >> hit >> ab >> Read_leng >> zf >> Nowchr >> position ;

	///*///
	int run = Genotype_Arg(ChrLeng[Nowchr] , ChrSeq[Nowchr] , Nowchr  ,SOAP , OUT , soapline , para_A21 ) ;
	int tempC=1;
	while(run)
	{
		run = Genotype_Arg(ChrLeng[Nowchr] , ChrSeq[Nowchr] , Nowchr  ,SOAP , OUT , soapline , para_A21 ) ;
		tempC++;
		if (tempC>chrNum) { cerr<<"may Ref chr smaller than soap chr\n" ;}
	}
	////*////
	OUT.close();
	SOAP.close();

	return 1 ;
}



int all_genetype_main(int argc, char **argv) 
{
	ParaClass * para_A21 = new ParaClass;
	para_A21->Indouble=0.0010;
	para_A21->InInt2=15;
	para_A21->InInt3=15;
	para_A21->InUnInt1=0;
	if( parse_cmd_A21( argc, argv  ,  para_A21 ) ==0)
	{
		delete para_A21 ;
		return 0; 
	}
	if ((para_A21->InUnInt1)==1)
	{
		if (GetShiftQSoap(para_A21->InPut1,2)!=64)
		{
			para_A21->Inchar1='!';
		}
		Soap_Genotype_main ( para_A21 );
	}
	else 
	{
		if  ((para_A21->InUnInt1)==2)
		{
			if (GetShiftQXam ( (para_A21->InStr3),2 )!=64)
			{
				para_A21->Inchar1='!';
			}
		}
		else
		{
			if (GetShiftQXam ( (para_A21->InStr2),3 )!=64)
			{
				para_A21->Inchar1='!';
			}
		}
		Bam_Genotype_main ( para_A21 );	
	}
	delete para_A21 ;
	return 0 ;
}

///////// swimming in the sky and flying in the sea ////////////
#endif /* Allgenotype_H_  */

