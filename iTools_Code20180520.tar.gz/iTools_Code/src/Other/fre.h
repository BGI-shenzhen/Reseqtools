#ifndef Fre_H_
#define Fre_H_

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <map>
#include "../include/gzstream/gzstream.C"
#include <iomanip>
#include "../ALL/comm.h"
#include <algorithm>

using namespace std;
typedef long long  llong ;

int  print_usage_A25()
{
	cout <<""
		"\n"
		"\tUsage: Fre  -InFile <inFile>  -OutPut <out> [options]\n"
		"\n"
		"\t\t-InFile    <str> : Input file for stat\n"
		"\t\t-InList    <str> : Input file list for stat\n"
		"\t\t-OutPut    <str> : OutPut file\n"
		"\n"
		"\t\t-Row       <int> : The column to count frequency [4]\n"
		"\t\t-Bin     <float> : Window bin of frequency [1]\n"
		"\n"
		"\t\t-help            : Show this help\n"
		"\n";
	return 1;
}

int parse_cmd_A25(int argc, char **argv, ParaClass * para_A25)
{
	if (argc <=2  ) {print_usage_A25();return 0 ;}


	for(int i = 1; i < argc ; i++)
	{
		if(argv[i][0] != '-')
		{
			cerr << "command option error! please check." << endl;
			return 0 ;
		}
		string flag=argv[i] ;
		flag=replace_all(flag,"-","");

		if (flag  == "InFile" )
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0 ;}
			i++;
			para_A25->InPut1=argv[i];
			para_A25->InUnInt1=2;
		}
		else if (flag  == "InList" )
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0 ;}
			i++;
			para_A25->InStr1=argv[i];
			para_A25->InUnInt1=3;
		}
		else if (flag  == "OutPut" )
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0 ;}
			i++;
			para_A25->OutPut1=argv[i];
		}
		else if (flag  ==  "Row")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0 ;}
			i++;
			para_A25->InInt1=atoi(argv[i]);
		}
		else if (flag  ==  "Bin")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0 ;}
			i++;
			para_A25->Indouble=atof(argv[i]);
		}
		else if (flag  == "help")
		{
			print_usage_A25();return 0 ;
		}
		else
		{
			cerr << "UnKnow argument -"<<flag<<endl;
			return 0 ;
		}
	}
	if  ((para_A25->OutPut1).empty() || (para_A25->InUnInt1)==1)
	{
		cerr<< "lack argument for the must"<<endl ;
		return 0 ;
	}
	return 1 ;
}

int Row_Bin_NoList(string file , int Row , double Bin , ofstream & OUT )
{
	igzstream IN (file.c_str(),ifstream::in); 
	if(!IN.good())
	{
		cerr << "open IN File error: "<<file<<endl;
		return 1;    
	}
	long  double  NNum=0 ;
	llong temp=0 ;
	map < llong ,long >  Map ;    
	while(!IN.eof())
	{
		string  line  ,tempsss ;
		getline(IN,line);
		if (line.length()<=0)  { continue  ; }
		istringstream  stream  (line,istringstream::in);
		for (int i=1 ; i<Row  ; i++)
		{
			stream >> tempsss  ;
		}
		stream >> NNum ;         
		temp= llong(NNum/Bin) ;
		Map[temp]++;
	}
	IN.close();

	map < llong ,long > ::iterator map_it =Map.begin();

	while(map_it!=Map.end())
	{        
		OUT<<(map_it->first)<<"\t"<<map_it->second<<endl ;
		map_it++ ;
	}

	return 1 ;
}


int Row_Bin_List(string file , int Row , double Bin , ofstream & OUT )
{
	igzstream IN (file.c_str(),ifstream::in); 
	if(!IN.good())
	{
		cerr << "open IN File error: "<<file<<endl;
		return 1;    
	}

	long double  num=0 ;
	llong temp=0 ;
	map < llong ,long >  Map ;

	while(!IN.eof())
	{
		string  file_stat ,temppp ;
		getline(IN,file_stat);
		if (file_stat.length()<=0)  { continue  ; }
		igzstream SST (file_stat.c_str(),ifstream::in);
		if(!SST.good())
		{
			cerr << "open IN File error: "<<file_stat<<endl;
			return 1;
		}
		while(!SST.eof())        
		{
			string  line ;
			getline(SST,line);
			if (line.length()<=0)  { continue  ;}
			istringstream isone (line,istringstream::in);
			for (int i=1 ; i<Row ; i++)
			{
				isone >> temppp  ;
			}
			isone >> num ;
			temp= llong(num/Bin) ;
			Map[temp]++;
		}
		SST.close();
	}
	IN.close();

	map < llong ,long > ::iterator map_it =Map.begin();
	while(map_it!=Map.end())
	{
		OUT<<(map_it->first)<<"\t"<<map_it->second<<endl ;
		map_it++ ;
	}
	return 1 ;
}

//programme entry
///////// swimming in the sky and flying in the sea ////////////
int Fre_main(int argc, char **argv)
{
	ParaClass * para_A25 = new ParaClass;
	para_A25->InInt1=4;
	if (parse_cmd_A25(argc, argv , para_A25 )==0)
	{
		delete para_A25 ; 
		return 1;
	}
	ofstream  OUT ((para_A25->OutPut1).c_str());
	if(!OUT.good())
	{
		cerr << "open OUT File error: "<<para_A25->OutPut1<<endl;
		return 1;
	}

	if ((para_A25->InUnInt1)==2 )
	{
		Row_Bin_NoList( para_A25->InPut1 , para_A25->InInt1 , para_A25->Indouble, OUT ) ;
	}
	else if ((para_A25->InUnInt1)==3)
	{
		Row_Bin_List ( para_A25->InStr1, para_A25->InInt1 , para_A25->Indouble , OUT ) ;
	}

	OUT.close();
	delete para_A25 ;
	return 0;
}
#endif 
///////// swimming in the sky and flying in the sea ////////////
