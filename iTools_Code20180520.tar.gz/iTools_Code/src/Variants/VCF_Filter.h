#ifndef VCFFilter_H_
#define VCFFilter_H_
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <map>
#include "../ALL/comm.h"
#include "../ALL/DataClass.h"
#include <cstdlib>
#include "../include/gzstream/gzstream.C"
#include "../include/zlib/zlib.h"
#include "../CNSTool/filter_genotype.h"
#include <stdio.h>

using namespace std;
typedef long long  llong ;

int  VCFFilterVCFIN_help()
{
	cout <<""
		"\n"
		"\tUsage: VCFFilter -InPut  <in.vcf>  -OutPut  <out.vcf>\n"
		"\n"
		"\t\t-InPut    <str>     Input GATK VCF genotype File\n"
		"\t\t-OutPut   <str>     OutPut the Filter VCF File\n"
		"\n"
		"\t\t-Het      <float>   The max ratio of het allele[0.88]\n"
		"\t\t-Miss     <float>   The max ratio of miss allele[0.88]\n"
		"\t\t-MAF      <float>   Filter the low minor allele frequency[0.0]\n"
		"\t\t-QUAL     <float>   Min QUAL to filter of VCF [50]\n"
		"\t\t-Cut3base           Filter position with 3 allele[off]\n"
		"\n"
		"\t\t-help               Show this help\n"
		"\n";
	return 1;
}

int VCFFilter_help01(int argc, char **argv , ParaClass * ParaIN )
{
	if (argc <=2 ) {VCFFilterVCFIN_help();return 0;}

	for(int i = 1; i < argc ; i++)
	{
		if(argv[i][0] != '-')
		{
			cerr << "command option error! please check." << endl;
			return 0;
		}
		string flag=argv[i] ;
		flag=replace_all(flag,"-","");

		if (flag  == "InPut")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			ParaIN->InPut1=argv[i];
		}
		else if (flag  ==  "OutPut")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			ParaIN->OutPut1=argv[i];
		}
		else if (flag  ==  "Het")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			ParaIN->Indouble=atof(argv[i]);
		}

		else if (flag  ==  "Miss")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			ParaIN->Infloat1=atof(argv[i]);
		}
		else if (flag  ==  "MAF")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			ParaIN->Infloat2=atof(argv[i]);
		}
		else if (flag  ==  "QUAL")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			ParaIN->InStr1=argv[i];
		}
		else if (flag == "Cut3base")
		{
			ParaIN->TF=false ;
		}
		else if (flag == "help")
		{
			VCFFilterVCFIN_help();return 0;
		}
		else
		{
			cerr << "UnKnow argument -"<<flag<<endl;
			return 0;
		}
	}
	if  ((ParaIN->InPut1).empty() || (ParaIN->OutPut1).empty()  )
	{
		cerr<< "lack argument for the must"<<endl ;
		return 0;
	}
	(ParaIN->OutPut1)=add_Asuffix(ParaIN->OutPut1);
	return 1 ;
}


int VCF_Filtermain(int argc, char *argv[])
//int main(int argc, char *argv[])
{
	ParaClass  *ParaIN = new  ParaClass ;
	ParaIN->Infloat1=0.88;
	ParaIN->Indouble=0.88;
	ParaIN->InStr1="50";
	if ((VCFFilter_help01(argc, argv, ParaIN)==0))
	{
		delete ParaIN ;
		return 0 ;
	}
	
	double  QUAL=atof((ParaIN->InStr1).c_str());

	ogzstream OUTVCF ((ParaIN->OutPut1).c_str());

	if((!OUTVCF.good()))
	{
		cerr << "open OUTVCF File error: "<<(ParaIN->OutPut1)<<endl;
		delete  ParaIN ; return  0;
	}

	igzstream VCFIN ((ParaIN->InPut1).c_str(),ifstream::in);
	if (VCFIN.fail())
	{
		cerr << "open VCFIN File error: "<<(ParaIN->InPut1)<<endl;
		delete  ParaIN ; return  0;
	}

	if (ParaIN->TF)
	{
		while(!VCFIN.eof())
		{
			string  line ;
			getline(VCFIN,line);
			if (line.length()<=0 )  { continue  ; }
			else if ((line[0] =='#'))
			{
				OUTVCF<<line<<endl;
				continue ;
			}

			vector<string> inf ;
			split(line,inf," \t");

			double  Q=atof((inf[5]).c_str());

			if  (Q<QUAL)
			{
				continue;
			}

			map <char , int>  Count ;

			int DiffHete=0;
			int MissNumner=0;

			int Aszie=inf.size();
			int SampleNumber=Aszie-9;

			for (int jj=9 ; jj< Aszie ;jj++ )
			{
				vector<string> BaseTmp  ; 
				split(inf[jj], BaseTmp,":");
				if  ( (BaseTmp[0] =="./.")  ||  (BaseTmp[0] ==".|." ) ||  (BaseTmp[0] ==".") )
				{
					MissNumner++;
					continue ;
				}
				if (BaseTmp[0][0] != BaseTmp[0][2] )
				{
					DiffHete++;
				}
				Count[BaseTmp[0][0]]++;
				Count[BaseTmp[0][2]]++;			
			}

			if ( ((MissNumner*1.0)/SampleNumber  )  > (ParaIN->Infloat1) )
			{
				continue ;
			}

			if ( ((DiffHete*1.0)/SampleNumber  )  > (ParaIN->Indouble) )
			{
				continue ;
			}

			int MaxBase=0;
			int SendBase=0;
			map <char,int>  :: iterator it=Count.begin();

			for ( ; it!=Count.end(); it++ )
			{
				if ((it->second)  > MaxBase )
				{
					SendBase=MaxBase;
					MaxBase=(it->second) ;
				}
				else if ( (it->second)  >= SendBase )
				{
					SendBase=(it->second);
				}
			}

			if (  (1.0-(MaxBase/(SampleNumber*2.0)))  <  (ParaIN->Infloat2))
			{
				continue ;				
			}

			OUTVCF<<line<<endl;

		} //#while

	} //#if 
	else
	{

		while(!VCFIN.eof())
		{
			string  line ;
			getline(VCFIN,line);
			if (line.length()<=0 )  { continue  ; }
			else if ((line[0] =='#'))
			{
				OUTVCF<<line<<endl;
				continue ;
			}

			map <char , int>  Count ;
			int DiffHete=0;
			int MissNumner=0;

			vector<string> inf ;
			split(line,inf," \t");

			double  Q=atof((inf[5]).c_str());
			if  (Q<QUAL)
			{
				continue;
			}


			int Aszie=inf.size();
			int SampleNumber=Aszie-9;

			for (int jj=9 ; jj< Aszie ;jj++ )
			{
				vector<string> BaseTmp  ; 
				split(inf[jj], BaseTmp,":");
				if  ( (BaseTmp[0] =="./.")  ||  (BaseTmp[0] ==".|." ) ||  (BaseTmp[0] ==".") )
				{
					MissNumner++;
					continue ;
				}
				if (BaseTmp[0][0] != BaseTmp[0][2] )
				{
					DiffHete++;
				}
				Count[BaseTmp[0][0]]++;
				Count[BaseTmp[0][2]]++;			
			}

			if ( ((MissNumner*1.0)/SampleNumber  )  > (ParaIN->Infloat1) )
			{
				continue ;
			}

			if ( ((DiffHete*1.0)/SampleNumber  )  > (ParaIN->Indouble) )
			{
				continue ;
			}

			int MaxBase=0;
			int SendBase=0;
			map <char,int>  :: iterator it=Count.begin();
			int Base_Number=0;

			for ( ; it!=Count.end(); it++ )
			{
				if ((it->second)  > MaxBase )
				{
					SendBase=MaxBase;
					MaxBase=(it->second) ;
				}
				else if ( (it->second)  >= SendBase )
				{
					SendBase=(it->second);
				}
				Base_Number++;
			}

			if (  (1.0-(MaxBase/(SampleNumber*2.0)))  <  (ParaIN->Infloat2))
			{
				continue ;				
			}
			if  (Base_Number > 2 )
			{
				continue ;				 
			}

			OUTVCF<<line<<"\n";

		} //#while


	}

	VCFIN.close();
	OUTVCF.close();
	delete ParaIN ;
	return 0;
}
#endif // VCFFilter_H_  //
///////// swimming in the sky and flying in the sea ////////////

