#ifndef _TYPE_H_
#define _TYPE_H_

typedef long long 		__int64;
typedef short			__int16;
typedef char			__int8;
typedef unsigned long long 	__uint64;
typedef unsigned short		__uint16;
typedef unsigned char		__uint8;

typedef char TCHAR, *PTCHAR;

#ifndef __wtypes_h__
typedef unsigned long       	DWORD;
typedef DWORD               	COLORREF;
typedef unsigned short      	WORD;
typedef  unsigned char			BYTE;
typedef unsigned int			UINT;
#endif
#endif
