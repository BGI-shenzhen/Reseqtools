//header file : align2pe.h
#ifndef _ALIGN2PE_H_
#define _ALIGN2PE_H_
/*Multithread parameter struct*/
/************************************************************************/
#define	CH(a,b)		((a<<1)|b)
/************************************************************************/


//implement file: align2pe.cpp
#include "include.h"
#include "common.h"
#include "main.h"

/************************************************************************/
pthread_mutex_t			mutex_s = PTHREAD_MUTEX_INITIALIZER;
bool		g_binsertfile = true;
/************************************************************************/



struct Pair_End
{
	int			npos;
	int			nqual;
	int			nrlen;
	char		ch;//strand
	string		strid;
	int			nmean;
	int			nsd;
	int			nrsd;
};

typedef map<string, Pair_End>		MPAIREND;

struct SGAP 
{
	int		ns;
	int		ne;
};

struct InsertSD 
{
	int		ninsert;
	int		nsd;
	int		nrsd;
};
typedef map<string, InsertSD>	MInsertSD;

struct align2pe_thread_param
{
	align2pe_thread_param(){pinsert=NULL;pVstr=NULL;}
	string		sname;// soap file name
	MInsertSD*	pinsert;// Insert size and sd info
	VString*	pVstr;// PE file name
	map<string, vector<SGAP> > mgap ;// Gap size info
};

//////////////////////////////////////////////////////////////////////////
class CAlign2pe
{
public:
	CAlign2pe();
	CAlign2pe(MInsertSD* pis)
	{
		char* pq = AfxGetValue("-Q");
		m_nqual = (pq==NULL) ? 1 : atoi(pq);//默认为唯一比上的pair  reads
		m_pminsert = pis;	
		m_cc['+'] = 0;
		m_cc['-'] = 1;
		m_mcc['0'] = '3';
		m_mcc['1'] = '2';
		m_mcc['2'] = '1';
		m_mcc['3'] = '0';
		m_mcc['4'] = '4';
		m_mcc['5'] = '5';
		m_bnormal = false;
		m_breverse = AfxGetValue("-R")==NULL?false:true;//use for test.
	}
	~CAlign2pe();

	void		 pe_convsoap2pe(const char* pName, VString& vstr);
	void		 pe_readgap(const char* p, map<string, vector<SGAP> >* pgap);
	bool		 pe_getinsertinfo(MInsertSD* p);// Get insert size information

	static bool	 pe_checknormal(Pair_End& pe1, Pair_End& pe2, char& ch);//PE 是否为正常PE，处于[insert－3sd,insert+3sd]视为正常PE，方向不同的都为 异常PE
	static void	 pe_parseID(string& str);//去掉soap id之后的 /1 & /2

private:
	bool	 	 pe_checkgap(int ns, int ne);
	void	 	 pe_outputPE(Pair_End& pe1, Pair_End& pe2, ofstream& ofile);//输出PE
	void	 	 pe_outputPE(string& str, MPAIREND& vpe, ofstream& ofile);//输出PE
//	void	 	 pe_outputPE2(string& str, MPAIREND& vpe, ofstream& ofile);//输出PE
public:
//Attribute
	map<char, char>			m_mcc;// Convert RF to FR  如果比对正方向为RF则把RF 转换为FR
private:
//Attribute
	vector<SGAP>*			m_vgap;// Gap on reference info
	MInsertSD*				m_pminsert;// Insert size and sd info
	map<char, int>			m_cc;  // '+'=>0   '-'=>1
	int						m_nqual;// Unique map or not
	string					m_strchr;
	bool					m_breverse;// for test . 
	bool					m_bnormal;// Output normal PE
};

extern bool g_binsertfile;
//////////////////////////////////////////////////////////////////////////
//inline functions
inline void CAlign2pe::pe_parseID( string& str )
{
	int		pos;
	if((pos=str.find('/'))!=-1)
		str.assign(str, 0, pos);
}

inline bool CAlign2pe::pe_checkgap( int ns, int ne )
{
	if (m_vgap == NULL)
		return false;
	
	for (size_t i=0; i<m_vgap->size(); i++)
	{
		if (!(ne<m_vgap->operator [](i).ns || ns>m_vgap->operator [](i).ne))
		{
			return true;
		}
	}
	return false;
}

inline bool CAlign2pe::pe_checknormal( Pair_End& pe1, Pair_End& pe2, char& ch )
{
	if(ch == '1')
	{	

//cout << "--in pe_checknormal: "<< pe1.nsd <<"|" << pe1.nrsd <<endl;

		int		len = pe2.npos - pe1.npos + pe2.nrlen;
		if(len <= pe1.nmean-3*pe1.nsd)ch = '4';
		else if(len < pe1.nmean+3*pe1.nrsd)ch = '5';	//right sd value
		if(ch == '5')return true;
	}
	return false;
}

struct cmp 
{
	string		m_str;
	cmp(string& str) : m_str(str){}
	bool operator()(Pair_End& pe){return (strcmp(pe.strid.c_str(), m_str.c_str())==0);}
};

inline void CAlign2pe::pe_outputPE( string& str, MPAIREND& mpe, ofstream& ofile )
{//for soap
	VString		vstr;
	split(str, vstr, "\t ");
	if(vstr.size()<9)return;
	
	Pair_End	pe;
	pe.nqual	= atoi(vstr[3].c_str());		
	if(pe.nqual>m_nqual) return;
	pe_parseID(vstr[0]);
	
	pe.strid	= vstr[0];
	pe.ch		= (vstr[6].c_str())[0];
	pe.npos		= atoi(vstr[8].c_str());
	pe.nrlen	= atoi(vstr[5].c_str());
	if(!g_binsertfile)
	{
		pe.nmean = m_pminsert->operator []("*").ninsert;
		pe.nsd	 = m_pminsert->operator []("*").nsd;
		
		pe.nrsd	 = m_pminsert->operator []("*").nrsd;
	}
	else		// get the insert information from m_pminsert
	{
		string	tmp;
		int		pos;
		if(vstr[0].find('-') == string::npos ) return;
		tmp = vstr[0].substr(0, vstr[0].find('-'));	// 11-9340372 , 11 is the number of len, in insert_info file is the number.
			
		pe.nmean = m_pminsert->operator [](tmp).ninsert;
		pe.nsd	 = m_pminsert->operator [](tmp).nsd;
		
		pe.nrsd	 = m_pminsert->operator [](tmp).nrsd;
		if(pe.nmean==0 || pe.nsd==0)return;
	}
	



	if (mpe.find(vstr[0]) != mpe.end())
	{


//cout << "--------- mpe.find :" << vstr[0] << endl;


		pe_outputPE(pe, mpe[vstr[0]], ofile);
		mpe.erase(vstr[0]);
	}
	else
	{
		mpe[vstr[0]] = pe;
	}
}

/*
inline void CAlign2pe::pe_outputPE2( string& str, MPAIREND& mpe, ofstream& ofile )
{//for soap
	VString		vstr;
	split(str, vstr, "\t ");

	Pair_End	pe;
	pe_parseID(vstr[0]);
	pe.nqual	= atoi(vstr[1].c_str());
	if(pe.nqual>1) return;
	pe.strid	= vstr[0];
	pe.ch		= (vstr[3].c_str())[0];
	pe.npos		= atoi(vstr[4].c_str());
	pe.nrlen	= atoi(vstr[2].c_str());
	pe.nmean	= atoi(vstr[5].c_str());
	pe.nsd		= atoi(vstr[6].c_str());
	if (mpe.find(vstr[0]) != mpe.end())
	{
		pe_outputPE(pe, mpe[vstr[0]], ofile);
		mpe.erase(vstr[0]);
	}
	else
	{
		mpe[vstr[0]] = pe;
	}
}
*/
inline void CAlign2pe::pe_outputPE( Pair_End& pe1, Pair_End& pe2, ofstream& ofile )
{
	char		ch;
	int			nStart;
	int			nEnd;
	if(abs(pe1.npos - pe2.npos)<pe1.nrlen)return;
	else
	{
		int		len = abs(pe1.npos-pe2.npos);
		if(pe1.npos < pe2.npos)
		{
			if(pe_checkgap(pe1.npos, pe2.npos))//true : in gap, false : not in gap
				return;
			ch = CH(m_cc[pe1.ch], m_cc[pe2.ch])+'0';
			if(!m_breverse && pe1.nmean > 1000)ch = m_mcc[ch];
			if(pe_checknormal(pe1, pe2, ch))
			{
				if(!m_bnormal)
					return;
			}
			ofile<<ch<<'\t'<<ch<<'\t'<<pe1.npos<<'\t'<<pe2.npos+pe2.nrlen<<'\t'<<pe1.nqual<<'\t'<<pe2.nqual<<'\t';//<<"215-13\t";
			ofile<<pe1.nmean<<'-'<<pe1.nsd<<'\t'<<pe2.npos+pe2.nrlen-pe1.npos<<'\t'<<pe1.strid<<'\t'<<m_strchr<<'\n';
		}
		else
		{
			if(pe_checkgap(pe2.npos, pe1.npos))//true : in gap, false : not in gap
				return;
			ch = CH(m_cc[pe2.ch], m_cc[pe1.ch])+'0';
			if(!m_breverse && pe1.nmean > 1000)ch = m_mcc[ch];
			if(pe_checknormal(pe2, pe1, ch))
			{
				if(!m_bnormal)
					return;
			}
			ofile<<ch<<'\t'<<ch<<'\t'<<pe2.npos<<'\t'<<pe1.npos+pe1.nrlen<<'\t'<<pe2.nqual<<'\t'<<pe1.nqual<<'\t';//<<"215-13\t";
			ofile<<pe2.nmean<<'-'<<pe2.nsd<<'\t'<<pe1.npos+pe1.nrlen-pe2.npos<<'\t'<<pe2.strid<<'\t'<<m_strchr<<'\n';
		}
	}
	
}

//////////////////////////////////////////////////////////////////////////
void*		 __align2_process(void*);
bool		 initInsert(const char* pfile, MInsertSD& mis);
void		 readgap(map<string, vector<SGAP> >& pgap);
//////////////////////////////////////////////////////////////////////////
//string		g_stroutdir;
int main_align2pe(int argc, char* argv[], void* pVoid /*= NULL*/)
{
	AfxGetOptions(argc, argv);
	if (AfxGetValue("-3")!=NULL || AfxGetValue("-4")!=NULL)
		return 1;
	cout<<"Align2pe......"<<endl;
	
	VString*	pVstr = &(((global_param*)pVoid)->vstr);
	
	VString		vfilename;
	char *		pName = AfxGetValue("--i");
	if(pName == NULL)
		return 0;

	if(pVstr->size() != 0)
	{
		vfilename.insert(vfilename.end(), pVstr->begin(), pVstr->end());
		pVstr->clear();
	}
	else
	{
		Getnamefromlist(AfxGetValue("-i"), vfilename);
	}
	if (vfilename.size() == 0)
	{
		printf("No file input or exsit! Align2pe testting......\n");
		return 1;// Temporary return, for this module is not in use.
	}

	char*   pcpu = AfxGetValue("-cpu");
	int		cpu = (pcpu==NULL) ? 4 : atoi(pcpu);

	MInsertSD		minsertsd;
	if(!initInsert(AfxGetValue("-insert"), minsertsd))
	{
		cerr<<"Error : insert size info is wrong !"<<endl;
		return 0;
	}

	CThreadManager		threadMgr(cpu);
	vector<align2pe_thread_param>		vtp(vfilename.size());
	threadMgr.SetTimer(0.5);
	for (int i=0; i<(int)vfilename.size(); i++)
	{
		vtp[i].sname		= vfilename[i];
		vtp[i].pVstr		= pVstr;
		vtp[i].pinsert		= &minsertsd;
		threadMgr.AddThread(__align2_process, (void*)&vtp[i]);
	}
//
	threadMgr.Run();

	return 1;
}

void* __align2_process(void* param)
{
	align2pe_thread_param*	pParam = (align2pe_thread_param*)param;
	CAlign2pe		align2pe(pParam->pinsert);
	
	string			tmp;
	map<string, vector<SGAP> > mgap;
	readgap(mgap);
	
	align2pe.pe_readgap(pParam->sname.c_str(), &mgap);
	align2pe.pe_getinsertinfo(pParam->pinsert);
	
	align2pe.pe_convsoap2pe(pParam->sname.c_str(), *(pParam->pVstr));
	return NULL;
}
//////////////////////////////////////////////////////////////////////////
bool isnumber(string& s)
{
	for (size_t i=0; i<s.size(); i++)
	{
		if (!isdigit(s[i]))
			return false;
	}
	return true;
}

bool initInsert( const char* pfile, MInsertSD& mis )
{
	if (pfile == NULL)
		return false;

	string		temp(pfile);
	VString		vtemp;


cout <<endl;
cout << "-----------------InsertSize information ----------------------" << endl;


	split(temp,vtemp,"- \t");

	if ( vtemp.size() > 1)
	{

		if(isnumber(vtemp[0]))
		{
			InsertSD        is;
			is.ninsert = atoi(vtemp[0].c_str());
			if (isnumber(vtemp[1]))
			{
				is.nsd 	= atoi(vtemp[1].c_str());
				
				if( vtemp.size() == 3)
				{
					if (isnumber(vtemp[2]))
                        		{
						is.nrsd = atoi(vtemp[2].c_str());
			
					}
				

				}

				else
				{	
					is.nrsd = is.nsd;

				}


	cout <<"\t\t" <<is.ninsert <<"\t" <<  is.nsd << "\t" <<  is.nrsd << endl;

			
				mis["*"] = is;
                                g_binsertfile = false;
                                return true;



			}
		}

	}
/*
	int			pos;
	if ((pos=temp.find('-')) != -1)
	{
		InsertSD	is;
		string s = temp.substr(0, pos);
		if(isnumber(s))
		{
			is.ninsert = atoi(s.c_str());

			//if ((pos2=temp.find('	
		
			s = temp.substr(pos+1, temp.length()-1-pos);
			if(isnumber(s))
			{
				is.nsd = atoi(s.c_str());
				mis["*"] = is;
				g_binsertfile = false;
				return true;
			}
		}
	}
*/



	igzstream	ifile(pfile);
	if (!ifile.good())
	{
		printf("No such file(%s) or directory!\n", pfile);
		return false;
	}
	string	str;
	while (getline(ifile, str))
	{
		VString		vstr;
		if (str.empty())
			continue;
		split(str, vstr, "\t ");
		if (vstr.size() > 2)
		{
			InsertSD	is;
			is.ninsert = atoi(vstr[1].c_str());
			is.nsd = int(atof(vstr[2].c_str())+0.5);

			if(vstr.size()== 4)
			{
			is.nrsd = int(atof(vstr[3].c_str())+0.5);


			}	////////////////////

			if(vstr.size()==3)
			{
			 is.nrsd = is.nsd;

			}
			mis[vstr[0]] = is;

	
cout <<"\t\t\t" << is.ninsert <<"\t"<< is.nsd << "\t" << is.nrsd << endl;
		}	

		else
		{

			return false;
		}

	}

cout << "-------------------------------------------------------------" << endl;




	return true;
}

void readgap( map<string, vector<SGAP> >& pgap )
{
	char* p = AfxGetValue("-gap");
	if(p == NULL) return;
	igzstream	ifile(p);
	if(!ifile.good())return;

	string	str;
	while (getline(ifile, str))
	{
		VString		vstr;
		split(str, vstr,"\t ");
		if(vstr.size() < 3)continue;

		SGAP	gap;
		gap.ns = atoi(vstr[1].c_str());
		gap.ne = atoi(vstr[2].c_str());
		pgap[vstr[0]].push_back(gap);
	}
	ifile.close();
}

CAlign2pe::CAlign2pe()
{
	char* pq = AfxGetValue("-Q");
	m_nqual = (pq==NULL) ? 1 : atoi(pq);
	m_mcc['0'] = '3';
	m_mcc['1'] = '2';
	m_mcc['2'] = '1';
	m_mcc['3'] = '0';
	m_mcc['4'] = '4';
	m_mcc['5'] = '5';
	m_breverse = AfxGetValue("-R")==NULL?false:true;//use for test.
}

CAlign2pe::~CAlign2pe()
{
	
}

void CAlign2pe::pe_convsoap2pe(const char* pName, VString& vstr)
{
	m_bnormal = (AfxGetValue("-normal")==NULL) ? false : true;
	MPAIREND	mpe;
	igzstream	gifile(pName);
	string		tmp = Formatnewfilename(pName, ".PE", AfxGetValue("-o"));

//	igzstream	ifile;
//	filtering_istream gifile;
//	string name(pName);
//	if(name.substr(name.length()-3)==".gz"){
	//	gifile.push(gzip_decompressor());
	//	gifile.push(file_source(name));
	//	gifile.open(pName);
//	}else{
//		ifile.open(pName);
//		getline(ifile, str);
//	}
	pthread_mutex_lock(&mutex_s);
	vstr.push_back(tmp);
	pthread_mutex_unlock(&mutex_s);
	
	ofstream	ofile(tmp.c_str());

printf("\n---- read soapfile: %s\n",pName);
	if (!gifile)
	{
		printf("%s: No such file or directory!\n", pName);
		return;
	}
	string		str;
	getline(gifile, str);
	if(str.empty())return;
	if(str[0] != '>')
	{
		VString		vstr;
		split(str, vstr, "\t ");
		m_strchr = vstr[7];

//cout << "------ before pe_outputPE: "<< vstr[0] << endl;
//__int64  count = 0;

		pe_outputPE(str, mpe, ofile);
//		if(name.substr(name.length()-3)==".gz"){
			while (getline(gifile, str))
			{
				pe_outputPE(str, mpe, ofile);
//++count;
			}
//		}else{
//			while (getline(ifile, str))
//			{
//				pe_outputPE(str, mpe, ofile);
//			}
//		}
	}
	else
	{
		m_strchr = str.substr(1, str.length()-1);
	//	if(name.substr(name.length()-3)==".gz"){
			while (getline(gifile, str))
			{
				pe_outputPE(str, mpe, ofile);
			}
	//	}else{
	//		while (getline(ifile, str))
	//		{
	//			pe_outputPE(str, mpe, ofile);
	//		}
	//	}
	}


//printf( "---------- total lines: %I64d\n", count);

//	if(name.substr(name.length()-3)==".gz"){
		gifile.close();
//	}else{
//		ifile.close();
//	}
	ofile.close();
	mpe.clear();

}
void CAlign2pe::pe_readgap( const char* p, map<string, vector<SGAP> >* pgap )
{
	if (p == NULL)
		return ;
	if (pgap->size() == 0)
		return;

	igzstream	ifile(p);
	if(!ifile.good())return;
	string		str;
	if(getline(ifile, str))
	{
		VString		vstr;
		//_table_t::Split(str, vstr);
		split(str, vstr,"\t \n");
		char* ptype = AfxGetValue("-type");
		if(vstr[0][0] == '>')
		{
			if (ptype != NULL)
			{
				if(strcmp(ptype, "soap")==0 )
					str = vstr[0].substr(1, vstr[0].length()-1);
				else if(strcmp(ptype, "maq")==0)
					str = vstr[0].substr(1, vstr[0].length()-1);
				else return;
			}
			else
			{
				str = vstr[0].substr(1, vstr[0].length()-1);
			}
		}
		else
		{
				str = vstr[7];
		}
		m_vgap = &(pgap->operator [](str));
	}
	ifile.close();
}

bool CAlign2pe::pe_getinsertinfo(MInsertSD* p)
{
	m_pminsert = p;
	return true;
}

#endif //_ALIGN2PE_H_
