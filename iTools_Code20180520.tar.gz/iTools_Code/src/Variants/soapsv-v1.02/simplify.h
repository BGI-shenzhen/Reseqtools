#ifndef _SIMPLIFY_SVH_
#define _SIMPLIFY_SVH_

#include "include.h"
#include "common.h"
#include "main.h"
#include "align2pe.h"
#include "findSV.h"
#include "filtersv.h"
#include "simplify.h"

bool g_boneinsert = false;
bool g_boutputnormal = false;
map<char, char>		g_mcc;//convert + to 0, and convert - to 1
map<char, char>		g_mRF2FR;

struct simplify_thread_param
{
	string 	strname;
	map<string, vector<_pair_end> >*	pmvpe;
};

struct InsertSD;
struct sv_info;


void init();

void* __simplify_process(void* param);

/*************align2pe module***********/
//get PE from soap file . For argument -2
void align2pe_module(string strname, void* pvoid);
//get PE from PE file . For argument -3
void getpe_from_pefile(string strname, void* pvoid);
//get insert size information from -insert
bool getinsertsize(map<string, InsertSD>& minssd);
//convert align-pe to findsv pe
void convertpe(map<string, vector<_pair_end> >& mvpe, Pair_End& pe1, Pair_End& pe2, map<string, InsertSD>& minssd, ofstream& ofile, string& strchr);
void outputpe(_pair_end& _pe, ofstream& ofile, string& strchr);
/***************************************/

/*************findsv module*************/
string findsv_module(string strname, void* pvoid, int n);
void classify_pe_by_insertsize(vector<_pair_end>& vpe, map<int, vector<_pair_end> >& mvpe);
/***************************************/

/**************filtersv module**********/
void filtersv_module(string strname, void* pvoid);
int readsv2(const char* p, map<string,vector<sv_info> >& mvsvinf);
/***************************************/

/****************************************************************
This module is specialy designed for thousands of reference and each reference is short than 10M, such as scaffold reference to avoid hundreds and thousands of files being created. However, this module is not such efficiency as before. Unless your soap result like what referred above.
****************************************************************/

void init()
{
	g_mcc['+'] = 0;
	g_mcc['-'] = 1;	
	g_mRF2FR['0'] = '3';
	g_mRF2FR['1'] = '2';
	g_mRF2FR['2'] = '1';
	g_mRF2FR['3'] = '0';
	g_mRF2FR['4'] = '4';
	g_mRF2FR['5'] = '5';

	g_boutputnormal = AfxGetValue("-normal")==NULL ? false : true;
}

int main_simplify(int argc, char* argv[])
{
	AfxGetOptions(argc, argv);
	init();
	VString 	vfilename;
	Getnamefromlist(AfxGetValue("-i"), vfilename);
	//recieve _pair_ends from align2pe for findsv
	map<string, vector<_pair_end> >	mvpe[vfilename.size()];
	
	int cpu = AfxGetValue("-cpu")==NULL ? 4 : atoi(AfxGetValue("-cpu"));
	CThreadManager		threadMgr(cpu);
	vector<simplify_thread_param>		vtp(vfilename.size());
	threadMgr.SetTimer(0.5);
	for (int i=0; i<(int)vfilename.size(); i++)
	{//cout<<vfilename[i]<<endl;
		vtp[i].strname		= vfilename[i];
		vtp[i].pmvpe		= &mvpe[i];
		threadMgr.AddThread(__simplify_process, (void*)&vtp[i]);
	}
	threadMgr.Run();

	if(AfxGetValue("-4") != NULL)
	{
		for (size_t i=0; i<vfilename.size(); i++)
		{
			filtersv_module(vfilename[i], NULL);
		}
		return 1;
	}
//	return 1;
	// Do find sv
	string strsvname = findsv_module(AfxGetValue("-i"), (void*)mvpe, vfilename.size());
	//Do filter sv
	if(strsvname.empty())return 1;
	filtersv_module(strsvname, NULL);
	return 1;
}

void* __simplify_process(void* param)
{// Get _pair_end information for findsv
	simplify_thread_param* p = (simplify_thread_param*)param;
	if(AfxGetValue("-2") != NULL)
		align2pe_module(p->strname, (void*)p->pmvpe);
	else if(AfxGetValue("-3") != NULL)
		getpe_from_pefile(p->strname, (void*)p->pmvpe);
	else 
	{
		cerr<<"Please make sure -2 or -3 or -4"<<endl;
		return NULL;
	}
}

void align2pe_module(string strname, void* pvoid)
{
	cout<<"align2pe......"<<endl;
	cout << " file : " << strname << endl;

	
	igzstream	ifile(strname.c_str());
	if(!ifile.good())
	{
		cerr<<"In align2pe_module: Can't open such file :"<<strname<<endl;
	}

	string 	pefilename = Formatnewfilename(strname, ".PE", AfxGetValue("-o"));
	ofstream	ofile(pefilename.c_str());
	if(!ofile.good())
	{
		cerr<<"In align2pe_module : Can't open such file :"<<pefilename<<endl;
	}
	int nQ = AfxGetValue("-Q")==NULL?1:atoi(AfxGetValue("-Q"));
	MInsertSD	minssd; // declare in align2pe.h


if(  !getinsertsize(minssd))
{
	cerr << " get insert information wrong ! " << endl;
	return ;
	

}



cout << endl;
cout << "-------------- insert information ----------------"<< endl;

for (MInsertSD::iterator it = minssd.begin();it != minssd.end();++it)
{
	cout <<"\t"<< it->second.ninsert <<"\t" << it->second.nsd << "\t" << it->second.nrsd << "\n";


}
cout << "--------------------------------------------------" << endl;



	map<string, map<string, Pair_End> >	mmpe;//chr10   10-23234   Pair_End
	map<string, vector<_pair_end> >	&mvpe = *((map<string, vector<_pair_end> >*)pvoid);//chr10    vector _pair_end
	string 	str;
	while(getline(ifile, str))
	{
		VString 	vstr;
		split(str, vstr, "\t ");
		if(atoi(vstr[3].c_str()) > nQ)continue;
		CAlign2pe::pe_parseID(vstr[0]);// remove /1 /2
		Pair_End	pe;
		pe.strid = vstr[0];
		pe.ch = vstr[6][0];
		pe.npos = atoi(vstr[8].c_str());
		pe.nrlen = atoi(vstr[5].c_str());
		if(mmpe[vstr[7]].find(vstr[0]) != mmpe[vstr[7]].end())
		{
			convertpe(mvpe, mmpe[vstr[7]][vstr[0]], pe, minssd, ofile, vstr[7]);
			mmpe[vstr[7]].erase(vstr[0]);
		}
		else
		{
			mmpe[vstr[7]][vstr[0]] = pe;
		}
	}
	ifile.close();
	if(ofile.good())
		ofile.close();
}

inline void convertpe(map<string, vector<_pair_end> >& mvpe, Pair_End& pe1, Pair_End& pe2, map<string, InsertSD>& minssd, ofstream& ofile, string& strchr)
{// From Pair_End to _pair_end(for findsv)
	_pair_end	_pe;
	string	insindex = pe1.strid.substr(0, pe1.strid.find('-'));
	if(g_boneinsert) insindex = "*";
	if (pe1.npos < pe2.npos)
	{
		if(pe1.npos+pe1.nrlen > pe2.npos)return;
		_pe.peid = pe1.strid;
		_pe.nStart = pe1.npos;
		_pe.nEnd = pe2.npos + pe2.nrlen;
		_pe.nInsert = minssd[insindex].ninsert;
		_pe.nsd = minssd[insindex].nsd;
		_pe.ch = CH(g_mcc[pe1.ch], g_mcc[pe2.ch]) + '0';
		if(_pe.nInsert > 1000)_pe.ch = g_mRF2FR[_pe.ch];
		pe1.nmean = _pe.nInsert;
		pe1.nsd = _pe.nsd;
		if(CAlign2pe::pe_checknormal(pe1, pe2, _pe.ch))
		{
			if(g_boutputnormal)
				outputpe(_pe, ofile, strchr);
			return;
		}
	}
	else
	{
		if(pe2.npos+pe2.nrlen > pe2.npos)return;
		_pe.peid = pe2.strid;
		_pe.nStart = pe2.npos;
		_pe.nEnd = pe1.npos + pe1.nrlen;
		_pe.nInsert = minssd[insindex].ninsert;
		_pe.nsd = minssd[insindex].nsd;
		_pe.ch = CH(g_mcc[pe1.ch], g_mcc[pe2.ch]) + '0';
		if(_pe.nInsert > 1000)_pe.ch = g_mRF2FR[_pe.ch];
		pe2.nmean = _pe.nInsert;
		pe2.nsd = _pe.nsd;
		if(CAlign2pe::pe_checknormal(pe2, pe1, _pe.ch))
		{
			if(g_boutputnormal)
				outputpe(_pe, ofile, strchr);
			return;
		}
	}
//	if(_pe.nEnd - _pe.nStart > 100000)return;
	mvpe[strchr].push_back(_pe);
	outputpe(_pe, ofile, strchr);
}

void outputpe(_pair_end& _pe, ofstream& ofile, string& strchr) // to make PE reslut like in align2pe 
{
	if(!ofile.good())return;
	ofile<<_pe.ch<<'\t'<<_pe.ch<<'\t'<<_pe.nStart<<'\t'<<_pe.nEnd<<'\t';
	ofile<<"1\t1\t"<<_pe.nInsert<<'-'<<_pe.nsd<<'\t'<<_pe.nEnd - _pe.nStart<<'\t'<<_pe.peid<<'\t'<<strchr<<'\n';
}

bool getinsertsize(MInsertSD& minssd) // need change sd
{// Get insert size information
	char* pinsert = AfxGetValue("-insert");
	if (pinsert == NULL)
	{
		cerr<<"Please make sure -insert isn't null. 0 example: 254-11"<<endl;
		return false ;
	}
	/* Get insert size information from file*/
	string 		str;
	igzstream	ifile(pinsert);
	if(ifile.good())
	{
		while(getline(ifile, str))
		{
			VString 	vstr;

			InsertSD        inssd;

			split(str, vstr, "\t ");

			if(vstr.size() > 2)
			   {

                             inssd.ninsert = atoi(vstr[1].c_str());
			     inssd.nsd  = int(atof(vstr[2].c_str())+0.5);


				if( vstr.size() == 4 ) 
				{
					inssd.nrsd  = int(atof(vstr[3].c_str())+0.5);
				}
				else
				{
					inssd.nrsd  = inssd.nsd;		
				}
			
				minssd[vstr[0]] = inssd;

	
			   }
			else
			  {
				cerr << "Please check your insert infomation file !" << endl;
				return false ;
				
			  }

		}
		ifile.close();
		return  true;
	}
	/***************************************/
	string		str1 = pinsert;
	
	VString         vtemp;

         split(str1,vtemp,"- \t");


	InsertSD    inssd;


	if(vtemp.size() > 1)
        { 

		inssd.ninsert = atoi(vtemp[0].c_str());
		inssd.nsd   = int(atof(vtemp[1].c_str())+0.5);

		  
		 if( vtemp.size() == 3 )
		{
	              inssd.nrsd = int(atof(vtemp[2].c_str())+0.5);
		}
                 else
		{
        	      inssd.nrsd = inssd.nsd;

 		}

		 minssd["*"] = inssd;
	        g_boneinsert = true;

		return true;
	}

	else

	{
		cerr<<"Please make sure -insert isn't null. example: 254-11  or 254-11-12 "<<endl;
		return false;
	}




}

void getpe_from_pefile(string strname, void* pvoid)
{
	cout<<"reading pe......"<<endl;
	map<string, vector<_pair_end> >	&mvpe = *((map<string, vector<_pair_end> >*)pvoid);//chr10    vector _pair_end
	igzstream	ifile(strname.c_str());
	if(!ifile.good())
	{
		cerr<<"In findsv_module : Can't open such file :"<<strname<<endl;
		return;
	}
	string 	str;
	int 	npe = 0;
	while(getline(ifile, str))
	{
		_pair_end	_pe;
		npe++;
		VString		vstr;
		split(str, vstr, "\t ");
		if(vstr.size() != 9)continue;
		_pe.ch = vstr[0][0];
		if (_pe.ch == NOM)
		{
			continue;
		}
		if(vstr.size()==10)_pe.peid = vstr[8];
		_pe.nStart	= atoi(vstr[2].c_str());
		_pe.nEnd		= atoi(vstr[3].c_str());
//		if(_pe.nEnd - _pe.nStart > 100000)continue;
		int     n = vstr[6].find('-');
		string  s1 = vstr[6].substr(0, n);
		string  s2 = vstr[6].substr(n+1, vstr[6].length()-n-1);
		_pe.nInsert	= atoi(s1.c_str());
		_pe.nsd	= atoi(s2.c_str());	

		mvpe[vstr[vstr.size()-1]].push_back(_pe);
	}
	ifile.close();
//	cout<<strname<<endl;
}
/***********************align2pe END*****************/

/***********************findsv module****************/
string findsv_module(string strname, void* pvoid, int n)//n indicate file count. return *.sv name
{
	//Merge PE by chromosome
	cout<<"findsv......"<<endl;
	map<string, vector<_pair_end> >* pmvpe = (map<string, vector<_pair_end> >*)pvoid;
	map<string, vector<_pair_end> >	 mvpe;
	for (int i=0; i<n; i++)
	{
		for(map<string, vector<_pair_end> >::iterator it=pmvpe[i].begin(); it!=pmvpe[i].end(); ++it)
		{
			mvpe[it->first].insert(mvpe[it->first].end(), it->second.begin(), it->second.end());
		//	it->second.clear();
		}
	}
	// Do find sv
	string 	strsvname, strclstname;
	if(AfxGetValue("-2") != NULL)
		strsvname = Formatnewfilename(strname, ".PE.sv", AfxGetValue("-o"));
	else if(AfxGetValue("-3") != NULL)
		strsvname = Formatnewfilename(strname, ".sv", AfxGetValue("-o"));
	if(AfxGetValue("-cluster") != NULL)
		strclstname = Formatnewfilename(strname, ".cluster", AfxGetValue("-o"));
	ofstream	ofilesv(strsvname.c_str());
	ofstream	ofileclst;
	if(!strclstname.empty())
	{
		ofileclst.open(strclstname.c_str());
		if(!ofileclst.good())
		{
			cerr<<"In findsv_module: Can't open such file"<<strclstname<<endl;
		}
	}
	if(!ofilesv.good())
	{
		cerr<<"In findsv_module: Can't open such file"<<strsvname<<endl;
		return "";
	}
	for(map<string, vector<_pair_end> >::iterator it=mvpe.begin(); it!=mvpe.end(); ++it)
	{//cout<<it->first<<'\t'<<it->second.size()<<endl;
		CFindSVEx       findsv;
		findsv.m_strchr = it->first;	
		MVPAIREND       MVPE;//classify PE by insert size
		classify_pe_by_insertsize(it->second, MVPE);
		
		MCLUSTER        mclst;
		for (MVPAIREND::iterator it=MVPE.begin(); it!=MVPE.end(); ++it)
		{

cout << endl;
cout << "------ MVPAIREND key: " << it->first << endl;

			VPAIREND&       VPE = it->second;
			findsv._sort(VPE);
			findsv.findcluster2(VPE, mclst);//Find and classify clusters
		}
		findsv.CombSimCluster(mclst);
		findsv.DetectSV(mclst, ofilesv);

		if(ofileclst.good())
		{
			findsv.cluster(mclst, ofileclst);
		}
	}
	ofilesv.close();
	if(ofileclst.good())ofileclst.close();

	return strsvname;
}

void classify_pe_by_insertsize(vector<_pair_end>& vpe, map<int, vector<_pair_end> >& mvpe)
{
	for(size_t i=0; i<vpe.size(); i++)
	{
		mvpe[vpe[i].nInsert].push_back(vpe[i]);
	}
}
/*****************findsv END***********************/

/******************filtersv module*****************/
void filtersv_module(string strname, void* pvoid)
{
	cout<<endl << "filtersv......"<<endl;
	map<string, vector<sv_info> >	mvsvinf;
	readsv2(strname.c_str(), mvsvinf);
	
	string 	strsvname = Formatnewfilename(strname, ".SV", AfxGetValue("-o"));
	ofstream	ofile(strsvname.c_str());
	if(!ofile.good())
	{
		cerr<<"In filtersv_module : Can't open such file : "<<strsvname<<endl;
	   return ;	
	}
	for(map<string, vector<sv_info> >::iterator it=mvsvinf.begin(); it!=mvsvinf.end(); ++it)
	{
		CFilterSV	filtersv;
		filtersv.m_strchr = it->first;
		filtersv.m_vSV.swap(it->second);
		filtersv.verifysv2();
		filtersv.outputsv2(ofile);
	}
	ofile.close();
}

int readsv2( const char* p, map<string,vector<sv_info> >& mvsvinf )
{
	if (p == NULL)
		return 0;
	sv_info		si;
	igzstream	ifile(p);
	if(!ifile.good())
	{
		printf("Can't open file : %s\n", p);
		return 0;
	}
	string	str;int index=0;
	while (getline(ifile, str))
	{//cout<<++index<<endl;
		si.vconnectinfo.clear();
		VString		vstr;
		split(str, vstr, "\t ");
		
		if (vstr[1][vstr[1].length()-1]=='1' || vstr[1][vstr[1].length()-1]=='2')
		{
			vstr[1].erase(vstr[1].length()-1, 1);
		}
		si.type = vstr[1];
		si.sid = vstr[2];
		si.start = atoi(vstr[3].c_str());
		si.end = atoi(vstr[4].c_str());
		if (strcmp(vstr[1].c_str(), "Deletion")==0)
		{//Deletion       3191 41721827        41723150        Deletion-Loc:   41721826        41723162        FR-41721827:        280		
			si.ls = atoi(vstr[6].c_str());
			si.le = atoi(vstr[7].c_str());
			connectinfo	ci;
			ci.str = vstr[8].substr(0, 2);
			ci.ncount = atoi(vstr[9].c_str());
			si.vconnectinfo.push_back(ci);
			si.nbreakpoint = 0;
		}
		else if (strcmp(vstr[1].c_str(), "Invertion")==0)
		{//Inversion      I1-3    41717878        41850680        Inversion-Loc:  41718315        41850472        FF-931: 1       RR-41718753:    1
			si.ls = atoi(vstr[6].c_str());
			si.le = atoi(vstr[7].c_str());
			si.nbreakpoint = 0;
			connectinfo ci;
			ci.str = vstr[8].substr(0, 2);
			ci.ncount = atoi(vstr[9].c_str());
			si.vconnectinfo.push_back(ci);
			ci.str = vstr[10].substr(0, 2);
			ci.ncount = atoi(vstr[11].c_str());
			si.vconnectinfo.push_back(ci);
		}
		else if (strcmp(vstr[1].c_str(), "Insertion")==0)
		{//Insertion      Ins1-1  475624  476997  Insertion-Loc:  475624  476997  InsertBreakpoint:  476311 RF*-475624:     1
			si.ls = atoi(vstr[6].c_str());
			si.le = atoi(vstr[7].c_str());
			si.nbreakpoint = atoi(vstr[9].c_str());
			connectinfo ci;
			ci.str = vstr[10].substr(0, 2);
			ci.ncount = atoi(vstr[11].c_str());
			si.vconnectinfo.push_back(ci);
		}
		else if (strcmp(vstr[1].c_str(), "TandemDuplication")==0)
		{//TandemDuplication     TD1-46  41680781        41699897        Duplication-Loc:        41680658        41699998        RF-31:  21
			si.ls = atoi(vstr[6].c_str());
			si.le = atoi(vstr[7].c_str());
			si.nbreakpoint = 0;
			connectinfo ci;
			ci.str = vstr[8].substr(0, 2);
			ci.ncount = atoi(vstr[9].c_str());
			si.vconnectinfo.push_back(ci);
		}
		else if (strcmp(vstr[1].c_str(), "Inversion+Deletion")==0 || strcmp(vstr[1].c_str(), "Deletion+Inversion")==0)
		{//Inversion+Deletion      DI-2    Inversion:      41718200        41850637        Deletion:       41850637        41859028        Inversion-Loc:  41718735        41850646        Deletion-Loc:   41719258        41859028        FF-429: 5       RR-41719258:    14
		 //Deletion+Inversion      DI-1    Deletion:       70058767        70064221        Inversion:      70064221        70077009        Deletion-Loc:   70058865        70064155        Inversion-Loc:  70064155        70076604        FF-70058767:    14      RR-70064221:    6
			si.start = atoi(vstr[4].c_str());
			si.end = atoi(vstr[8].c_str());
			si.ls = atoi(vstr[10].c_str());
			si.le = atoi(vstr[14].c_str());
			si.nbreakpoint = 0;
			connectinfo ci;
			ci.str = vstr[15].substr(0, 2);
			ci.ncount = atoi(vstr[16].c_str());
			si.vconnectinfo.push_back(ci);
			ci.str = vstr[17].substr(0, 2);
			ci.ncount = atoi(vstr[18].c_str());
			si.vconnectinfo.push_back(ci);	
		}
		else if (strcmp(vstr[1].c_str(), "Translocation_upstream")==0)
		{//Translocation_upstream T-10    26908828        26989670        InsertBreakpoint:       26915432        Translocation-Loc:      26964240        26985348        FR-699:        1       RF-26922037:    1       FR-26955914:   1
			si.ls = atoi(vstr[8].c_str());
			si.le = atoi(vstr[9].c_str());
			si.nbreakpoint = atoi(vstr[6].c_str());
			connectinfo ci;
			ci.str = vstr[10].substr(0, 2);
			ci.ncount = atoi(vstr[11].c_str());
			si.vconnectinfo.push_back(ci);
			ci.str = vstr[12].substr(0, 2);
			ci.ncount = atoi(vstr[13].c_str());
			si.vconnectinfo.push_back(ci);
			ci.str = vstr[14].substr(0, 2);
			ci.ncount = atoi(vstr[15].c_str());
			si.vconnectinfo.push_back(ci);

		}
		else if (strcmp(vstr[1].c_str(), "Translocation_downstream")==0)
		{//Translocation_downstream       Td-186811        41718470        41729251        Translocation-Loc:      41718563        41719109        InsertBreakpoint:       41727272        FR-947:        1       RF-41718657:    1       FR-41718957:   1
			si.ls = atoi(vstr[6].c_str());
			si.le = atoi(vstr[7].c_str());
			si.nbreakpoint = atoi(vstr[8].c_str());
			connectinfo ci;
			ci.str = vstr[9].substr(0, 2);
			ci.ncount = atoi(vstr[10].c_str());
			si.vconnectinfo.push_back(ci);
			ci.str = vstr[11].substr(0, 2);
			ci.ncount = atoi(vstr[12].c_str());
			si.vconnectinfo.push_back(ci);
			ci.str = vstr[13].substr(0, 2);
			ci.ncount = atoi(vstr[14].c_str());
			si.vconnectinfo.push_back(ci);
		}
		else if (strcmp(vstr[1].c_str(), "DispersedDuplication_upstream")==0)
		{//DispersedDuplication_upstream  DDu-4   41679972        41699886        InsertBreakpoint:       41680062        Duplication-Loc:        41680155        41699887        FR-0:   1       RF-41680154:    3
			si.ls = atoi(vstr[8].c_str());
			si.le = atoi(vstr[9].c_str());
			si.nbreakpoint = atoi(vstr[6].c_str());
			connectinfo ci;
			ci.str = vstr[10].substr(0, 2);
			ci.ncount = atoi(vstr[11].c_str());
			si.vconnectinfo.push_back(ci);
			ci.str = vstr[12].substr(0, 2);
			ci.ncount = atoi(vstr[13].c_str());
			si.vconnectinfo.push_back(ci);
		}
		else if (strcmp(vstr[1].c_str(), "DispersedDuplication_downstream")==0)
		{//DispersedDuplication_downstream        DDd-1   41680035        41700645        Duplication-Loc:        41680006        41680063        IInsertBreakpoint:       41700456        RF-2:   4       FR-41680063:    1
			si.ls = atoi(vstr[6].c_str());
			si.le = atoi(vstr[7].c_str());
			si.nbreakpoint = atoi(vstr[9].c_str());
			connectinfo ci;
			ci.str = vstr[10].substr(0, 2);
			ci.ncount = atoi(vstr[11].c_str());
			si.vconnectinfo.push_back(ci);
			ci.str = vstr[12].substr(0, 2);
			ci.ncount = atoi(vstr[13].c_str());
			si.vconnectinfo.push_back(ci);
		}
		else if (strcmp(vstr[1].c_str(), "Translocation+Invertion_upstream")==0)
		{//Translocation+Inversion_upstream       TIu-20  41717878        41860013        InversionBreakpoint:    41718308        Translcation-Loc:       41847342        41855134        FF-931: 1       RR-41718738:    1       FR-41846009:    3
			si.ls = atoi(vstr[8].c_str());
			si.le = atoi(vstr[9].c_str());
			si.nbreakpoint = atoi(vstr[6].c_str());
			connectinfo ci;
			ci.str = vstr[10].substr(0, 2);
			ci.ncount = atoi(vstr[11].c_str());
			si.vconnectinfo.push_back(ci);
			ci.str = vstr[12].substr(0, 2);
			ci.ncount = atoi(vstr[13].c_str());
			si.vconnectinfo.push_back(ci);
			ci.str = vstr[14].substr(0, 2);
			ci.ncount = atoi(vstr[15].c_str());
			si.vconnectinfo.push_back(ci);
		}
		else if (strcmp(vstr[1].c_str(), "Translocation+Invertion_downstream")==0)
		{//Translocation+Inversion_downstream     TId-1   41704870        41852778        Translocation-Loc:      41711441        41718133        InversionBreakpoint:    41852255        FR-593: 1       RR-41718012:    1       FF-41718122:    1
			si.ls = atoi(vstr[6].c_str());
			si.le = atoi(vstr[7].c_str());
			si.nbreakpoint = atoi(vstr[9].c_str());
			connectinfo ci;
			ci.str = vstr[10].substr(0, 2);
			ci.ncount = atoi(vstr[11].c_str());
			si.vconnectinfo.push_back(ci);
			ci.str = vstr[12].substr(0, 2);
			ci.ncount = atoi(vstr[13].c_str());
			si.vconnectinfo.push_back(ci);
			ci.str = vstr[14].substr(0, 2);
			ci.ncount = atoi(vstr[15].c_str());
			si.vconnectinfo.push_back(ci);
		}
		else if (strcmp(vstr[1].c_str(), "Duplication+Invertion_upstream")==0)
		{//Duplication+Inversion_upstream DIu-3   41717878        41850265        InversionBreakpoint:    41718308        Duplication-Loc:        41848672        41850265        FF-931: 1       RR-41718738:    1
			si.ls = atoi(vstr[8].c_str());
			si.le = atoi(vstr[9].c_str());
			si.nbreakpoint = atoi(vstr[6].c_str());
			connectinfo ci;
			ci.str = vstr[10].substr(0, 2);
			ci.ncount = atoi(vstr[11].c_str());
			si.vconnectinfo.push_back(ci);
			ci.str = vstr[12].substr(0, 2);
			ci.ncount = atoi(vstr[13].c_str());
			si.vconnectinfo.push_back(ci);
		}
		else if (strcmp(vstr[1].c_str(), "Duplication+Invertion_downstream")==0)
		{//Duplication+Inversion_downstream       DId-3   169530153       169531587       Duplication-Loc:        169530153       169530245       InversionBreakpoint:    169531341     RR-169530153:   13      FF-169530200:   11
			si.ls = atoi(vstr[6].c_str());
			si.le = atoi(vstr[7].c_str());
			si.nbreakpoint = atoi(vstr[9].c_str());
			connectinfo ci;
			ci.str = vstr[10].substr(0, 2);
			ci.ncount = atoi(vstr[11].c_str());
			si.vconnectinfo.push_back(ci);
			ci.str = vstr[12].substr(0, 2);
			ci.ncount = atoi(vstr[13].c_str());
			si.vconnectinfo.push_back(ci);
		}
		if (!((si.start <=si.ls && si.ls <=si.end) || (si.ls<=si.start && si.start<=si.le)))continue;
		//cout<<si.start<<'\t'<<si.end<<'\t'<<si.ls<<'\t'<<si.le<<'\n';
		mvsvinf[vstr[0]].push_back(si);
	}
	
	ifile.close();
	return 0;
}
/***************filtersv END **********************/
#endif
