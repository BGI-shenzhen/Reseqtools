#ifndef _FILTERSV_SVH_
#define _FILTERSV_SVH_
/************************************************************************/
/*                                                                      */
#include "include.h"
#include "common.h"
#include "main.h"
#include <sys/stat.h>


struct filtersv_thread_param
{
	int 		threadcount;
	string		sname;
	VString*	pVstr;
};

struct connectinfo
{
	string 	str;
	int 	ncount;
};

struct sv_info 
{
	sv_info(){bcombined=false;}
	string				type;
	string				sid;
	int					start;
	int					end;
	int					ls;
	int					le;
	bool				bcombined;
	int					nbreakpoint;
	int					size(){return end-start;}
	vector<connectinfo>	vconnectinfo;
};

typedef vector<sv_info>			vsv_info;

/************************************************************************/
/*                                                                      */
class CFilterSV
{
public:
	CFilterSV();
	~CFilterSV();

	int			readsv2(const char* p);
	void		verifysv2();
	/********************************************/
	//for future replacement of verifysv2()
	void		verifysv3();
	/********************************************/
	void		outputsv2(ofstream& ofile);
	void		drawimage(const char* p);

private:
	void		outputother(ofstream& ofile, vsv_info& vsv);
	void		deepfilte(ofstream& ofile, vsv_info& vsv);
public:
	vsv_info				m_vSV;// All sv from *.sv were read into this verctor. From readsv2()
	string					m_strchr;//chromosome id
private:
	vector<vsv_info>		m_vvsvinfo;
};
/************************************************************************/
void*	__filtersv_process(void*);

//////////////////////////////////////////////////////////////////////////
COLORREF	g_clr[6] = 
{
	g_clr[0] = RGB(255, 0, 0),
		g_clr[1] = RGB(0, 255, 0),
		g_clr[2] = RGB(255, 0, 255),
		g_clr[3] = RGB(0, 255, 255),
		g_clr[4] = RGB(0, 255, 0),
		g_clr[5] = RGB(0, 255, 0)
};

const char* g_ptype[] = 
{
	"FF", "FR", "RF", "RR", "FR"
};

//////////////////////////////////////////////////////////////////////////

void getfilefromlist(VString& vstr)
{
	if (vstr.size() != 0)
		return;
	
	char	*pfile = AfxGetValue("--i");
	if(pfile == NULL)return;
	string s = pfile;
	string tmp = s.substr(s.rfind('.')+1, s.length()-s.rfind('.')-1);
	if (strcmp(tmp.c_str(), "l")==0 || strcmp(tmp.c_str(), "L")==0 || strcmp(tmp.c_str(), "list")==0 || strcmp(tmp.c_str(), "lst")==0 )
	{
		igzstream	ifile(pfile);
		string		str;
		vstr.clear();
		while (getline(ifile, str))
		{
			vstr.push_back(str);
		}
		ifile.close();
	}
	else
	{
		vstr.push_back(s);
	}
}

int main_filtersv(int argc, char* argv[], void* pVoid)
{//chr1	return 1;
	cout<<"filtersv....."<<endl;
#ifdef MODULE
	AfxGetOptions(argc, argv);
#endif
	VString*	pVstr = &(((global_param*)pVoid)->vstr);
	getfilefromlist(*pVstr);

	int		nth=0;
	if ((nth=pVstr->size()) == 0)
		return 0;
	VString		vfile;
	vfile.swap(*pVstr);

	char*   pcpu = AfxGetValue("-cpu");
	int		cpu = (pcpu==NULL) ? 4 : atoi(pcpu);

	CThreadManager		threadMgr(cpu);
	vector<filtersv_thread_param>		vtp(nth);
	for (int i=0; i<nth; i++)
	{
//		vtp[i].sname = vfile[i];
		threadMgr.AddThread(__filtersv_process, &vfile[i]);
	}
	threadMgr.Run();
	
	return 1;
}

void* __filtersv_process(void* param)
{
//	filtersv_thread_param *pParam = (filtersv_thread_param*)param;
	string	sname = *((string*)param);
	CFilterSV		filter;
	if(filter.readsv2(sname.c_str())==0)
		return NULL;
	filter.verifysv2();
	string	strsvname = Formatnewfilename(sname, ".SV", AfxGetValue("-o"));
	ofstream	ofile(strsvname.c_str());
	if(!ofile.good())
	{
		cerr<<"In __filtersv_process : Can't open such file : "<<strsvname<<endl;
		return NULL;
	}
	filter.outputsv2(ofile);
	filter.drawimage(sname.c_str());
	ofile.close();
}

CFilterSV::CFilterSV()
{
	
}

CFilterSV::~CFilterSV()
{
}

int CFilterSV::readsv2( const char* p )
{
	if (p == NULL)
		return 0;
	sv_info		si;
	igzstream	ifile(p);
	if(!ifile.good())
	{
		printf("Can't open file : %s\n", p);
		return 0;
	}
	string	str;int index=0;
	while (getline(ifile, str))
	{
		si.vconnectinfo.clear();
		VString		vstr;
		split(str, vstr, "\t ");

		if (vstr[1][vstr[1].length()-1]=='1' || vstr[1][vstr[1].length()-1]=='2')
		{
			vstr[1].erase(vstr[1].length()-1, 1);
		}
		si.type = vstr[1];
		si.sid = vstr[2];
		si.start = atoi(vstr[3].c_str());
		si.end = atoi(vstr[4].c_str());
		m_strchr = vstr[0];
		if (strcmp(vstr[1].c_str(), "Deletion")==0)
		{//chr1	Deletion       3191 41721827        41723150        Deletion-Loc:   41721826        41723162        FR-41721827:        280		
			si.ls = atoi(vstr[6].c_str());
			si.le = atoi(vstr[7].c_str());
			connectinfo	ci;
			ci.str = vstr[8].substr(0, 2);
			ci.ncount = atoi(vstr[9].c_str());
			si.vconnectinfo.push_back(ci);
			si.nbreakpoint = 0;
		}
		else if (strcmp(vstr[1].c_str(), "Invertion")==0)
		{//chr1	Inversion      I1-3    41717878        41850680        Inversion-Loc:  41718315        41850472        FF-931: 1       RR-41718753:    1
			si.ls = atoi(vstr[6].c_str());
			si.le = atoi(vstr[7].c_str());
			si.nbreakpoint = 0;
			connectinfo ci;
			ci.str = vstr[8].substr(0, 2);
			ci.ncount = atoi(vstr[9].c_str());
			si.vconnectinfo.push_back(ci);
			ci.str = vstr[10].substr(0, 2);
			ci.ncount = atoi(vstr[11].c_str());
			si.vconnectinfo.push_back(ci);
		}
		else if (strcmp(vstr[1].c_str(), "Insertion")==0)
		{//chr1	Insertion      Ins1-1  475624  476997  Insertion-Loc:  475624  476997  InsertBreakpoint:  476311 RF*-475624:     1
			si.ls = atoi(vstr[6].c_str());
			si.le = atoi(vstr[7].c_str());
			si.nbreakpoint = atoi(vstr[9].c_str());
			connectinfo ci;//cout<<"2"<<endl;
			ci.str = vstr[10].substr(0, 2);
			ci.ncount = atoi(vstr[11].c_str());
			si.vconnectinfo.push_back(ci);
		}
		else if (strcmp(vstr[1].c_str(), "TandemDuplication")==0)
		{//chr1	TandemDuplication     TD1-46  41680781        41699897        Duplication-Loc:        41680658        41699998        RF-31:  21
			si.ls = atoi(vstr[6].c_str());
			si.le = atoi(vstr[7].c_str());
			si.nbreakpoint = 0;
			connectinfo ci;
			ci.str = vstr[8].substr(0, 2);
			ci.ncount = atoi(vstr[9].c_str());
			si.vconnectinfo.push_back(ci);
		}
		else if (strcmp(vstr[1].c_str(), "Inversion+Deletion")==0 || strcmp(vstr[1].c_str(), "Deletion+Inversion")==0)
		{//chr1	Inversion+Deletion      DI-2    Inversion:      41718200        41850637        Deletion:       41850637        41859028        Inversion-Loc:  41718735        41850646        Deletion-Loc:   41719258        41859028        FF-429: 5       RR-41719258:    14
		 //Deletion+Inversion      DI-1    Deletion:       70058767        70064221        Inversion:      70064221        70077009        Deletion-Loc:   70058865        70064155        Inversion-Loc:  70064155        70076604        FF-70058767:    14      RR-70064221:    6
			si.start = atoi(vstr[4].c_str());
			si.end = atoi(vstr[8].c_str());
			si.ls = atoi(vstr[10].c_str());
			si.le = atoi(vstr[14].c_str());
			si.nbreakpoint = 0;
			connectinfo ci;
			ci.str = vstr[15].substr(0, 2);
			ci.ncount = atoi(vstr[16].c_str());
			si.vconnectinfo.push_back(ci);
			ci.str = vstr[17].substr(0, 2);
			ci.ncount = atoi(vstr[18].c_str());
			si.vconnectinfo.push_back(ci);	
		}
		else if (strcmp(vstr[1].c_str(), "Translocation_upstream")==0)
		{//chr1	Translocation_upstream T-10    26908828        26989670        InsertBreakpoint:       26915432        Translocation-Loc:      26964240        26985348        FR-699:        1       RF-26922037:    1       FR-26955914:   1
			si.ls = atoi(vstr[8].c_str());
			si.le = atoi(vstr[9].c_str());
			si.nbreakpoint = atoi(vstr[6].c_str());
			connectinfo ci;
			ci.str = vstr[10].substr(0, 2);
			ci.ncount = atoi(vstr[11].c_str());
			si.vconnectinfo.push_back(ci);
			ci.str = vstr[12].substr(0, 2);
			ci.ncount = atoi(vstr[13].c_str());
			si.vconnectinfo.push_back(ci);
			ci.str = vstr[14].substr(0, 2);
			ci.ncount = atoi(vstr[15].c_str());
			si.vconnectinfo.push_back(ci);

		}
		else if (strcmp(vstr[1].c_str(), "Translocation_downstream")==0)
		{//chr1	Translocation_downstream       Td-186811        41718470        41729251        Translocation-Loc:      41718563        41719109        InsertBreakpoint:       41727272        FR-947:        1       RF-41718657:    1       FR-41718957:   1
			si.ls = atoi(vstr[6].c_str());
			si.le = atoi(vstr[7].c_str());
			si.nbreakpoint = atoi(vstr[8].c_str());
			connectinfo ci;
			ci.str = vstr[9].substr(0, 2);
			ci.ncount = atoi(vstr[10].c_str());
			si.vconnectinfo.push_back(ci);
			ci.str = vstr[11].substr(0, 2);
			ci.ncount = atoi(vstr[12].c_str());
			si.vconnectinfo.push_back(ci);
			ci.str = vstr[13].substr(0, 2);
			ci.ncount = atoi(vstr[14].c_str());
			si.vconnectinfo.push_back(ci);
		}
		else if (strcmp(vstr[1].c_str(), "DispersedDuplication_upstream")==0)
		{//chr1	DispersedDuplication_upstream  DDu-4   41679972        41699886        InsertBreakpoint:       41680062        Duplication-Loc:        41680155        41699887        FR-0:   1       RF-41680154:    3
			si.ls = atoi(vstr[8].c_str());
			si.le = atoi(vstr[9].c_str());
			si.nbreakpoint = atoi(vstr[6].c_str());
			connectinfo ci;
			ci.str = vstr[10].substr(0, 2);
			ci.ncount = atoi(vstr[11].c_str());
			si.vconnectinfo.push_back(ci);
			ci.str = vstr[12].substr(0, 2);
			ci.ncount = atoi(vstr[13].c_str());
			si.vconnectinfo.push_back(ci);
		}
		else if (strcmp(vstr[1].c_str(), "DispersedDuplication_downstream")==0)
		{//chr1	DispersedDuplication_downstream        DDd-1   41680035        41700645        Duplication-Loc:        41680006        41680063        IInsertBreakpoint:       41700456        RF-2:   4       FR-41680063:    1
			si.ls = atoi(vstr[6].c_str());
			si.le = atoi(vstr[7].c_str());
			si.nbreakpoint = atoi(vstr[9].c_str());
			connectinfo ci;
			ci.str = vstr[10].substr(0, 2);
			ci.ncount = atoi(vstr[11].c_str());
			si.vconnectinfo.push_back(ci);
			ci.str = vstr[12].substr(0, 2);
			ci.ncount = atoi(vstr[13].c_str());
			si.vconnectinfo.push_back(ci);
		}
		else if (strcmp(vstr[1].c_str(), "Translocation+Invertion_upstream")==0)
		{//chr1	Translocation+Inversion_upstream       TIu-20  41717878        41860013        InversionBreakpoint:    41718308        Translcation-Loc:       41847342        41855134        FF-931: 1       RR-41718738:    1       FR-41846009:    3
			si.ls = atoi(vstr[8].c_str());
			si.le = atoi(vstr[9].c_str());
			si.nbreakpoint = atoi(vstr[6].c_str());
			connectinfo ci;
			ci.str = vstr[10].substr(0, 2);
			ci.ncount = atoi(vstr[11].c_str());
			si.vconnectinfo.push_back(ci);
			ci.str = vstr[12].substr(0, 2);
			ci.ncount = atoi(vstr[13].c_str());
			si.vconnectinfo.push_back(ci);
			ci.str = vstr[14].substr(0, 2);
			ci.ncount = atoi(vstr[15].c_str());
			si.vconnectinfo.push_back(ci);
		}
		else if (strcmp(vstr[1].c_str(), "Translocation+Invertion_downstream")==0)
		{//chr1	Translocation+Inversion_downstream     TId-1   41704870        41852778        Translocation-Loc:      41711441        41718133        InversionBreakpoint:    41852255        FR-593: 1       RR-41718012:    1       FF-41718122:    1
			si.ls = atoi(vstr[6].c_str());
			si.le = atoi(vstr[7].c_str());
			si.nbreakpoint = atoi(vstr[9].c_str());
			connectinfo ci;
			ci.str = vstr[10].substr(0, 2);
			ci.ncount = atoi(vstr[11].c_str());
			si.vconnectinfo.push_back(ci);
			ci.str = vstr[12].substr(0, 2);
			ci.ncount = atoi(vstr[13].c_str());
			si.vconnectinfo.push_back(ci);
			ci.str = vstr[14].substr(0, 2);
			ci.ncount = atoi(vstr[15].c_str());
			si.vconnectinfo.push_back(ci);
		}
		else if (strcmp(vstr[1].c_str(), "Duplication+Invertion_upstream")==0)
		{//chr1	Duplication+Inversion_upstream DIu-3   41717878        41850265        InversionBreakpoint:    41718308        Duplication-Loc:        41848672        41850265        FF-931: 1       RR-41718738:    1
			si.ls = atoi(vstr[8].c_str());
			si.le = atoi(vstr[9].c_str());
			si.nbreakpoint = atoi(vstr[6].c_str());
			connectinfo ci;
			ci.str = vstr[10].substr(0, 2);
			ci.ncount = atoi(vstr[11].c_str());
			si.vconnectinfo.push_back(ci);
			ci.str = vstr[12].substr(0, 2);
			ci.ncount = atoi(vstr[13].c_str());
			si.vconnectinfo.push_back(ci);
		}
		else if (strcmp(vstr[1].c_str(), "Duplication+Invertion_downstream")==0)
		{//chr1	Duplication+Inversion_downstream       DId-3   169530153       169531587       Duplication-Loc:        169530153       169530245       InversionBreakpoint:    169531341     RR-169530153:   13      FF-169530200:   11
			si.ls = atoi(vstr[6].c_str());
			si.le = atoi(vstr[7].c_str());
			si.nbreakpoint = atoi(vstr[9].c_str());
			connectinfo ci;
			ci.str = vstr[10].substr(0, 2);
			ci.ncount = atoi(vstr[11].c_str());
			si.vconnectinfo.push_back(ci);
			ci.str = vstr[12].substr(0, 2);
			ci.ncount = atoi(vstr[13].c_str());
			si.vconnectinfo.push_back(ci);
		}
		if (!((si.start <=si.ls && si.ls <=si.end) || (si.ls<=si.start && si.start<=si.le)))continue;
		//cout<<si.start<<'\t'<<si.end<<'\t'<<si.ls<<'\t'<<si.le<<'\n';
		m_vSV.push_back(si);
	}
	ifile.close();
	return m_vSV.size();
}

void CFilterSV::verifysv2()
{
	if (m_vSV.size() == 0)
		return ;

	for (size_t i=0; i<m_vSV.size(); i++)
	{
		if(m_vSV[i].bcombined)continue;
		vsv_info	vsv;
		vsv.push_back(m_vSV[i]);
		m_vSV[i].bcombined = true;
		for (size_t j=i+1; j<m_vSV.size(); j++)
		{
			if (m_vSV[j].size()/m_vSV[i].size() >= 5 || m_vSV[i].size()/m_vSV[j].size() >= 5)
				continue;
			if (m_vSV[i].end - m_vSV[j].start > 0.5*m_vSV[i].size() || m_vSV[i].end - m_vSV[j].start > 0.5*m_vSV[j].size())
			{
				vsv.push_back(m_vSV[j]);
				m_vSV[j].bcombined = true;
			}
			else
			{
				m_vvsvinfo.push_back(vsv);
				vsv.clear();
				break;
			}
		}
		if (vsv.size() != 0)
		{
			m_vvsvinfo.push_back(vsv);
			vsv.clear();
		}
	}
}

void CFilterSV::outputsv2( ofstream& ofile )
{
	if(m_vvsvinfo.size() == 0)return;

	for (size_t i=0; i<m_vvsvinfo.size(); i++)
	{
		if(m_vvsvinfo[i].size() == 1)
		{
			ofile<<m_strchr<<'\t';
			ofile<<m_vvsvinfo[i][0].type<<'\t'<<m_vvsvinfo[i][0].start<<'\t'<<m_vvsvinfo[i][0].end<<'\t';
			ofile<<m_vvsvinfo[i][0].ls<<'\t'<<m_vvsvinfo[i][0].le<<'\t'<<m_vvsvinfo[i][0].le-m_vvsvinfo[i][0].ls<<'\t';
			if(m_vvsvinfo[i][0].nbreakpoint==0)
				ofile<<"0-0-0"<<'\t';
			else
				ofile<<m_vvsvinfo[i][0].ls<<'-'<<m_vvsvinfo[i][0].nbreakpoint<<'-'<<m_vvsvinfo[i][0].le<<'\t';
			for (size_t j=0; j<m_vvsvinfo[i][0].vconnectinfo.size(); j++)
			{
				ofile<<m_vvsvinfo[i][0].vconnectinfo[j].str<<'\t'<<m_vvsvinfo[i][0].vconnectinfo[j].ncount<<'\t';
			}
			ofile<<'\n';
		}
		else
			outputother(ofile, m_vvsvinfo[i]);
	}
}

struct cmp1
{
	cmp1(int n):m_n(n){}
	bool operator()(sv_info& a, sv_info& b)
	{
		return (m_n==0) ? (a.start < b.start) : (a.end < b.end);
	}
	
	int m_n;
};

void joinconnectinfo(vsv_info& vsv)
{
	for (size_t i=1; i<vsv.size(); i++)
	{
		for (size_t j=0; j<vsv[i].vconnectinfo.size(); j++)
		{
			vsv[0].vconnectinfo[j].ncount += vsv[i].vconnectinfo[j].ncount;
		}
	}
}
void CFilterSV::outputother( ofstream& ofile, vsv_info& vsv )
{
	bool		bcomplex = false;
	for (size_t i=1; i<vsv.size(); i++)
	{
		if (strcmp(vsv[i].type.c_str(), vsv[0].type.c_str()) == 0)
		{
			continue;
		}
		else
			bcomplex = true;
	}

	int		maxs = max_element(vsv.begin(), vsv.end(), cmp1(0))->start;
	int		mins = min_element(vsv.begin(), vsv.end(), cmp1(0))->start;
	int		maxe = max_element(vsv.begin(), vsv.end(), cmp1(1))->end;
	int		mine = min_element(vsv.begin(), vsv.end(), cmp1(1))->end;

	if (bcomplex)
	{
		deepfilte(ofile, vsv);
	}
	else
	{
		joinconnectinfo(vsv);
		ofile<<m_strchr<<'\t';
		ofile<<vsv[0].type<<'\t'<<mins<<'\t'<<maxe<<'\t';
		if(maxs >= mine) 
		{
			ofile<<mins<<'\t'<<maxe<<'\t'<<maxe-mins<<'\t';
			if(vsv[0].nbreakpoint==0)
				ofile<<"0-0-0"<<'\t';
			else
				ofile<<vsv[0].ls<<'-'<<vsv[0].nbreakpoint<<'-'<<vsv[0].le<<'\t';
			for(size_t j=0; j<vsv[0].vconnectinfo.size(); j++)
			{
				ofile<<vsv[0].vconnectinfo[j].str<<'\t'<<vsv[0].vconnectinfo[j].ncount<<'\t';
			}
			ofile<<'\n';
			return;
		}
		else
		{
			ofile<<maxs<<'\t'<<mine<<'\t'<<mine-maxs<<'\t';
			if(vsv[0].nbreakpoint==0)
				ofile<<"0-0-0"<<'\t';
			else
				ofile<<vsv[0].ls<<'-'<<vsv[0].nbreakpoint<<'-'<<vsv[0].le<<'\t';
			for(size_t j=0; j<vsv[0].vconnectinfo.size(); j++)
			{
				ofile<<vsv[0].vconnectinfo[j].str<<'\t'<<vsv[0].vconnectinfo[j].ncount<<'\t';
			}
			ofile<<'\n';	
		}
	}
}

struct Check_SV_Type
{
	Check_SV_Type(const char* ps)
	{
		pstr = const_cast<char*>(ps);
	}
	bool	operator()(sv_info& si)
	{
		return (strcmp(si.type.c_str(), pstr)==0);
	}
	char*		pstr;
};
void CFilterSV::deepfilte( ofstream& ofile, vsv_info& vsv )
{
	vsv_info::iterator	it;
	if(vsv.size()<10)
	{
		if (((find_if(vsv.begin(), vsv.end(), Check_SV_Type("Deletion")))!=vsv.end()||
			(find_if(vsv.begin(), vsv.end(), Check_SV_Type("Insertion")))!=vsv.end()) && 
			(find_if(vsv.begin(), vsv.end(), Check_SV_Type("TandemDuplication")))!=vsv.end())
		{
			vsv_info::iterator	it1;
			if((it=find_if(vsv.begin(), vsv.end(), Check_SV_Type("Translocation_downstream")))!=vsv.end() ||
				(it1=find_if(vsv.begin(), vsv.end(), Check_SV_Type("Translocation_upstream")))!=vsv.end())
			{
				if(it!=vsv.end() && it1!=vsv.end())
				{
					int		maxs = max_element(vsv.begin(), vsv.end(), cmp1(0))->start;
					int		mins = min_element(vsv.begin(), vsv.end(), cmp1(0))->start;
					int		maxe = max_element(vsv.begin(), vsv.end(), cmp1(1))->end;
					int		mine = min_element(vsv.begin(), vsv.end(), cmp1(1))->end;
					ofile<<m_strchr<<'\t';
					ofile<<"Complex\t"<<mins<<'\t'<<maxe<<'\t'<<mins<<'\t'<<maxe<<'\t'<<maxe-mins<<'\t';
					ofile<<"0-0-0"<<'\n';
					return;
				}
				if(it==vsv.end())it=it1;
				ofile<<m_strchr<<'\t';
				ofile<<it->type<<'\t'<<it->start<<'\t'<<it->end<<'\t'<<it->ls<<'\t'<<it->le<<'\t'<<it->le-it->ls<<'\t';
				ofile<<it->ls<<'-'<<it->nbreakpoint<<'-'<<it->le<<'\t';

				for(size_t j=0; j<it->vconnectinfo.size(); j++)
				{
					ofile<<it->vconnectinfo[j].str<<'\t'<<it->vconnectinfo[j].ncount<<'\t';
				}
				ofile<<'\n';
			}
			else
			{
				if((it=find_if(vsv.begin(), vsv.end(), Check_SV_Type("DispersedDuplication_upstream")))!=vsv.end())
				{
					ofile<<m_strchr<<'\t';
					ofile<<it->type<<'\t'<<it->start<<'\t'<<it->end<<'\t'<<it->ls<<'\t'<<it->le<<'\t'<<it->le-it->ls<<'\t';
					ofile<<it->ls<<'-'<<it->nbreakpoint<<'-'<<it->le<<'\t';
				}
				else if((it=find_if(vsv.begin(), vsv.end(), Check_SV_Type("DispersedDuplication_downstream")))!=vsv.end())
				{
					ofile<<m_strchr<<'\t';
					ofile<<it->type<<'\t'<<it->start<<'\t'<<it->end<<'\t'<<it->ls<<'\t'<<it->le<<'\t'<<it->le-it->ls<<'\t';
					ofile<<it->ls<<'-'<<it->nbreakpoint<<'-'<<it->le<<'\t';
				}
				if(it != vsv.end())
				{
					for(size_t j=0; j<it->vconnectinfo.size(); j++)
					{
						ofile<<it->vconnectinfo[j].str<<'\t'<<it->vconnectinfo[j].ncount<<'\t';
					}
					ofile<<'\n';
				}
			}
		}
	}
	else
	{
		int		maxs = max_element(vsv.begin(), vsv.end(), cmp1(0))->start;
		int		mins = min_element(vsv.begin(), vsv.end(), cmp1(0))->start;
		int		maxe = max_element(vsv.begin(), vsv.end(), cmp1(1))->end;
		int		mine = min_element(vsv.begin(), vsv.end(), cmp1(1))->end;
		ofile<<m_strchr<<'\t';
		ofile<<"Complex\t"<<mins<<'\t'<<maxe<<'\t'<<mins<<'\t'<<maxe<<'\t'<<maxe-mins<<'\t';
		ofile<<"0-0-0"<<'\n';
	}
}
/********************************Draw simple image************************************/
struct SVIMAGE
{
	SVIMAGE(string str, int s, int e):m_s(s),m_e(e)
	{
		m_pImage = NULL;
		m_s = (m_s<0)?0:m_s;
		sprintf(name, "%s-%d-%d.png", str.c_str(), m_s, m_e);
		m_pImage = new CGraphic<int>(name, "png", ARC);
		m_pImage->SetImageSize(1040, 840);
		m_pImage->DrawImage(s, e, RGB(255, 255, 255));
		for (int i=0; i<4; i++)
		{
			m_pImage->SetDescription(g_ptype[i], true, 0, 0, g_clr[i]);
		}
	}
	~SVIMAGE()
	{
		if(m_pImage != NULL)
		{
			delete m_pImage;
			m_pImage = NULL;
		}
	}

	void AddItem(int s, int e, COLORREF clr)
	{
		if(s>=m_s && s<=m_e && e>=m_s && e<=m_e)
			m_pImage->AddImageItem(s, e, clr);
	}
	
	void ChangeType(emType type)
	{
		m_pImage->ChangeType(type);
	}

	int		m_s;
	int		m_e;
	char name[256];
	CGraphic<int>*	m_pImage;
};

void CFilterSV::drawimage( const char* p )
{
	if(AfxGetValue("-image") == NULL)return;
	if(p == NULL) return;
	string		str(p);
	char* pdo = AfxGetValue("-o");
	string		s;
	if(pdo == NULL || (pdo != NULL && (strcmp(pdo, ".") == 0 ||strcmp(pdo, "./") == 0 )))
	{
		s = ".";
	}
	else
	{
		s = pdo;
		mkdir(s.c_str(), 0755);
	}
 
  	string tmp  = str.substr(0, str.find(".sv"));
//////////////////////////////////////////////////////////////////////////
	string	svfile = str+".SV";
	igzstream	ifilesv(svfile.c_str());
	vector<SVIMAGE*>		vsvimage;
	string	ssv;
	while (getline(ifilesv, ssv))
	{
		VString		vstr;
		split(ssv, vstr, "\t ");
		mkdir((s+"/"+vstr[0]).c_str(), 00755);
		SVIMAGE		*svimage = new SVIMAGE(s+"/"+vstr[0]+"/"+vstr[0]+"-"+vstr[1], atoi(vstr[2].c_str())-100, atoi(vstr[3].c_str())+100);
		vsvimage.push_back(svimage);
	}
	ifilesv.close();

	igzstream	ifile(tmp.c_str());
	if (!ifile.good())
	{
		cout<<"Can't open file: "<<tmp<<endl;
		return;
	}
	
	string		str1;
	while (getline(ifile, str1))
	{
		VString		vstr;
		split(str1, vstr, "\t ");
		int		nStart	= atoi(vstr[2].c_str());
		int		nEnd	= atoi(vstr[3].c_str());
		for (size_t i=0; i<vsvimage.size(); i++)
		{
			int		n = atoi(vstr[0].c_str());
			COLORREF 	clr = g_clr[n];
			vsvimage[i]->AddItem(nStart, nEnd, clr);
		}
	}
	ifile.close();

	for (vector<SVIMAGE*>::iterator it=vsvimage.begin(); it!=vsvimage.end(); ++it)
	{
		Safe_Delete((*it));
	}
}

#endif
