
#ifndef _COMMON_STRUCT_H_
#define _COMMON_STRUCT_H_
// #include <boost/tokenizer.hpp>
// using namespace boost;
// 
// #ifndef Tokenizer
// typedef tokenizer<boost::char_separator<char> > Tokenizer;
// typedef char_separator<char> Separator;
// #endif

struct	FILEINFO
{
	string		dir;
	string		ext;
	string		name;
};
/*
struct SPLIT
{
	SPLIT(string& str):m_sep(" \t\n"), m_token(str, m_sep)
	{
	}

	SPLIT(string& str, const char* pch):m_sep(pch), m_token(str, m_sep)
	{
	}

	string& operator [](int index)
	{
		m_it = m_token.begin();
		while(index-- >=0)
			m_it++;
		return m_it;
	}

	Tokenizer::iterator	m_it;
	Separator			m_sep;
	Tokenizer			m_token;
};
*/
#endif
