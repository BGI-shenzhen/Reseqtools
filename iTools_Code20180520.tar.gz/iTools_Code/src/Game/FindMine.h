#ifndef  FindMine_H_
#define  FindMine_H_
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <map>
#include <ctime>
#include <cstdlib>
#include <stdio.h>
#include <ncurses.h>
#include <ctime>
#include "LiangLianKan.h"
#include "../ALL/comm.h"
#include "Draw_comm.h"


///////////////////

class Mine
{
	public:
		bool  P ;
		bool Open ;
		int Find ;
		int right_D ;
		Mine()
		{
			P=false;
			Open=false ;
			Find=0;
			right_D=0;
		}
};

class FindMine
{
	public:
		int mrow ;
		int mcol ;
		Mine **Arry ;
		bool Game_Over ;
		int STARTX;
		int STARTY ;
		int WIDTH ;
		int HEIGHT ;
		int ROW;
		int COL;
		int level ;
		int Count ;
};


void magic_board( FindMine * tv )
{ 
	int i,j, deltax, deltay;
	int attr = COLOR_PAIR(4) ; 
	attron(attr);                       
	board(stdscr, tv->STARTY, tv->STARTX,  tv->ROW,  tv->COL, tv->WIDTH, tv->HEIGHT);
	attroff(attr);
	deltay = tv->HEIGHT / 2;
	deltax = tv->WIDTH  / 2;
	attr = COLOR_PAIR(5) ;
	attron(attr);
	for(i = 0;i < tv->COL; ++i)
	{
		for(j = 0; j < tv->ROW; ++j)
		{
			mvaddch(tv->STARTY + j * tv->HEIGHT + deltay,
					tv->STARTX + i * tv->WIDTH  + deltax,
					'$');
		}
	}
	attroff(attr);
}


void draw_NoMine( FindMine * tv , int x , int y )
{
	int   deltay = tv->HEIGHT / 2;
	int   deltax = tv->WIDTH  / 2;

	if ( (-1<x && x<(tv->COL) ) && (-1<y && y<(tv->ROW) )  && (!(tv->Arry[x][y]).Open) )
	{
		mvaddch(tv->STARTY + y * tv->HEIGHT + deltay, tv->STARTX + x * tv->WIDTH  + deltax, ' ');
		(tv->Arry[x][y]).Open=true ;
	}

	for (int ii=-1; ii<2 ; ii++ )
	{
		for (int jj=-1; jj<2 ; jj++ )
		{
			if (ii==0 && jj==0 )
			{
				continue ;
			}
			int NowX=x+ii;
			int NowY=y+jj;
			if ( ( NowX>-1 && NowX<(tv->COL) )  &&  (NowY>-1 && NowY<(tv->ROW)))
			{
				if ((tv->Arry[NowX][NowY]).Open )
				{
					continue ;
				}
				else if ((tv->Arry[NowX][NowY]).Find!=0)
				{

					attron(COLOR_PAIR((tv->Arry[NowX][NowY]).Find));
					mvprintw(tv->STARTY+NowY*tv->HEIGHT+deltay,tv->STARTX+NowX*tv->WIDTH+deltax, "%d", (tv->Arry[NowX][NowY]).Find);
					attroff(COLOR_PAIR((tv->Arry[NowX][NowY]).Find));
					(tv->Arry[NowX][NowY]).Open=true ;
				}
				else
				{
					mvaddch(tv->STARTY + NowY * tv->HEIGHT + deltay, tv->STARTX + NowX * tv->WIDTH  + deltax, ' ');
					(tv->Arry[NowX][NowY]).Open=true ;
					draw_NoMine( tv , NowX, NowY ) ;
				}
			}
		}
	}

	//    refresh();
}


bool FindMine_tv_Draw(FindMine * tv )
{
	clear(); 
	int attr=0;
	attr |= COLOR_PAIR(7); attron(attr);
	mvaddstr(0,(tv->mcol/2)-15,"Welcome come,FindMine Game");
	int HelpPosi=(tv->mcol)/2 ;
	mvaddstr(1,(tv->mcol/2)-15,"Love hewm@genomics.org.cn");
	mvaddstr(2,(tv->mcol/2)-22,"q : leave; n : next level; f :forward level" );
	string sore="level :" + Int2Str(tv->level);
	mvaddstr(3,(tv->mcol/2)-10,sore.c_str());
	attroff(attr);
	magic_board(tv);
	refresh();
	return true ;
}


bool FindMine_tv_Pair( FindMine * tv )
{    
	int endy = tv->STARTY + tv->ROW * tv->HEIGHT;
	int endx = tv->STARTX + tv->COL * tv->WIDTH;
	int deltay = tv->HEIGHT / 2;
	int deltax = tv->WIDTH  / 2;
	FindMine_tv_Draw(tv);
	MEVENT event;
	int x1=0 ,y1=0 ;
	int Right=0;
	int Flag=(tv->Count) ;
	int Tmp=tv->STARTX + tv->COL * tv->WIDTH/2-8;
	string Mine_Count="Mine Count : "+Int2Str(Flag)+"  ";
	mvaddstr(tv->STARTY-1,Tmp,Mine_Count.c_str());
	refresh();

	while(true)
	{        
		if ((Right==(tv->Count))  &&  (Flag==0)  )
		{
			return true ;
		}
		int  ch = getch();
		if(ch == KEY_MOUSE && (getmouse(&event) == OK ))
		{
			int x=(event.x- tv->STARTX)/(tv->WIDTH);
			int y=(event.y- tv->STARTY)/(tv->HEIGHT);

			if ( ( event.bstate & BUTTON3_PRESSED ))
			{
				if ( (-1<x && x<(tv->COL) ) && (-1<y && y<(tv->ROW)))
				{
					if ((tv->Arry[x][y]).Open)
					{
						continue ;
					}
					else
					{
						(tv->Arry[x][y]).right_D++;
						if ((tv->Arry[x][y]).right_D==1)
						{
							int  attr = COLOR_PAIR(11);
							attron(attr);
							mvaddch(tv->STARTY + y * tv->HEIGHT + deltay,
									tv->STARTX + x * tv->WIDTH + deltax,'*');
							attroff(attr);
							if ( (tv->Arry[x][y]).P )
							{
								++Right;
							}
							Flag--;
							Mine_Count="Mine Count : "+Int2Str(Flag)+"  ";
							mvaddstr(tv->STARTY-1,Tmp,Mine_Count.c_str());
						}
						else if ((tv->Arry[x][y]).right_D==2)
						{
							int  attr = COLOR_PAIR(11);
							attron(attr);
							mvaddch(tv->STARTY + y * tv->HEIGHT + deltay,
									tv->STARTX + x * tv->WIDTH+ deltax,'?');
							attroff(attr);
							if ( (tv->Arry[x][y]).P )
							{
								--Right;
							}
							Flag++;
							Mine_Count="Mine Count : "+Int2Str(Flag)+"  ";
							mvaddstr(tv->STARTY-1,Tmp,Mine_Count.c_str());
						}
						else if ((tv->Arry[x][y]).right_D==3)
						{
							(tv->Arry[x][y]).right_D=0;
							int  attr = COLOR_PAIR(5);
							attron(attr);
							mvaddch(tv->STARTY + y * tv->HEIGHT + deltay,
									tv->STARTX + x * tv->WIDTH+ deltax,'$');
							attroff(attr);
						}
					}
				}
				refresh();
			}
			else if ( ( event.bstate & BUTTON1_PRESSED) )
			{
				if ( (-1<x && x<(tv->COL) ) && (-1<y && y<(tv->ROW) ))
				{
					if ((tv->Arry[x][y]).Open || ((tv->Arry[x][y]).right_D==1))
					{
						continue ;
					}                
					else if ((tv->Arry[x][y]).P)
					{
						int  attr = COLOR_PAIR(11);
						attron(attr);
						for(int i = 0;i < tv->COL; ++i)
						{
							for(int j = 0; j < tv->ROW; ++j)
							{
								if ((tv->Arry[i][j]).P)
								{
									mvaddch(tv->STARTY + j * tv->HEIGHT + deltay,tv->STARTX + i * tv->WIDTH  + deltax,'@');
								}
							}
						}                    
						attroff(attr);
						refresh();
						return false ;
					}
					else if ( (tv->Arry[x][y]).Find!=0)
					{
						attron(COLOR_PAIR((tv->Arry[x][y]).Find));
						mvprintw(tv->STARTY+y*tv->HEIGHT+deltay,tv->STARTX+x*tv->WIDTH+deltax, "%d", (tv->Arry[x][y]).Find);
						attroff(COLOR_PAIR((tv->Arry[x][y]).Find));
						refresh();
					}
					else
					{
						draw_NoMine(  tv , x ,  y );
						refresh();
					}
				}
			}
		}
		else if (ch == 'q')
		{
			return false ;
			break ;
		}
		else if (ch == 'n')
		{
			return true ;
		}
		else if  (ch == 'f')
		{
			tv->level-=2 ;
			if (tv->level<0)
			{
				tv->level=0;
			}
			return true ;
		}
	}
	return true ;
}


int FindMine_tv_Run (FindMine * tv )
{

	while(true)
	{
		if (tv->level>2)
		{
			tv->WIDTH =3;
			tv->HEIGHT=2;
			tv->ROW=16 ;
			tv->COL=30;
			tv->Count=99;
		}
		else if ( tv->level==1 )
		{
			tv->WIDTH =5;
			tv->HEIGHT=3;
			tv->ROW=9 ;
			tv->COL=9;
			tv->Count=10;
		}
		else
		{
			tv->WIDTH =4;
			tv->HEIGHT=2;
			tv->ROW=16 ;
			tv->COL=16;
			tv->Count=40;
		}

		tv->STARTY = (tv->mrow - tv->ROW * tv->HEIGHT) / 2;
		tv->STARTX = (tv->mcol - tv->COL * tv->WIDTH) / 2;

		tv->Arry = new Mine *[(tv->COL)];
		tv->Arry[0] = new Mine[(tv->ROW)*(tv->COL)];
		for(int i = 1; i <(tv->COL); i++)
		{
			tv->Arry[i] = tv->Arry[i-1]+(tv->ROW);
		}
		srand((unsigned)time(NULL));
		int BB=0 ;
		while(true)
		{
			int ii=rand()%(tv->COL);
			int jj=rand()%(tv->ROW);
			if (!(tv->Arry[ii][jj].P))
			{
				BB++;
				(tv->Arry[ii][jj].P)=true;
				if (BB==(tv->Count))
				{
					break ;
				}
			}
		}

		for (int i = 0; i <(tv->COL); i++)
		{
			for (int j = 0; j <(tv->ROW); j++)
			{
				for (int ii=-1; ii<2 ; ii++ )
				{
					for (int jj=-1; jj<2 ; jj++ )
					{
						int NowX=i+ii;
						int NowY=j+jj;
						if ( ( NowX>-1 && NowX<(tv->COL) )  &&  (NowY>-1 && NowY<(tv->ROW)))
						{
							if ((tv->Arry[NowX][NowY]).P)
							{
								(tv->Arry[i][j]).Find++; 
							}
						}
					}
				}
				if ((tv->Arry[i][j]).P)
				{
					(tv->Arry[i][j]).Find--;
				}
			}
		}

		time_t start_time = time(NULL);
		if (FindMine_tv_Pair(tv))
		{
			tv->level++;
			delete []  tv->Arry[0] ;
			delete []  tv->Arry ;

			time_t end_time=time(NULL);
			int Time=int(end_time - start_time);
			string time="Used Time : "+Int2Str(Time);
			mvaddstr(tv->mrow/2-2,tv->mcol/2,time.c_str());
			mvaddstr(tv->mrow/2,tv->mcol/2,"AnyKey Continue");
			getch();
			getch();
			refresh();
			beep();
			flash();
		}
		else
		{
			delete []  tv->Arry[0] ;
			delete []  tv->Arry ;    
			int B=COLOR_PAIR(6); attron(B);
			mvaddstr(tv->mrow/2,tv->mcol/2,"FindMine Game Over");
			mvaddstr(tv->mrow/2+2,tv->mcol/2,"Enter 'y' : Repeat");
			mvaddstr(tv->mrow/2+4,tv->mcol/2,"Enter 'q' : Leave");
			mvaddstr(tv->mrow/2+6,tv->mcol/2,"Welcome Again");
			mvaddstr(tv->mrow/2+8,tv->mcol/2,"hewm@genomics.org.cn");
			attroff(B);
			refresh();
			return 1 ;
		}
	}
	return 1;
}


int FindMine_tv_Init( FindMine * tv )
{
	initscr();
	noecho();
	cbreak();
	raw();
	curs_set(0);
	keypad(stdscr, TRUE);
	mousemask(ALL_MOUSE_EVENTS,NULL);
	mouseinterval(50);
	start_color();
	init_pair(1, COLOR_BLUE, COLOR_BLACK);
	init_pair(6, COLOR_WHITE, COLOR_BLACK);
	init_pair(3, COLOR_YELLOW, COLOR_BLACK);
	init_pair(4, COLOR_RED, COLOR_BLACK);
	init_pair(5, COLOR_GREEN, COLOR_BLACK);
	init_pair(2, COLOR_CYAN, COLOR_BLACK);
	init_pair(7, COLOR_YELLOW, COLOR_BLACK);
	init_pair(8, COLOR_GREEN, COLOR_BLACK);
	init_pair(9, COLOR_BLUE, COLOR_BLACK);
	init_pair(10, COLOR_RED, COLOR_CYAN);
	init_pair(11, COLOR_RED, COLOR_GREEN);
	init_pair(12, COLOR_RED, COLOR_BLUE);
	init_pair(13, COLOR_CYAN, COLOR_GREEN);
	// COLOR_MAGENTA
	tv->mrow=82 ;tv->mcol=42 ;    
	getmaxyx(stdscr, tv->mrow, tv->mcol);
	//tv->STARTY = (tv->mrow - tv->ROW * tv->HEIGHT) / 2;
	//tv->STARTX = (tv->mcol - tv->COL * tv->WIDTH) / 2;
	return 1 ;
}


int Game_Mine_main(int argc, char** argv)
{
	bool Game_Repeat=true ;
	int level=1;
	while(true)
	{
		FindMine  *game=new FindMine ;
		FindMine_tv_Init(game) ;
		game->level=level;
		FindMine_tv_Run(game);
		level=game->level;
		while(true)
		{
			int c=getch();
			if (c=='Y' || c=='y' || c==32)
			{
				Game_Repeat=false ;
				break ;
			}
			else if( c=='n' || c=='N' || c=='q' || c=='Q')
			{
				Game_Repeat=true ;
				break ;
			}
		}
		endwin();
		delete game ;
		if (Game_Repeat)
		{
			return 1 ;
		}
	}
	return 0;
}

////////////////////////swimming in the sea & flying in the sky //////////////////

#endif // Snake_Eat_H_

//1)

