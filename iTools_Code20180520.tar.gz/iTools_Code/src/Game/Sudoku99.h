#include <curses.h>
#include <stdlib.h>

#ifndef  SudokuGamev2_H_
#define  SudokuGamev2_H_
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <map>
#include <ctime>
#include <cstdlib>
#include <stdio.h>
#include <ncurses.h>
#include <ctime>
#include "LiangLianKan.h"
#include "../ALL/comm.h"
#include "Draw_comm.h"
#include "FindMine.h"
#include "Sudoku.h"


//deleting from available[] the item which has already been selected 
void del_avail(int array[9],int n)
{
	int i,j;
	for(i=0;i<9;i++)
		if(n==array[i])
			for(j=i;j<8;j++)
				array[j]=array[j+1]; //shifting the rest items ahead
}

//Creating 3*3 matrix randomly
void create_phalanx(int phalanx[][3])
{
	int i,j;
	time_t t;
	int available[9]={1,2,3,4,5,6,7,8,9};
	srand(time(&t));

	for(i=0;i<3;i++)
		for(j=0;j<3;j++)
		{
			phalanx[i][j]=available[rand()%(9-i*3-j)];
			del_avail(available,phalanx[i][j]);
		}
}

//Placing 3*3 phalanx at a block of 9*9 sudoku matrix
//the indexes of block are from 0 to 8
void place_phalanx(int phalanx[][3],int sudoku[][9],int index_block)
{
	int i,j;
	for(i=0;i<3;i++)
		for(j=0;j<3;j++)
			sudoku[index_block/3*3+i][index_block%3*3+j]=phalanx[i][j];
}

void shift_up(int phalanx[][3])
{
	int i;
	int temp[3]={0};
	for(i=0;i<3;i++)
		temp[i]=phalanx[0][i];
	for(i=0;i<3;i++)
	{
		phalanx[0][i]=phalanx[1][i];
		phalanx[1][i]=phalanx[2][i];
		phalanx[2][i]=temp[i];
	}
}

void shift_down(int phalanx[][3])
{
	int i;
	int temp[3]={0};
	for(i=0;i<3;i++)
		temp[i]=phalanx[2][i];
	for(i=0;i<3;i++)
	{
		phalanx[2][i]=phalanx[1][i];
		phalanx[1][i]=phalanx[0][i];
		phalanx[0][i]=temp[i];
	}
}

void shift_left(int phalanx[][3])
{
	int i;
	int temp[3]={0};
	for(i=0;i<3;i++)
		temp[i]=phalanx[i][0];
	for(i=0;i<3;i++)
	{
		phalanx[i][0]=phalanx[i][1];
		phalanx[i][1]=phalanx[i][2];
		phalanx[i][2]=temp[i];
	}
}

void shift_right(int phalanx[][3])
{
	int i;
	int temp[3]={0};
	for(i=0;i<3;i++)
		temp[i]=phalanx[i][2];
	for(i=0;i<3;i++)
	{
		phalanx[i][2]=phalanx[i][1];
		phalanx[i][1]=phalanx[i][0];
		phalanx[i][0]=temp[i];
	}
}



void magicv2(FindMine * tv)
{	
	int sudoku[9][9]={0};
	int phalanx[3][3]={0};
	create_phalanx(phalanx);
	place_phalanx(phalanx,sudoku,4); 
	shift_down(phalanx);
	place_phalanx(phalanx,sudoku,3);
	shift_right(phalanx);
	place_phalanx(phalanx,sudoku,0);
	shift_up(phalanx);
	place_phalanx(phalanx,sudoku,1);
	shift_up(phalanx);
	place_phalanx(phalanx,sudoku,2);
	shift_left(phalanx);
	place_phalanx(phalanx,sudoku,5);
	shift_left(phalanx);
	place_phalanx(phalanx,sudoku,8);
	shift_down(phalanx);
	place_phalanx(phalanx,sudoku,7);
	shift_down(phalanx);
	place_phalanx(phalanx,sudoku,6);

	int i,j,k;
	for(i = 0;i < 9;++i)
	{
		for(j = 0;j < 9;++j)
		{
			(tv->Arry[i][j]).Find = sudoku[i][j];
		}
	}
	return ;
}

///////////////////

int Sudoku_tv_RunV2 (FindMine * tv )
{

	while(true)    
	{
		tv->WIDTH=5 ;
		tv->HEIGHT=3;
		tv->ROW= 9  ;
		tv->COL= tv->ROW ;

		int XY=(tv->ROW)*(tv->COL) ;
		int Space_Count=8+(tv->level)*2;

		if (tv->level>4)
		{
			tv->WIDTH=5;
			tv->HEIGHT=3;
			tv->ROW= 9  ; 
			tv->COL= 9 ;
			XY=81  ;
			Space_Count=8+(tv->level)*2;
			if (Space_Count>47){Space_Count=47;}
		}

		(tv->Count)=(tv->ROW) ;

		int    deltay = tv->HEIGHT / 2;
		int    deltax = tv->WIDTH  / 2;


		tv->STARTY = (tv->mrow - tv->ROW * tv->HEIGHT) / 2 ;
		tv->STARTX = (tv->mcol - tv->COL * tv->WIDTH) / 2 ;

		tv->Arry = new Mine *[(tv->COL)];
		tv->Arry[0] = new Mine[XY];

		for(int i = 1; i <(tv->COL); i++)
		{
			tv->Arry[i] = tv->Arry[i-1]+(tv->ROW);
		}

		magicv2(tv);

		srand((unsigned)time(NULL));
		int Rand=rand()%4;
		for(int i=0 ; i<Rand ; i++ )
		{
			circumrotate(tv);
		}

		Sudoku_tv_Draw(tv);

		int  attr = COLOR_PAIR(5) ;
		attron(attr);
		int BB=0;
		while(true)
		{
			int ii=rand()%(tv->COL);
			int jj=rand()%(tv->ROW);
			if (!(tv->Arry[ii][jj].P))
			{
				BB++;
				(tv->Arry[ii][jj].P)=true;
				(tv->Arry[ii][jj].Open)=true;
				if (BB==Space_Count)
				{
					break ;
				}
			}
		}


		for (int i = 0; i <(tv->COL); i++)
		{
			for (int j = 0; j <(tv->ROW); j++)
			{
				if (!(tv->Arry[i][j].P))
				{
					int   Pvalue=(tv->Arry[i][j].Find) ;
					mvprintw(tv->STARTY+j*tv->HEIGHT+deltay,tv->STARTX+i*tv->WIDTH+deltax, "%d",Pvalue);
				}
			}
		}

		attroff(attr);

		refresh() ;  

		time_t start_time = time(NULL);
		if (Sudoku_tv_Pair(tv))
		{
			tv->level++;
			delete []  tv->Arry[0] ;
			delete []  tv->Arry ;

			time_t end_time=time(NULL);
			int Time=int(end_time - start_time);
			string time="Used Time : "+Int2Str(Time);
			mvaddstr(tv->mrow/2-3,tv->mcol/2,time.c_str());
			mvaddstr(tv->mrow/2+1,tv->mcol/2,"AnyKey Continue");
			getch();
			getch();
			refresh();
			beep(); 
			flash();
		}
		else
		{
			delete []  tv->Arry[0] ;
			delete []  tv->Arry ;    
			int B=COLOR_PAIR(6); attron(B);
			mvaddstr(tv->mrow/2,tv->mcol/2,"Sudoku Game Over");
			mvaddstr(tv->mrow/2+2,tv->mcol/2,"Enter 'y' : Repeat");
			mvaddstr(tv->mrow/2+4,tv->mcol/2,"Enter 'q' : Leave");
			mvaddstr(tv->mrow/2+6,tv->mcol/2,"Welcome Again");
			mvaddstr(tv->mrow/2+8,tv->mcol/2,"hewm@genomics.org.cn");
			attroff(B);
			refresh();
			return 1 ;
		}
	}
	return 1;
}

int Game_SudokuV2_main(int argc, char** argv)
{
	bool Game_Repeat=true ;
	int level=1;
	while(true)
	{
		FindMine  *game=new FindMine ;
		FindMine_tv_Init(game) ;
		curs_set(1);

		game->level=level;
		Sudoku_tv_RunV2(game);
		level=game->level;

		while(true)
		{
			int c=getch();
			if (c=='Y' || c=='y' || c==32)
			{
				Game_Repeat=false ;
				break ;
			}
			else if( c=='n' || c=='N' || c=='q' || c=='Q')
			{
				Game_Repeat=true ;
				break ;
			}
		}
		endwin();
		delete game ;
		if (Game_Repeat)
		{
			return 1 ;
		}
	}
	return 0;
}

////////////////////////swimming in the sea & flying in the sky //////////////////

#endif // SudokuGamev2_H_


