#include <unistd.h>
#include <cstdlib>
#include <cstdio>
#include "Thread.h"

Thread::Thread( ) : m_running(false)
{
}

void * Thread::_ThreadFunc(void* pArg)
{
	Thread* pThread = (Thread*) pArg;
	pThread->m_running = true;
	srand(time(NULL));
	pThread->Run();
	::pthread_exit(NULL);
	return NULL;
}

unsigned int Thread::Sleep( unsigned int seconds)
{
	return ::sleep(seconds);
}

unsigned int Thread::MSleep( unsigned int mSeconds)
{
	return ::usleep(mSeconds * 1000U);
}

bool Thread::Start()
{
	if ( !m_running)
	{
		if ( ::pthread_create(&m_tid, NULL, _ThreadFunc, this ) )
			return false;
	}
	return true;
}

void Thread::Join() const
{
	::pthread_join(m_tid, NULL);
}

