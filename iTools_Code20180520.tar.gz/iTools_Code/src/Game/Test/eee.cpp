#include <ncurses.h>        /* stdio.h is also included */ 
#include <string.h> 
#include <unistd.h> 
#include <stdlib.h> 
#include <signal.h> 
#include <time.h> 
#include "Draw_comm.h" 

#define ENTER              10 




void begin_print(void) 
{ 
	int          i; 

	//    bkgd(COLOR_PAIR()); 
	box(stdscr, 0, 0); 
	Box(stdscr, 0, 0,23,80,COLOR_PAIR(7)); 
	Box(stdscr, 6, 3, 12, 35, COLOR_PAIR(1)); 
	int attr = COLOR_PAIR(7); attron(attr);

	for (i = 1; i < 4; ++i) 
	{
		mvvline(7, 4-1+i*8, ACS_VLINE, 5); 
	}

	mvvline(1, 39, ACS_VLINE, 22);

	attroff(attr);

	for (i = 0; i < 4; ++i) { 
		Box(stdscr, 7, 4+1+i*8, 11, 4+1+i*8+4, COLOR_PAIR(8)); 
		fill_rectangle(stdscr, 8, 4+1+1+i*8, 10, 4+i*8+4, ' ' | COLOR_PAIR(12)); 
	}

	attr = COLOR_PAIR(5); attron(attr);
	mvprintw(3, 12, "Welcome to 24!"); 
	mvprintw(14, 4, "Your answer: ('@' to end)"); 
	mvhline(17, 5, ACS_HLINE, 28); 
	mvaddstr(22, 3, "T:"); 
	mvaddstr(22, 10, "C:"); 
	mvaddstr(22, 17, "RATE:"); 
	mvaddch(22, 28, '%'); 
	mvaddstr(21, 30, "Ver 2.0"); 
	Box(stdscr, 2, 42, 21, 75, COLOR_PAIR(1)); 
	mvaddstr(5, 43, "Notes:"); 
	mvaddstr(8, 43,    "1. Direct Enter try next round."); 
	mvaddstr(10, 43, "2. A stands 1."); 
	mvaddstr(12, 43, "3. J Q K stand for 11,12,13"); 
	//   mvaddstr(14, 43, "4. Press 'A' to auto run."); 
	mvaddstr(14, 43, "5. Press '@' to quit the game."); 
	mvaddstr(16, 43, "6. hewm@genomics.org.cn"); 
	mvaddstr(19, 51, "Have a good time!"); 

	attroff(attr);
	return; 
} 






int main(int argc, char **argv) 
{ 
	initscr();    /* init ncurses mode */ 
	start_color();
	start_color();
	init_pair(1, COLOR_BLUE, COLOR_BLACK);
	init_pair(2, COLOR_GREEN, COLOR_BLACK);
	init_pair(3, COLOR_YELLOW, COLOR_BLACK);
	init_pair(4, COLOR_WHITE, COLOR_BLACK);
	init_pair(5, COLOR_GREEN, COLOR_BLACK);
	init_pair(6, COLOR_CYAN, COLOR_BLACK);
	init_pair(7, COLOR_YELLOW, COLOR_BLACK);
	init_pair(8, COLOR_RED, COLOR_BLACK);
	init_pair(9, COLOR_BLUE, COLOR_BLACK);
	init_pair(10, COLOR_RED, COLOR_CYAN);
	init_pair(11, COLOR_RED, COLOR_GREEN);
	init_pair(12, COLOR_RED, COLOR_BLUE);
	init_pair(13, COLOR_CYAN, COLOR_GREEN);
	begin_print(); 
	srand(time(NULL)); 


	refresh();
	getch();
	endwin();   /* leave ncurses mode */ 
	return 0; 

}


