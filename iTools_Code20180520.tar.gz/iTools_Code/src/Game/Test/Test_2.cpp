/* 
 * File:   newmain.cc
 * Author: Null
 * Blog: http://hi.baidu.com/hetaoos
 * Created on 2008��7��30��, ����12:49
 */


#include "Thread.h"
#include "pthread.h"
#include <iostream>

using namespace std;

class MultiThread : public Thread
{
	public:
		Thread *th1;
		Thread *th2;
		char A[100];
		int B ;
		void Test()
		{
			A[0]='c';
			B=0;
			th1 = new Thread(this);
			th2 = new Thread(this);
			start();
			th1->start();
			th2->start();
			th1->join();
			th2->join();
		}

		bool count_d()
		{
			while(true)    
			{
				char a=getchar();
				B++ ;
				if (B>100){B=99;}
				if (a=='q' || a=='Q') {return true ;}
				A[B]=a; 
				cout<<"in\t"<<a<<endl;
				sleep(1);
			}
			return true ;
		}

		void dd()
		{
			while(true)
			{
				B--;
				if (B<0)
				{
					B=0;
					A[0]='c';
				}

				cout<<"out\t"<<A[B]<<endl;
				sleep(2);
			}
		}

		void run()
		{
			if (Thread::isEquals(th1))
			{
				count_d();
				pthread_kill(th2,1);
				pthread_exit(NULL);

				return  ;
			}
			else if (Thread::isEquals(th2))
			{
				dd();
			}
			else
			{

				return  ;
			}
		}
};

int main(int argc, char** argv)
{
	bool ret;
	MultiThread *mt;
	mt = new MultiThread();
	mt->Test();
	cout<<"love hewm"<<endl;
	return (EXIT_SUCCESS);
}

