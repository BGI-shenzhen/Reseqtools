#include <curses.h>
#include <stdio.h>
#include <signal.h>
#include <sys/types.h>
#include <pthread.h>
#include <errno.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <string.h>
#include <stdlib.h>

#define MIN(a,b) a<b?a:b
#define MAX(a,b) a>b?a:b

int running ;
int prunning ;
int quit ;
int step[2];
int ballx ;
int bally;

int barx ;
int bary ;

int d ;
float d1;
int fd;
char buf[1024];
int mrunning = 1;
char *bar = "__________";
char ball ='O';
void pa();
void showmsg();
void newgame();

void paint()
{
	clear();
	while(prunning)
	{

		clear();
		mvaddstr(bary,barx,bar);
		mvaddch(bally,ballx,ball);
		refresh();
		usleep(100000);

	}
	pthread_exit(NULL);
}

void ballmove()
{
	int ret;
	unlink("record.txt");
	//bally = LINES - 2 ;
	fd = open("record.txt",O_CREAT|O_RDWR,0666);
	if(fd < 0)
	{
		perror("create");
		exit(1);
	}
	while(1)
	{
		while(running)
		{
			memset(buf,0,sizeof(buf));
			ballx += d;
			if(ballx == COLS)
			{
				d = -1;
				ballx= COLS -1;
				beep();

			}
			if(ballx <0)
			{
				d = 1;
				ballx = 0;
				beep();
			}
			bally -= d1;
			/*if(bally == LINES )
			  {
			//srand(time(NULL));
			//d1 = (rand()%10)/(10.0)+1.0;

			d1 = 1;
			bally = LINES - 1;
			beep();

			}*/
			if(bally < 0)
			{
				//srand(time(NULL));
				//d1 = (rand()%10)/(10.0) + 1.0;
				d1 = -1;
				bally= 0;
				beep();
			}
			/*if(LINES - 2 == bally)
			  {
			  d1 = 1;
			  bally = LINES - 2;
			  beep();
			  }*/
			else if(bally == LINES)
			{
				char tmp[] = "ball move over\n";
				write(fd,tmp,strlen(tmp));
				running = 0;
				prunning = 0;
				//quit = 0;
				clear();
				mvaddstr(12,15,"Game  over ! ,thank  you play        next time!");
				refresh();
				mvaddstr(13,15,"Input  'n'  restart ,'q'  exit the game,'r' return the  menu ");
				refresh();

				attron(A_BOLD);
				mvaddstr(14,17,"please input:");
				refresh();
				move(14,25);
				break;        

			}
			else if( (bally == bary)&&((ballx >=step[0])&&(ballx <= step[1])))
			{
				d1 = 1;
				bally = LINES - 1;
				char temp[]="the ball click the bar\n";
				write(fd,temp,strlen(temp));
				//beep();
			}
			sprintf(buf,"x = %d,  y = %d\n",ballx,bally);
			write(fd,buf,strlen(buf));
			usleep(100000);
		}
		if(0 == prunning)
			break;
	}
	//close(fd);
	pthread_exit(NULL);

}

void barmove()
{

	chtype input;
	clear();
	char buf[100];
	keypad(stdscr,TRUE);

	//bary = LINES - 1;
	mvaddstr(bary,barx,bar);
	//quit&&(input = getch())&&input !=ERR
	while(quit&&(input = getch())&&input !=ERR)
	{
		if(!quit)
		{
			char tmp[] = "bar move over 1\n";
			write(fd,tmp,strlen(tmp));
			break;
		}

		switch(input)
		{
			case KEY_LEFT:
				barx = MAX(barx-1,0);
				memset(buf,0,sizeof(buf));
				step[0] -= 1;
				step[1] -= 1;
				sprintf(buf,"step[0] = %d, step[1]= %d \n",step[0],step[1]);
				write(fd,buf,strlen(buf));
				break;
			case KEY_RIGHT:
				memset(buf,0,sizeof(buf));
				barx = MIN(barx+1,COLS-1-10);
				step[0] += 1;
				step[1] += 1;
				sprintf(buf,"step[0] = %d, step[1]= %d \n",step[0],step[1]);
				write(fd,buf,strlen(buf));
				break;
			case 'r':
				{
					char tmp[] = "bar move over 2\n";
					write(fd,tmp,strlen(tmp));
					//prunning = 0;
					//running = 0;
					if(running && prunning)
					{
						prunning = 0;
						running = 0;
						quit = 0;

					}
					else if(prunning &&!running)//���������ͣ
					{
						prunning = 0;
						running = 0;
						quit = 0;
						showmsg();

					}
					else
					{
						quit = 0;

					}
					showmsg();
					break;
				}
			case 'p':
				pa();
				break;        
			case 'q':
				{
					if(prunning&&running )//���������������
					{
						prunning = 0;
						running = 0;
						quit = 0;
						showmsg();
					}
					else if(prunning &&!running)//���������ͣ
					{
						prunning = 0;
						running = 0;
						quit = 0;
						showmsg();

					}
					else//ֱ���˳�
					{
						quit = 0;
						mrunning = 0;
						prunning = 0;
						running = 0;
					}
					break;
				}
			case 'n':
				newgame();
				break;
		}
	}
	char tmp[] = "bar move over 3\n";
	write(fd,tmp,strlen(tmp));
	close(fd);
	pthread_exit(NULL);

}
void showmsg()
{
	//attron(A_BOLD);

	clear();
	mvaddstr(10,30,"Welcome to the game!");
	refresh();
	attroff(A_UNDERLINE);
	mvaddstr(11,25,"Help:");
	refresh();
	mvaddstr(12,26,"'N':Start a new game.");
	refresh();
	mvaddstr(13,26,"'q':Quit  the game.");
	refresh();
	mvaddstr(14,26,"'p':Pause the game.");
	refresh();
	mvaddstr(15,26,"'r':Return the menu.");
	refresh();

}
void newgame()
{
	pthread_t pid,pid2,pid3,pid4;
	prunning = 1;
	running = 1;
	quit = 1;
	step[0] = 10;
	step[1] = 19;
	bally = LINES - 1;
	bary = LINES - 1 ;
	barx = 10;
	ballx = 10;
	d1 = 1;
	d = 1;
	//��ͼ
	pthread_create(&pid,NULL,(void *) paint,NULL);

	//ľ������
	pthread_create(&pid2,NULL,(void *)barmove,NULL);


	//�����
	pthread_create(&pid3,NULL,(void *)ballmove,NULL);

	pthread_join(pid,NULL);
	pthread_join(pid2,NULL);
	pthread_join(pid3,NULL);
	//pthread_create(&pid4,NULL,(void *)pa,NULL);
	//pthread_join(pid4,NULL);
}

void pa()
{
	if(running)
		running = 0;
	else
		running = 1;

}

int main()
{
	pthread_t pid4;
	char buf[100];
	initscr();
	crmode();
	noecho();
	chtype input;
	//keypad(stdscr,TRUE);
	showmsg();
	//pthread_create(&pid4,NULL,(void *)pa,NULL);
	while(mrunning&&(input = getch()))
	{

		switch(input)
		{
			case 'n':
				{  
					newgame();
					break;
				}
			case 'q':
				{
					mrunning = 0;
					break;        
				}      
		}
	}
	endwin();
	return 0;


}




