#ifndef  DropBar_H_
#define  DropBar_H_
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <map>
#include <ctime>
#include <cstdlib>
#include <stdio.h>
#include "../include/gzstream/gzstream.C"
#include "../include/gzstream/gzstream.C"
#include "../ALL/comm.h"
#include <ncurses.h>
#include <ctime>

#include <boost/thread/thread.hpp>
#include <boost/thread/mutex.hpp>
#include <boost/bind.hpp>


typedef long long llong ;
using namespace std;
using namespace boost ;

///////////////////

class DropBar
{
	public:
		int mrow ;
		int mcol ;
		vector <char> operations ;
		int **Arry ;
		//        int **ArryX ;
		//        int **ArryY ;
		int life ;
		int score ;
		int level ;
		bool m_pause ;
		int bullet;
		int P_A, P_S ,P_D, P_W;
		int H_X ;
		int sleep_time ;
		//        int RunX ;
		//      int H_X, H_Y ,T_X, T_Y;
		//int RunX ,RunY ;
		bool Game_Over ;
};

int DropBar_rand_next( DropBar * tv)
{
	int X=(rand()%(tv->P_D));
	int Y=(rand()%24);
	if ((X>(tv->P_A))  && Y<6 && (tv->Arry[X][Y])==0 )
	{
		tv->Arry[X][3]=1;
		tv->Arry[X+1][3]=1;
		tv->Arry[X+2][3]=1;
		if ( Y<3 )
		{
			tv->Arry[X+Y][3]=2;
		}
		else if ( Y==4 )
		{             
			tv->Arry[X][3]=2;
			tv->Arry[X+1][3]=2;
			tv->Arry[X+2][3]=2;
		}
		return 1;
	}
	else if ((X>(tv->P_A))  && Y<7 && (tv->Arry[X][Y])==0 )
	{
		tv->Arry[X][3]=3;
		return 1;
	}
	else if ((X>(tv->P_A))  && (tv->Arry[X][Y])==0  && Y<8 )
	{
		tv->Arry[X][3]=2;
		tv->Arry[X+1][3]=2;
		return 1;
	}

	else if ( (X>(tv->P_A))  && (tv->Arry[X][Y])==0  && Y<9)
	{
		tv->Arry[X][3]=-20 ;
		return 1;
	}
	else if ( (X>(tv->P_A))  && (tv->Arry[X][Y])==0  && Y<10)
	{
		int YY=(rand()%4);
		if (YY==1)
		{
			tv->Arry[X][3]=-30 ;
		}
		return 1;
	}
	else if ( (X>(tv->P_A))  && (tv->Arry[X][Y])==0  && Y<11 )
	{
		tv->Arry[X][3]=-40 ;
		return 1;
	}
	else if ( (X>(tv->P_A))  && (tv->Arry[X][Y])==0  && Y<13 )
	{
		tv->Arry[X][3]=2;
		tv->Arry[X+1][3]=1;
		tv->Arry[X+2][3]=2;
	}


	return 1 ;
}

int DropBar_Eat_one( DropBar * tv)
{
	///*////
	for (int jj= tv->P_W+1 ; jj< tv->P_S ; jj++ )
	{
		for ( int ii=tv->P_A+1 ; ii< tv->P_D+1 ; ii++ )
		{
			if (tv->Arry[ii][jj]==-1)
			{
				if (jj==3)
				{
					tv->Arry[ii][jj]=0;
				}
				else if ( tv->Arry[ii][jj-1]==0)
				{
					tv->Arry[ii][jj-1]=-1;
					tv->Arry[ii][jj]=0;
				}
			}
		}
	}
	////*///
	int tmpEnd=(tv->P_S)-1;
	for (int jj= (tv->P_S)-2 ; jj > tv->P_W  ; jj--)
	{
		int A_tmp=jj ;
		int B_tmp=jj+1 ;
		for (int ii=tv->P_A+1  ; ii< tv->P_D ; ii++)
		{
			if (tv->Arry[ii][B_tmp]!=-100 )
			{
				if ( tv->Arry[ii][B_tmp]== -1 && tv->Arry[ii][A_tmp]>0 )
				{
					tv->Arry[ii][B_tmp]=-50 ;
					tv->Arry[ii][A_tmp]=0 ;
				}
				else if ( (tv->Arry[ii][B_tmp]>= 0) && (tv->Arry[ii][A_tmp]>0) )
				{
					--(tv->Arry[ii][A_tmp]);
					++(tv->Arry[ii][B_tmp]);
				}
				else if ( tv->Arry[ii][A_tmp]<-2 )
				{
					tv->Arry[ii][B_tmp]=tv->Arry[ii][A_tmp];
					tv->Arry[ii][A_tmp]=0;
				}
				else if ( B_tmp== tmpEnd )
				{
					tv->Arry[ii][B_tmp]=tv->Arry[ii][A_tmp] ;
				}                
				//*                
				else if  ( tv->Arry[ii][A_tmp] ==-1  )
				{
				}
				/*
				   else
				   {
				   tv->Arry[ii][B_tmp]=tv->Arry[ii][A_tmp];
				   }
				// */
			}
			else
			{
				if ( tv->Arry[ii][A_tmp]>0)
				{
					tv->life--;
				}
				else if (tv->Arry[ii][A_tmp]==-30)
				{
					tv->life++;
				}
				else if (tv->Arry[ii][A_tmp]==-20)
				{
					tv->bullet+=20;
				}
				else if (tv->Arry[ii][A_tmp]==-40)
				{
					tv->score+=5;
				}                
				if ( tv->Arry[ii][A_tmp]!=-100)
				{                
					tv->Arry[ii][A_tmp]=0;
				}
			}
		}
	}
	DropBar_rand_next(tv) ;
	return true ;

}

void DropBar_get_operations( DropBar *tv )
{
	while(true)
	{
		if (tv->Game_Over) { return ;}
		int c = getch();
		switch (c)
		{
			case 'h':
			case 'H':
			case '?': tv->operations.push_back('h') ; break;
			case '\033':
			case 'Q':
			case 'q': tv->operations.push_back('q') ; break;
			case KEY_LEFT:
			case 'a': tv->operations.push_back('l') ; break;
			case KEY_RIGHT:
			case 'd': tv->operations.push_back('r') ; break;
			case KEY_UP:
			case ' ':
			case 'w': tv->operations.push_back('u') ; break;
			case KEY_DOWN:
			case 's': tv->operations.push_back('d') ; break;
			case 'p': 
			case 'P': tv->m_pause=(!(tv->m_pause)); break;
			case KEY_RESIZE: getmaxyx(stdscr, tv->mrow, tv->mcol); break;
			default: continue;
		}
	}
}

bool DropBar_tv_Draw(DropBar * tv )
{
	clear(); 
	int attr=0;
	attr |= COLOR_PAIR(8); attron(attr);
	mvaddstr(1,(tv->mcol/2)-20,"Welcome come,Hide Stone Game");
	int HelpPosi=tv->mcol-17 ;
	mvaddstr(1,HelpPosi,"Love hewm");
	mvaddstr(8,HelpPosi,"Anykey : Begin");
	mvaddstr(10,HelpPosi,"Arrows : move");
	mvaddstr(12,HelpPosi,"a,s,w,d: move");
	mvaddstr(14,HelpPosi,"space  : shoot");
	mvaddstr(16,HelpPosi,"p  : Stop");
	mvaddstr(18,HelpPosi,"q  : leave");
	mvaddstr(20,HelpPosi,"$  : 5 Score");
	mvaddstr(22,HelpPosi,"@  : 1 Rock");
	mvaddstr(24,HelpPosi,"*  : 1 Life");
	mvaddstr(26,HelpPosi,"%  : 20 Bullet");
	//P_D=mcol-10;
	attroff(attr);

	for(int ii=0 ; ii< tv->mcol ; ii++)
	{
		for ( int jj=0 ; jj<tv->mrow ; jj++)
		{
			if ( tv->Arry[ii][jj]==0 )
			{
				continue ;
			}
			else if ( tv->Arry[ii][jj]>0 )
			{
				int attr = COLOR_PAIR(3) ;
				attron(attr);
				mvaddch(jj,ii,'@');
				attroff(attr);
			}
			else if ( tv->Arry[ii][jj]==-100)
			{
				int attr = COLOR_PAIR(13) ;
				attron(attr);
				mvaddch(jj,ii,'Y') ;
				attroff(attr);
			}
			else if ( tv->Arry[ii][jj]==-200)
			{
				int attr = COLOR_PAIR(6) ;
				/*                if (((tv->RunX)+jj)%2)
								  {
								  attr = COLOR_PAIR(6) ;
								  }
								  */
				attron(attr);
				mvaddch(jj,ii,'+');
				attroff(attr);
			}
			else if ( tv->Arry[ii][jj]==-20 )
			{
				int attr = COLOR_PAIR(10) ;
				attron(attr);
				mvaddch(jj,ii,'%') ;
				attroff(attr);
			}
			else if ( tv->Arry[ii][jj]==-30 )
			{
				int attr = COLOR_PAIR(12) ;
				attron(attr);
				mvaddch(jj,ii,'*') ;
				attroff(attr);
			}
			else if  (tv->Arry[ii][jj]==-40 )
			{
				int attr = COLOR_PAIR(11) ;
				attron(attr);
				mvaddch(jj,ii,'$') ;
				attroff(attr);
			}
			else if ( tv->Arry[ii][jj]==-50 )
			{
				int attr = COLOR_PAIR(10) ;
				attron(attr);
				mvaddch(jj,ii,'@') ;
				attroff(attr);
				tv->Arry[ii][jj]=0;
				++(tv->score);
			}
			else if ( tv->Arry[ii][jj]==-1 )
			{
				int attr = COLOR_PAIR(5) ;
				attron(attr);
				mvaddch(jj,ii,'+') ;
				attroff(attr);
			}
		}
	}

	//    tv->RunX=((tv->RunX)+1)%2;
	//int time=(tv->sleep_time)/10;
	string Score="Score  :"+Int2Str(tv->score);
	mvaddstr(30,HelpPosi,Score.c_str());
	Score="Level:"+Int2Str(tv->level);
	mvaddstr(32,HelpPosi,Score.c_str());
	Score="Life:"+Int2Str(tv->life);
	mvaddstr(34,HelpPosi,Score.c_str());
	Score="Bullet:"+Int2Str(tv->bullet);
	mvaddstr(36,HelpPosi,Score.c_str());
	attroff(attr);
	refresh();
	if (tv->score<100)
	{
		(tv->level)=tv->score/10 ;
	}
	else if  (tv->score<200)
	{
		(tv->level)=(tv->score-100)/20+10;
	}
	else if (tv->score<400)
	{
		(tv->level)=(tv->score-200)/40+20;
	}
	else
	{
		(tv->level)=(tv->score-400)/50+30;
	}
	(tv->sleep_time)=300-(tv->level)*5;
	if (tv->life<0)
	{
		return false ;
	}
	return true ;

}

void DropBar_Life_posi  ( DropBar * tv  , int move=0, int bullet=0)
{

	if (bullet!=0)
	{
		if (tv->Arry[tv->H_X+1][tv->P_S-3]==0)
		{
			tv->Arry[tv->H_X+1][tv->P_S-3]=-1;
		}
		else if (tv->Arry[tv->H_X+1][tv->P_S-3]>0)
		{
			tv->Arry[tv->H_X+1][tv->P_S-3]=-50;
		}
		//     return ;
	}
	if (move!=0) 
	{
		if (( tv->H_X+move<=tv->P_A)  ||  ( tv->H_X+move+3>=tv->P_D ))
		{
			move = 0 ;
		}

		int X_1=tv->H_X;  
		int X_2=tv->H_X+1;  
		int X_3=tv->H_X+2;  
		int XX_1=tv->H_X+move;  
		int XX_2=tv->H_X+move+1;  
		int XX_3=tv->H_X+move+2;  
		int Y=tv->P_S-1;
		int YY=tv->P_S-2;

		if ( tv->Arry[XX_1][Y]>0 || tv->Arry[XX_2][Y]>0 || tv->Arry[XX_3][Y]>0 || tv->Arry[XX_2][YY]>0 )
		{
			tv->life--;
		}
		else if ( tv->Arry[XX_1][Y]==-30 || tv->Arry[XX_2][Y]==-30 || tv->Arry[XX_3][Y]==-30 || tv->Arry[XX_2][YY]==-30 )
		{    
			tv->life++;
		}
		else if ( tv->Arry[XX_1][Y]==-20 || tv->Arry[XX_2][Y]==-20 || tv->Arry[XX_3][Y]==-20 || tv->Arry[XX_2][YY]==-20 )
		{
			tv->bullet+=10;
		}
		else if ( tv->Arry[XX_1][Y]==-40 || tv->Arry[XX_2][Y]==-40 || tv->Arry[XX_3][Y]==-40 || tv->Arry[XX_2][YY]==-40 )
		{
			tv->score+=5;
		}

		tv->Arry[X_1][Y]=0;
		tv->Arry[X_2][Y]=0;
		tv->Arry[X_3][Y]=0;
		tv->Arry[X_2][YY]=0;
		tv->Arry[XX_1][Y]=-100;
		tv->Arry[XX_2][Y]=-100;
		tv->Arry[XX_3][Y]=-100;
		tv->Arry[XX_2][YY]=-100;
		tv->H_X=XX_1;
	}
}

int DropBar_tv_Init( DropBar * tv )
{
	initscr();keypad(stdscr, TRUE);
	clear();
	noecho();cbreak();
	tv->mrow = 24; tv->mcol = 80;
	tv->sleep_time =300 ;
	tv->m_pause=false ;
	tv->Game_Over=false ;
	//    tv->RunX=1 ;
	getmaxyx(stdscr, tv->mrow, tv->mcol) ;
	//whelp = newwin(15, 40, 5, 5);
	start_color();
	init_pair(1, COLOR_BLUE, COLOR_BLACK);
	init_pair(2, COLOR_GREEN, COLOR_BLACK);
	init_pair(3, COLOR_YELLOW, COLOR_BLACK);
	init_pair(4, COLOR_WHITE, COLOR_BLACK);
	init_pair(5, COLOR_GREEN, COLOR_BLACK);
	init_pair(6, COLOR_CYAN, COLOR_BLACK);
	init_pair(7, COLOR_YELLOW, COLOR_BLACK);
	init_pair(8, COLOR_RED, COLOR_BLACK);
	init_pair(9, COLOR_BLUE, COLOR_BLACK);
	init_pair(10, COLOR_RED, COLOR_CYAN);
	init_pair(11, COLOR_RED, COLOR_GREEN);
	init_pair(12, COLOR_RED, COLOR_BLUE);
	init_pair(13, COLOR_CYAN, COLOR_GREEN);

	tv->P_A=1;        tv->P_S=tv->mrow-1 ;
	tv->P_D=tv->mcol-18;  tv->P_W=2 ;
	int arrrXY=(tv->mcol)*(tv->mrow);
	int arrrX=tv->mcol ;
	tv->Arry  = new int *[arrrX] ;
	tv->Arry[0] = new int[arrrXY] ;
	srand((unsigned)time(NULL));
	//    tv->ArryX  = new int *[arrrX] ;
	//    tv->ArryX[0] = new int[arrrXY] ;

	//tv->ArryY  = new int *[arrrX] ;
	//tv->ArryY[0] = new int[arrrXY] ;

	for(int i = 1; i <(tv->mcol); i++)
	{
		tv->Arry[i]  =(tv->Arry[i-1])+(tv->mrow);
		//     tv->ArryX[i] =(tv->ArryX[i-1])+(tv->mrow);
		//     tv->ArryY[i] =(tv->ArryY[i-1])+(tv->mrow);
	}


	for (int ii=0 ; ii< tv->mcol ; ii++)
	{
		for (int jj=0 ; jj< tv->mrow ; jj++)
		{
			tv->Arry[ii][jj]=0;
			//          tv->ArryX[ii][jj]=0;
			//         tv->ArryY[ii][jj]=0;
		}
	}

	for(int ii=0 ; ii< tv->mrow ; ii++)
	{        
		tv->Arry[tv->P_A][ii]=-200;
		tv->Arry[tv->P_D][ii]=-200;
	}

	for(int ii=0 ; ii < tv->mcol ; ii++ )
	{
		tv->Arry[ii][tv->P_W]=-200;
		tv->Arry[ii][tv->P_S]=-200;
	}

	tv->life=3;
	tv->level=1;
	tv->bullet=50;
	tv->H_X=tv->mcol/2 ;
	tv->Arry[tv->H_X][tv->P_S-1]=-100;
	tv->Arry[tv->H_X+1][tv->P_S-1]=-100;
	tv->Arry[tv->H_X+2][tv->P_S-1]=-100;
	tv->Arry[tv->H_X+1][tv->P_S-2]=-100;
	DropBar_rand_next( tv) ;
	DropBar_tv_Draw( tv ) ;
	getchar();
	return 1 ;
}

int  tv_Destroy(DropBar * tv )
{
	delete []  tv->Arry[0] ;
	delete []  tv->Arry ;
	//    delete []  tv->ArryX[0] ;
	//   delete []  tv->ArryX ;
	//   delete []  tv->ArryY[0] ;
	//   delete []  tv->ArryY ;
	endwin();
	return 1;
}

int DropBar_tv_operations( DropBar * tv )
{

	while ( DropBar_tv_Draw(tv) )
	{
		int move =0 ;
		int bullet=0;
		//        int Now_sleep_time=tv->sleep_time ;
		while(!(tv->operations.empty()))
		{
			char c=tv->operations[0];
			tv->operations.erase((tv->operations).begin());
			switch (c)
			{
				case 'h': ; break;
				case 'q':  goto End_Flag ; break;
				case 'l': move=-1; break;
				case 'r': move=1; break;
				case 'u':  if ((tv->bullet)>0) {bullet++ ; --(tv->bullet) ;}  break;
				case 'd':  DropBar_Eat_one( tv ) ; break;
						   //case 'd': Now_sleep_time=Now_sleep_time-50;if (Now_sleep_time<0) {Now_sleep_time=40;} ;break;
				default: continue;
			}

			DropBar_Life_posi  ( tv  , move, bullet );
			DropBar_tv_Draw( tv );

			while (tv->m_pause)
			{
				usleep(tv->sleep_time*1000U);
				continue ;
			}
		}

		usleep( tv->sleep_time * 1000U );
		//    usleep( Now_sleep_time* 1000U );
		DropBar_Eat_one( tv ) ;

		while (tv->m_pause )
		{
			usleep(tv->sleep_time*1000U);
			continue ;
		}
	}
End_Flag :
	int B=0;
	B |= COLOR_PAIR(5); attron(B);
	mvaddstr(tv->mrow/2,tv->mcol/2,"Drop Rock Game Over");
	mvaddstr(tv->mrow/2+2,tv->mcol/2,"Enter 'yy' : Repeat");
	mvaddstr(tv->mrow/2+4,tv->mcol/2,"Enter 'nn' : Leave");
	mvaddstr(tv->mrow/2+6,tv->mcol/2,"Welcome Again");
	mvaddstr(tv->mrow/2+8,tv->mcol/2,"hewm@genomics.org.cn");
	attroff(B);
	refresh();
	tv->Game_Over=true ;
	return 0 ;
}


void DropBar_tv_Run (DropBar * tv )
{
	thread_group TG ;
	TG.create_thread(bind(DropBar_get_operations,boost::ref(tv)));
	TG.create_thread(bind(DropBar_tv_operations,boost::ref(tv)));
	TG.join_all();
}

int Game_DropBar_main(int argc, char** argv)
{
	bool Game_Repeat=true ;

	while(true)
	{
		DropBar  *game=new DropBar ;
		DropBar_tv_Init(game) ;
		DropBar_tv_Run(game);
		while(true)
		{
			int c=getch();
			if (c=='Y' || c=='y' || c==32)
			{
				Game_Repeat=false ;
				break ;
			}
			else if( c=='n' || c=='N' || c=='q' || c=='Q')
			{
				Game_Repeat=true ;
				break ;
			}
		}
		tv_Destroy(game);
		delete game ;

		if (Game_Repeat)
		{
			return 1 ;
		}
	}
	return 0;
}

////////////////////////swimming in the sea & flying in the sky //////////////////

#endif // Snake_Eat_H_
//
