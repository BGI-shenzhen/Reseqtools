#!/bin/sh
#$ -S /bin/sh
#Version1.0	hewm@genomics.org.cn	2017-09-28
echo Start Time : 
date
g++	-g	-O3	-o	iTools	-static	iTools.o	-lboost_system	-lboost_thread	-lpthread	-lncurses	-lgzstream	-lbam	-lz	-ldl	-luuid	-lgd	-lpng	-ljpeg	-lm	-lrt	-L	./src/include/ncurses/	-L	/zfssz5/BC_PUB/Software/01.Usr/lib	
echo End Time : 
date
